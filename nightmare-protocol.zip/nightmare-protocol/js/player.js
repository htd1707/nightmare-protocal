/* NIGHTMARE PROTOCOL — first-person player controller, stamina, head bob, footsteps, flashlight */
'use strict';
(function (NP) {
  const L = NP.Level;
  const Pl = (NP.Player = {});
  const fwd = new THREE.Vector3(), right = new THREE.Vector3(), wish = new THREE.Vector3();

  Pl.init = function (scene, camera) {
    this.scene = scene; this.camera = camera;
    this.pos = new THREE.Vector3(); this.vel = new THREE.Vector3();
    this.yaw = 0; this.pitch = 0; this.r = 0.3;
    this.eye = 1.62; this.eyeCur = 1.62; this.crouch = false; this.crouchToggle = false;
    this.stamina = 1; this.exhausted = false; this.staminaDelay = 0;
    this.bobPhase = 0; this.bobAmt = 0; this.lastStep = 0;
    this.shake = 0; this.shakeT = 0; this.roll = 0; this.kick = new THREE.Vector2();
    this.frozen = false; this.hidden = null; this.cine = null; this.speedMul = 1;
    this.moving = false; this.sprinting = false; this.noiseLevel = 0;

    // flashlight
    const q = NP.q();
    const fl = new THREE.SpotLight(0xfff1dc, 0, 24, 0.5, 0.55, 1.6);
    fl.castShadow = q.shadows > 0;
    if (fl.castShadow) { fl.shadow.mapSize.set(q.shadows, q.shadows); fl.shadow.camera.near = 0.15; fl.shadow.camera.far = 24; fl.shadow.bias = -0.0008; fl.shadow.normalBias = 0.02; }
    this.flash = fl;
    this.flashTarget = new THREE.Object3D();
    camera.add(fl); camera.add(this.flashTarget);
    fl.position.set(0.18, -0.16, 0.05); this.flashTarget.position.set(0.05, -0.05, -10);
    fl.target = this.flashTarget;
    // soft fill so the beam's near field reads
    this.fill = new THREE.PointLight(0xffe9d0, 0, 4.5, 2); camera.add(this.fill); this.fill.position.set(0.1, -0.1, -0.6);

    // hand-held torch model
    const hand = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.026, 0.22, 12), new THREE.MeshStandardMaterial({ color: 0x1a1c1d, roughness: 0.5, metalness: 0.6 }));
    body.rotation.x = Math.PI / 2;
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.026, 0.06, 14), new THREE.MeshStandardMaterial({ color: 0x2c2f31, roughness: 0.35, metalness: 0.8 }));
    head.rotation.x = Math.PI / 2; head.position.z = -0.13;
    this.lens = new THREE.Mesh(new THREE.CircleGeometry(0.03, 14), new THREE.MeshBasicMaterial({ color: 0x000000 }));
    this.lens.position.z = -0.161; this.lens.rotation.y = Math.PI;
    hand.add(body, head, this.lens);
    hand.position.set(0.2, -0.2, -0.38);
    hand.traverse((m) => { m.renderOrder = 10; });
    camera.add(hand); this.hand = hand; hand.visible = false;

    // volumetric beam cone
    const cg = new THREE.ConeGeometry(1, 1, 32, 1, true);
    cg.translate(0, -0.5, 0); cg.rotateX(Math.PI / 2);
    this.beamMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { uI: { value: 0 }, uT: { value: 0 } },
      vertexShader: 'varying vec3 vP; varying vec3 vN; varying vec3 vV; void main(){ vP=position; vec4 mv=modelViewMatrix*vec4(position,1.0); vV=normalize(-mv.xyz); vN=normalize(normalMatrix*normal); gl_Position=projectionMatrix*mv; }',
      fragmentShader: 'uniform float uI; uniform float uT; varying vec3 vP; varying vec3 vN; varying vec3 vV; float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);} void main(){ float d=clamp(-vP.z,0.0,1.0); float edge=pow(abs(dot(vN,vV)),2.0); float n=0.75+0.25*h(floor(gl_FragCoord.xy*0.5)+uT); float a=uI*(1.0-d)*(1.0-d)*edge*0.09*n*smoothstep(0.0,0.08,d); gl_FragColor=vec4(vec3(1.0,0.93,0.82)*a,1.0); }',
    });
    this.beam = new THREE.Mesh(cg, this.beamMat);
    this.beam.scale.set(4.2, 4.2, 10);
    this.beam.position.set(0.18, -0.16, -0.2);
    this.beam.renderOrder = 5; this.beam.frustumCulled = false;
    camera.add(this.beam);

    this.light = { owned: false, on: false, battery: 1, spares: 0, flick: 1, reloadT: 0 };
  };

  Pl.reset = function (pos, yaw) {
    this.pos.copy(pos); this.vel.set(0, 0, 0); this.yaw = yaw || 0; this.pitch = 0;
    this.stamina = 1; this.exhausted = false; this.hidden = null; this.cine = null; this.frozen = false;
    this.crouch = false; this.crouchToggle = false; this.shake = 0; this.eyeCur = this.eye;
  };

  Pl.addShake = function (amt, dur) { this.shake = Math.max(this.shake, amt); this.shakeT = Math.max(this.shakeT, dur || 0.4); };

  Pl.forward = function (out) { return out.set(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch)); };
  Pl.eyePos = function (out) { return out.set(this.pos.x, this.eyeCur, this.pos.z); };

  /* is a world point in view (cone) and visible (LOS)? */
  Pl.canSee = function (p, cosLimit = 0.55, maxD = 40) {
    const dx = p.x - this.pos.x, dy = p.y - this.eyeCur, dz = p.z - this.pos.z;
    const d = Math.hypot(dx, dy, dz); if (d > maxD) return false;
    this.forward(fwd);
    const c = (fwd.x * dx + fwd.y * dy + fwd.z * dz) / d;
    if (c < cosLimit) return false;
    return L.los(this.pos.x, this.pos.z, p.x, p.z, 'sight');
  };
  Pl.facingDot = function (p) {
    const dx = p.x - this.pos.x, dy = p.y - this.eyeCur, dz = p.z - this.pos.z;
    const d = Math.hypot(dx, dy, dz) || 1; this.forward(fwd);
    return (fwd.x * dx + fwd.y * dy + fwd.z * dz) / d;
  };
  /* point is inside flashlight beam */
  Pl.inBeam = function (p, maxD = 16) {
    if (!this.light.on || this.light.flick < 0.3) return false;
    const dx = p.x - this.pos.x, dy = p.y - this.eyeCur, dz = p.z - this.pos.z;
    const d = Math.hypot(dx, dy, dz); if (d > maxD) return false;
    this.forward(fwd);
    return (fwd.x * dx + fwd.y * dy + fwd.z * dz) / d > 0.93 && L.los(this.pos.x, this.pos.z, p.x, p.z, 'sight');
  };

  Pl.update = function (dt, I) {
    const S = NP.settings;
    // ---- look ----
    if (!this.frozen && !this.cine) {
      const sens = 0.0022 * S.sensitivity;
      this.yaw -= I.mdx * sens;
      this.pitch -= I.mdy * sens * (S.invertY ? -1 : 1);
      this.pitch = NP.clamp(this.pitch, -1.45, 1.45);
    }
    // ---- move ----
    let mvx = 0, mvz = 0;
    const canMove = !this.frozen && !this.hidden && !this.cine;
    if (canMove) {
      if (I.down('KeyW') || I.down('ArrowUp')) mvz += 1;
      if (I.down('KeyS') || I.down('ArrowDown')) mvz -= 1;
      if (I.down('KeyA') || I.down('ArrowLeft')) mvx -= 1;
      if (I.down('KeyD') || I.down('ArrowRight')) mvx += 1;
      if (I.hit('KeyC')) this.crouchToggle = !this.crouchToggle;
    }
    this.crouch = canMove && (this.crouchToggle || I.down('ControlLeft') || I.down('ControlRight'));
    const wantSprint = canMove && (I.down('ShiftLeft') || I.down('ShiftRight')) && mvz > 0 && !this.crouch;
    this.sprinting = wantSprint && !this.exhausted && this.stamina > 0.02;
    // stamina
    if (this.sprinting) { this.stamina -= dt / 6.5; this.staminaDelay = 1.1; if (this.stamina <= 0) { this.stamina = 0; this.exhausted = true; NP.Audio && NP.Audio.exhaust(); } }
    else { this.staminaDelay -= dt; if (this.staminaDelay <= 0) this.stamina = Math.min(1, this.stamina + dt / 4.5); if (this.exhausted && this.stamina > 0.4) this.exhausted = false; }

    const speed = (this.crouch ? 1.45 : this.sprinting ? 5.5 : 3.0) * this.speedMul * (this.exhausted ? 0.85 : 1);
    fwd.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    right.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    wish.set(0, 0, 0).addScaledVector(fwd, mvz).addScaledVector(right, mvx);
    if (wish.lengthSq() > 0) wish.normalize().multiplyScalar(speed);
    const acc = wish.lengthSq() > 0 ? 11 : 13;
    this.vel.x = NP.damp(this.vel.x, wish.x, acc, dt); this.vel.z = NP.damp(this.vel.z, wish.z, acc, dt);
    const ox = this.pos.x, oz = this.pos.z;
    // sub-step to avoid tunnelling
    const steps = Math.ceil(Math.hypot(this.vel.x, this.vel.z) * dt / 0.12) || 1;
    for (let i = 0; i < steps; i++) {
      this.pos.x += this.vel.x * dt / steps; this.pos.z += this.vel.z * dt / steps;
      L.collideCircle(this.pos, this.r, 'player');
    }
    const moved = Math.hypot(this.pos.x - ox, this.pos.z - oz);
    const hs = moved / Math.max(dt, 1e-4);
    this.moving = hs > 0.4;

    // ---- head bob + footsteps ----
    this.bobAmt = NP.damp(this.bobAmt, this.moving ? (this.sprinting ? 1.6 : this.crouch ? 0.5 : 1) : 0, 8, dt);
    const prev = this.bobPhase;
    this.bobPhase += moved * (this.sprinting ? 1.55 : 1.9);
    if (Math.floor(prev / Math.PI) !== Math.floor(this.bobPhase / Math.PI) && this.moving) this.footstep();
    const targetEye = this.crouch ? 1.02 : this.eye;
    this.eyeCur = NP.damp(this.eyeCur, targetEye, 10, dt);

    // ---- noise emitted ----
    this.noiseLevel = !this.moving ? 0 : this.crouch ? 0.15 : this.sprinting ? 1 : 0.4;

    // ---- shake ----
    if (this.shakeT > 0) { this.shakeT -= dt; if (this.shakeT <= 0) this.shake = 0; }
    this.kick.x = NP.damp(this.kick.x, 0, 6, dt); this.kick.y = NP.damp(this.kick.y, 0, 6, dt);

    this.applyCamera(dt);
    this.updateFlashlight(dt, I);
  };

  Pl.footstep = function () {
    const z = L.zoneAt(this.pos.x, this.pos.z);
    let surf = z ? z.surf : 'concrete';
    if (L.puddles) for (const p of L.puddles) if (Math.hypot(p.x - this.pos.x, p.z - this.pos.z) < p.r) { surf = 'water'; break; }
    const vol = this.crouch ? 0.25 : this.sprinting ? 1 : 0.6;
    if (NP.Audio) NP.Audio.footstep(surf, vol, this.sprinting);
    const radius = this.crouch ? 1.6 : this.sprinting ? 15 : 6;
    NP.Bus.emit('noise', { x: this.pos.x, z: this.pos.z, r: radius * (surf === 'metal' ? 1.3 : surf === 'water' ? 1.2 : 1), kind: 'step' });
  };

  const _e = new THREE.Euler(0, 0, 0, 'YXZ');
  Pl.applyCamera = function (dt) {
    const cam = this.camera;
    if (this.cine) {
      // scripted camera: blend toward cine pose
      const c = this.cine;
      cam.position.lerp(c.pos, 1 - Math.exp(-(c.rate || 6) * dt));
      if (c.look) {
        const m = new THREE.Matrix4().lookAt(cam.position, c.look, cam.up);
        const tq = new THREE.Quaternion().setFromRotationMatrix(m);
        cam.quaternion.slerp(tq, 1 - Math.exp(-(c.lookRate || 6) * dt));
      }
      if (c.roll) cam.rotateZ(c.roll);
      if (this.shake > 0) { cam.position.x += (Math.random() - 0.5) * this.shake * 0.1; cam.position.y += (Math.random() - 0.5) * this.shake * 0.1; }
      return;
    }
    const S = NP.settings;
    const bobK = S.headBob ? this.bobAmt : this.bobAmt * 0.2;
    const by = Math.abs(Math.sin(this.bobPhase)) * 0.045 * bobK;
    const bx = Math.cos(this.bobPhase) * 0.03 * bobK;
    if (this.hidden) {
      cam.position.copy(this.hidden.eye);
      _e.set(this.pitch, this.yaw, 0);
    } else {
      cam.position.set(this.pos.x + right.x * bx, this.eyeCur + by - 0.02 * bobK, this.pos.z + right.z * bx);
      this.roll = NP.damp(this.roll, Math.cos(this.bobPhase) * 0.008 * bobK, 10, dt);
      _e.set(this.pitch + this.kick.y, this.yaw + this.kick.x, this.roll);
    }
    cam.quaternion.setFromEuler(_e);
    if (this.shake > 0) {
      const s = this.shake * Math.min(1, this.shakeT * 3);
      cam.rotateX((Math.random() - 0.5) * s * 0.05); cam.rotateY((Math.random() - 0.5) * s * 0.05);
      cam.position.x += (Math.random() - 0.5) * s * 0.04; cam.position.y += (Math.random() - 0.5) * s * 0.04;
    }
  };

  Pl.toggleFlash = function () {
    const l = this.light;
    if (!l.owned || l.reloadT > 0) return;
    if (l.battery <= 0.001 && !l.on) { NP.UI && NP.UI.toast('Battery dead — press R to swap batteries'); NP.Audio && NP.Audio.click(0.5); return; }
    l.on = !l.on;
    NP.Audio && NP.Audio.click(1);
    NP.Bus.emit('flash', { on: l.on });
  };
  Pl.reload = function () {
    const l = this.light;
    if (!l.owned || l.reloadT > 0) return;
    if (l.spares <= 0) { NP.UI && NP.UI.toast('No spare batteries'); return; }
    if (l.battery > 0.95) { NP.UI && NP.UI.toast('Battery already full'); return; }
    l.spares--; l.reloadT = 1.1; NP.Audio && NP.Audio.reload();
    NP.Timers.after(1.1, () => { l.battery = 1; });
  };

  const _tq = new THREE.Quaternion(), _sm = new THREE.Quaternion();
  Pl.updateFlashlight = function (dt) {
    const l = this.light, q = NP.q();
    this.hand.visible = l.owned && !this.hidden && !this.cine;
    if (l.reloadT > 0) { l.reloadT -= dt; }
    if (l.on && l.reloadT <= 0) {
      l.battery = Math.max(0, l.battery - dt / 210);
      if (l.battery <= 0) { l.on = false; NP.UI && NP.UI.toast('The flashlight died. Press R to swap batteries.'); NP.Bus.emit('flash', { on: false }); }
    }
    // flicker at low battery, plus scripted interference
    let f = 1;
    if (l.battery < 0.22) {
      const n = NP.noise1(NP.Timers.time * 3.3);
      if (n > 0.55 - (0.22 - l.battery) * 2) f = Math.random() < 0.5 ? 0.1 : 0.6;
      f *= 0.55 + l.battery * 2;
    }
    if (this.interfere > 0) { this.interfere -= dt; if (Math.random() < 0.6) f *= Math.random() * 0.3; }
    l.flick = l.on && l.reloadT <= 0 ? f : 0;
    const I = l.flick;
    this.flash.intensity = I * 3.2;
    this.fill.intensity = I * 0.35;
    this.beamMat.uniforms.uI.value = I * (q.fogSprites > 20 ? 1 : 0.7);
    this.beamMat.uniforms.uT.value = NP.Timers.time;
    this.beam.visible = I > 0.01 && !this.hidden;
    this.lens.material.color.setScalar(I > 0 ? 6 * I : 0.02);
    // lag the beam slightly behind the view for weight
    const sway = Math.sin(this.bobPhase) * 0.012 * this.bobAmt;
    this.flashTarget.position.set(0.05 + sway * 8 - this.vel.x * 0.0, -0.05 + Math.abs(sway) * 6, -10);
    this.hand.position.set(0.2 + sway, -0.2 - Math.abs(sway) * 0.6 + (l.reloadT > 0 ? -0.15 * Math.sin(Math.min(1, l.reloadT) * Math.PI) : 0), -0.38);
  };
})(window.NP);
