/* NIGHTMARE PROTOCOL — core: namespace, math, rng, settings, save, timers, input */
'use strict';
window.NP = window.NP || {};
(function (NP) {
  const V3 = THREE.Vector3;

  /* ---------- math helpers ---------- */
  NP.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  NP.lerp = (a, b, t) => a + (b - a) * t;
  NP.smooth = (t) => t * t * (3 - 2 * t);
  NP.damp = (a, b, rate, dt) => a + (b - a) * (1 - Math.exp(-rate * dt));
  NP.angDiff = (a, b) => {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return d;
  };
  NP.v3 = (x, y, z) => new V3(x, y, z);

  /* ---------- seeded rng (per playthrough variation) ---------- */
  NP.makeRng = function (seed) {
    let s = seed >>> 0 || 1;
    const r = () => {
      s ^= s << 13; s >>>= 0;
      s ^= s >>> 17;
      s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
    r.range = (a, b) => a + (b - a) * r();
    r.int = (a, b) => Math.floor(a + (b - a + 1) * r());
    r.pick = (arr) => arr[Math.floor(r() * arr.length) % arr.length];
    r.shuffle = (arr) => {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(r() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    };
    return r;
  };
  NP.rand = NP.makeRng(Date.now() & 0xffffffff);

  /* value noise 1D for organic flicker / twitch */
  const NOISE = new Float32Array(512);
  { const r = NP.makeRng(1337); for (let i = 0; i < 512; i++) NOISE[i] = r() * 2 - 1; }
  NP.noise1 = (x) => {
    const i = Math.floor(x), f = x - i;
    const a = NOISE[i & 511], b = NOISE[(i + 1) & 511];
    return a + (b - a) * NP.smooth(f);
  };

  /* ---------- storage (always guarded) ---------- */
  NP.store = {
    get(k, def) {
      try { const v = localStorage.getItem('np_' + k); return v == null ? def : JSON.parse(v); } catch (e) { return def; }
    },
    set(k, v) { try { localStorage.setItem('np_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
    del(k) { try { localStorage.removeItem('np_' + k); } catch (e) { /* ignore */ } },
  };

  /* ---------- settings ---------- */
  const DEFAULTS = {
    quality: 'medium', sensitivity: 1.0, invertY: false, fov: 72,
    volume: 0.85, musicVolume: 0.8, brightness: 1.0, headBob: true, subtitles: true, showObjective: true,
  };
  NP.settings = Object.assign({}, DEFAULTS, NP.store.get('settings', {}));
  NP.saveSettings = () => NP.store.set('settings', NP.settings);

  NP.QUALITY = {
    low: { scale: 0.6, shadows: 0, lights: 3, ssao: false, bloom: false, particles: 140, mirror: 0, fogSprites: 10, aniso: 1 },
    medium: { scale: 0.8, shadows: 512, lights: 4, ssao: false, bloom: true, particles: 300, mirror: 0, fogSprites: 22, aniso: 2 },
    high: { scale: 1.0, shadows: 1024, lights: 6, ssao: true, bloom: true, particles: 520, mirror: 256, fogSprites: 36, aniso: 4 },
    ultra: { scale: 1.0, dprBoost: true, shadows: 2048, lights: 8, ssao: true, bloom: true, particles: 800, mirror: 512, fogSprites: 50, aniso: 8 },
  };
  NP.q = () => NP.QUALITY[NP.settings.quality] || NP.QUALITY.medium;

  /* ---------- game-time scheduler (pauses with the game) ---------- */
  NP.Timers = {
    list: [], time: 0,
    after(delay, fn, tag) { const t = { at: this.time + delay, fn, tag }; this.list.push(t); return t; },
    seq(steps, tag) { steps.forEach(([d, fn]) => this.after(d, fn, tag)); },
    cancel(tag) { this.list = this.list.filter((t) => t.tag !== tag); },
    clear() { this.list.length = 0; },
    update(dt) {
      this.time += dt;
      if (!this.list.length) return;
      const due = [];
      this.list = this.list.filter((t) => { if (t.at <= this.time) { due.push(t); return false; } return true; });
      due.sort((a, b) => a.at - b.at);
      for (const t of due) { try { t.fn(); } catch (e) { console.error('[timer]', e); } }
    },
  };

  /* ---------- tweens (game time) ---------- */
  NP.Tweens = {
    list: [],
    add(dur, fn, done, tag) { const tw = { t: 0, dur, fn, done, tag }; this.list.push(tw); return tw; },
    cancel(tag) { this.list = this.list.filter((t) => t.tag !== tag); },
    clear() { this.list.length = 0; },
    update(dt) {
      for (let i = this.list.length - 1; i >= 0; i--) {
        const tw = this.list[i];
        tw.t += dt;
        const k = Math.min(1, tw.t / tw.dur);
        try { tw.fn(k); } catch (e) { console.error('[tween]', e); }
        if (k >= 1) { this.list.splice(i, 1); if (tw.done) try { tw.done(); } catch (e) { console.error(e); } }
      }
    },
  };

  /* ---------- input ---------- */
  NP.Input = {
    keys: {}, pressed: {}, mdx: 0, mdy: 0, mouseDown: false, clicked: false, locked: false,
    init(canvas) {
      addEventListener('keydown', (e) => {
        if (['Space', 'Tab', 'ControlLeft', 'ControlRight'].includes(e.code) && NP.Game && NP.Game.state === 'play') e.preventDefault();
        if (!this.keys[e.code]) this.pressed[e.code] = true;
        this.keys[e.code] = true;
        if (NP.Game) NP.Game.onKey(e);
      });
      addEventListener('keyup', (e) => { this.keys[e.code] = false; });
      addEventListener('blur', () => { this.keys = {}; });
      addEventListener('mousemove', (e) => {
        // drag-to-look fallback when pointer lock is refused
        if (!this.locked && !(this.mouseDown && NP.Game && NP.Game.noLock && NP.Game.state === 'play')) return;
        this.mdx += e.movementX || 0; this.mdy += e.movementY || 0;
      });
      canvas.addEventListener('mousedown', (e) => {
        if (e.button === 0) { this.mouseDown = true; this.clicked = true; }
        if (NP.Game) NP.Game.onCanvasClick(e);
      });
      addEventListener('mouseup', (e) => { if (e.button === 0) this.mouseDown = false; });
      document.addEventListener('pointerlockchange', () => {
        this.locked = document.pointerLockElement === canvas;
        if (NP.Game) NP.Game.onLockChange(this.locked);
      });
      document.addEventListener('pointerlockerror', () => { this.locked = false; if (NP.Game) NP.Game.onLockError(); });
      this.canvas = canvas;
    },
    lock() {
      try {
        const p = this.canvas.requestPointerLock();
        if (p && p.catch) p.catch(() => NP.Game && NP.Game.onLockError());
      } catch (e) { if (NP.Game) NP.Game.onLockError(); }
    },
    unlock() { try { if (document.pointerLockElement) document.exitPointerLock(); } catch (e) { /* ignore */ } },
    endFrame() { this.pressed = {}; this.mdx = 0; this.mdy = 0; this.clicked = false; },
    down(code) { return !!this.keys[code]; },
    hit(code) { return !!this.pressed[code]; },
  };

  /* ---------- tiny event bus ---------- */
  NP.Bus = {
    h: {},
    on(n, f) { (this.h[n] = this.h[n] || []).push(f); },
    emit(n, a) { (this.h[n] || []).forEach((f) => { try { f(a); } catch (e) { console.error('[bus]', n, e); } }); },
  };
})(window.NP);
