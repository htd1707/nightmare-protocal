/* NIGHTMARE PROTOCOL — level: grid map, geometry batching, baked circuit lighting, fixtures, doors, collision, LOS */
'use strict';
(function (NP) {
  const C = 2.4, W = 40, H = 40;
  const L = (NP.Level = { C, W, H });

  /* ---------------- MAP ---------------- */
  const grid = [];
  for (let z = 0; z < H; z++) grid.push(new Array(W).fill('#'));
  const carve = (x0, z0, x1, z1, ch) => { for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) grid[z][x] = ch; };
  const set = (x, z, ch) => { grid[z][x] = ch; };

  carve(3, 30, 7, 34, 'v');            // recovery
  carve(9, 28, 21, 36, 'r');           // reception
  [[12, 30], [18, 30], [12, 34], [18, 34]].forEach(([x, z]) => set(x, z, '#')); // pillars
  carve(23, 27, 24, 37, 'g');          // service corridor
  carve(26, 27, 31, 30, 'k');          // storage
  carve(26, 32, 33, 37, 'n');          // generator
  carve(15, 13, 16, 26, 'm');          // medical corridor
  carve(18, 22, 22, 26, 'm');          // exam room E1
  carve(18, 14, 22, 19, 'm');          // simulation room E2
  carve(10, 22, 13, 25, 'm');          // pharmacy W1
  carve(2, 14, 13, 15, 'w');           // ward hallway
  carve(2, 17, 4, 20, 'w'); carve(6, 17, 8, 20, 'w'); carve(10, 17, 12, 20, 'w'); // 101-103
  carve(2, 9, 4, 12, 'w'); carve(6, 9, 8, 12, 'w');   // 104-105
  carve(10, 4, 22, 11, 'l');           // lab
  for (let z = 4; z <= 6; z++) set(17, z, '#');
  for (let x = 18; x <= 22; x++) set(x, 7, 'G');      // observation glass
  carve(24, 5, 25, 18, 't');           // tunnel north-south
  for (let z = 12; z <= 15; z++) set(25, z, '#');     // narrow squeeze
  carve(24, 17, 37, 18, 't');          // tunnel east-west
  carve(36, 19, 37, 28, 't');          // tunnel south leg
  carve(27, 20, 34, 25, 'q');          // security
  carve(28, 4, 37, 15, 'c');           // containment
  carve(7, 1, 37, 2, 'x');             // exit corridor
  carve(2, 1, 5, 3, 'e'); set(6, 1, 'x'); set(6, 2, 'x'); // elevator lobby
  set(2, 32, 'M');                     // two-way mirror in recovery

  // door cells
  const DOORS = [
    { id: 'recovery', x: 8, z: 32, kind: 'hinged', label: 'Recovery' },
    { id: 'service', x: 22, z: 31, kind: 'slide', lock: 'L1', label: 'Service Access' },
    { id: 'storage', x: 25, z: 28, kind: 'hinged', label: 'Storage' },
    { id: 'generator', x: 25, z: 34, kind: 'hinged', label: 'Generator Room' },
    { id: 'medical', x: 15, z: 27, kind: 'slide', lock: 'fuse', label: 'Medical Wing' },
    { id: 'exam', x: 17, z: 24, kind: 'hinged', label: 'Exam 2' },
    { id: 'sim', x: 17, z: 16, kind: 'hinged', label: 'Simulation' },
    { id: 'pharmacy', x: 14, z: 23, kind: 'hinged', label: 'Pharmacy' },
    { id: 'ward', x: 14, z: 14, kind: 'hinged', label: 'Patient Ward' },
    { id: 'r101', x: 3, z: 16, kind: 'hinged', label: '101' },
    { id: 'r102', x: 7, z: 16, kind: 'hinged', label: '102' },
    { id: 'r103', x: 11, z: 16, kind: 'hinged', label: '103' },
    { id: 'r104', x: 3, z: 13, kind: 'hinged', label: '104' },
    { id: 'r105', x: 7, z: 13, kind: 'hinged', label: '105' },
    { id: 'lab', x: 15, z: 12, kind: 'slide', lock: 'keypad', label: 'Research Lab' },
    { id: 'cell', x: 20, z: 7, kind: 'heavy', lock: 'script', label: 'Containment Cell 0' },
    { id: 'tunnel', x: 23, z: 9, kind: 'heavy', lock: 'script', label: 'Maintenance' },
    { id: 'security', x: 35, z: 23, kind: 'slide', lock: 'L2', label: 'Security Control' },
    { id: 'contain', x: 32, z: 16, kind: 'heavy', lock: 'contain', label: 'Containment Chamber' },
    { id: 'blast', x: 33, z: 3, kind: 'heavy', lock: 'exit', label: 'Emergency Exit' },
    { id: 'x1', x: 30, z: 2, kind: 'shutter', label: 'Bulkhead A', startOpen: true },
    { id: 'x2', x: 22, z: 2, kind: 'shutter', label: 'Bulkhead B', startOpen: true },
    { id: 'x3', x: 14, z: 2, kind: 'shutter', label: 'Bulkhead C', startOpen: true },
  ];
  // shutters live in a 2-wide corridor: wall off the other row
  DOORS.forEach((d) => { set(d.x, d.z, '+'); if (d.kind === 'shutter') set(d.x, 1, '#'); });

  L.grid = grid;
  L.ZONES = {
    v: { name: 'Recovery', floor: 'lino', wall: 'paint', ceil: 'ceiling', h: 3.0, surf: 'tile', amb: [0.010, 0.012, 0.016] },
    r: { name: 'Reception', floor: 'tileFloor', wall: 'paint', ceil: 'ceiling', h: 3.6, surf: 'tile', amb: [0.010, 0.012, 0.016] },
    g: { name: 'Service Corridor', floor: 'concrete', wall: 'concrete', ceil: 'concrete', h: 3.0, surf: 'concrete', amb: [0.008, 0.009, 0.012] },
    k: { name: 'Storage', floor: 'concrete', wall: 'concrete', ceil: 'concrete', h: 3.0, surf: 'concrete', amb: [0.008, 0.009, 0.012] },
    n: { name: 'Generator Room', floor: 'metal', wall: 'concrete', ceil: 'concrete', h: 4.2, surf: 'metal', amb: [0.008, 0.008, 0.010] },
    m: { name: 'Medical Wing', floor: 'tileFloor', wall: 'tileWall', ceil: 'ceiling', h: 3.0, surf: 'tile', amb: [0.009, 0.013, 0.012] },
    w: { name: 'Patient Ward', floor: 'lino', wall: 'paint', ceil: 'ceiling', h: 3.0, surf: 'tile', amb: [0.009, 0.011, 0.012] },
    l: { name: 'Research Laboratory', floor: 'tileFloor', wall: 'labPanel', ceil: 'ceiling', h: 3.4, surf: 'tile', amb: [0.008, 0.011, 0.014] },
    t: { name: 'Maintenance Tunnels', floor: 'grate', wall: 'concrete', ceil: 'concrete', h: 2.5, surf: 'metal', amb: [0.007, 0.007, 0.009] },
    q: { name: 'Security Control', floor: 'lino', wall: 'paint', ceil: 'ceiling', h: 3.0, surf: 'tile', amb: [0.009, 0.010, 0.013] },
    c: { name: 'Containment Chamber', floor: 'metal', wall: 'metal', ceil: 'metal', h: 7.0, surf: 'metal', amb: [0.008, 0.010, 0.010] },
    x: { name: 'Emergency Exit', floor: 'concrete', wall: 'concrete', ceil: 'concrete', h: 3.0, surf: 'concrete', amb: [0.009, 0.006, 0.006] },
    e: { name: 'Service Lift', floor: 'metal', wall: 'metal', ceil: 'metal', h: 3.0, surf: 'metal', amb: [0.009, 0.009, 0.010] },
  };
  const DOOR_H = 2.7;

  /* ---------------- grid queries ---------------- */
  L.inb = (x, z) => x >= 0 && z >= 0 && x < W && z < H;
  L.ch = (x, z) => (L.inb(x, z) ? grid[z][x] : '#');
  L.isFloorish = (x, z) => { const c = L.ch(x, z); return c !== '#' && c !== 'M'; }; // includes G and +
  L.isSolid = (x, z) => { const c = L.ch(x, z); return c === '#' || c === 'M'; };
  L.cellOf = (x, z) => [Math.floor(x / C), Math.floor(z / C)];
  L.center = (gx, gz, y = 0) => new THREE.Vector3((gx + 0.5) * C, y, (gz + 0.5) * C);
  L.doorAtCell = {};
  L.zoneKey = (gx, gz) => {
    const c = L.ch(gx, gz);
    if (L.ZONES[c]) return c;
    if (c === '+' || c === 'G') {
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = L.ch(gx + dx, gz + dz); if (L.ZONES[n]) return n; }
    }
    return null;
  };
  L.zoneAt = (x, z) => { const [gx, gz] = L.cellOf(x, z); const k = L.zoneKey(gx, gz); return k ? L.ZONES[k] : null; };
  L.ceilH = (gx, gz) => {
    const c = L.ch(gx, gz);
    if (c === '+') {
      let m = 99;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = L.ch(gx + dx, gz + dz); if (L.ZONES[n]) m = Math.min(m, L.ZONES[n].h); }
      return Math.min(DOOR_H, m);
    }
    const k = L.zoneKey(gx, gz);
    return k ? L.ZONES[k].h : 0;
  };

  /* ---------------- materials ---------------- */
  L.bakeUniform = { value: 1.0 };      // global multiplier for baked light (blackouts)
  L.bakeTint = { value: new THREE.Color(1, 1, 1) };
  L.mats = {};
  function bakedMaterial(params) {
    const m = new THREE.MeshStandardMaterial(params);
    m.vertexColors = true;
    m.onBeforeCompile = (sh) => {
      sh.uniforms.uBake = L.bakeUniform;
      sh.uniforms.uBakeTint = L.bakeTint;
      sh.fragmentShader = 'uniform float uBake;\nuniform vec3 uBakeTint;\n' + sh.fragmentShader
        .replace('#include <color_fragment>', '')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n#ifdef USE_COLOR\n totalEmissiveRadiance += diffuseColor.rgb * vColor * uBake * uBakeTint;\n#endif');
    };
    m.customProgramCacheKey = () => 'baked';
    return m;
  }
  L.bakedMaterial = bakedMaterial;
  const MATDEF = {
    // [texture, colour tint, roughness, metalness, uv scale (m per repeat)]
    floor_lino: ['lino', 0xb9c4b8, 1, 0, 2.4], floor_tileFloor: ['tileFloor', 0xffffff, 1, 0, 2.4],
    floor_concrete: ['concrete', 0xd0d0d0, 1, 0, 3.0], floor_metal: ['metal', 0xb8bfc0, 1, 0.35, 2.4],
    floor_grate: ['grate', 0xffffff, 1, 0.5, 1.2],
    wall_paint: ['paint', 0xffffff, 1, 0, 2.4], wall_tileWall: ['tileWall', 0xffffff, 1, 0, 2.4],
    wall_concrete: ['concrete', 0xffffff, 1, 0, 3.0], wall_labPanel: ['labPanel', 0xdfe6ea, 1, 0, 2.4],
    wall_metal: ['metal', 0xa8b2b2, 1, 0.4, 2.4],
    ceil_ceiling: ['ceiling', 0xffffff, 1, 0, 2.4], ceil_concrete: ['concrete', 0x9a9a9a, 1, 0, 3.0], ceil_metal: ['metal', 0x707878, 1, 0.3, 2.4],
    p_metal: ['metal', 0x8e9a92, 0.9, 0.35, 1.2], p_steel: ['metal', 0xd8dde0, 0.35, 0.85, 1.0], p_rust: ['metal', 0xa07a5a, 1, 0.3, 1.2],
    p_wood: ['concrete', 0x8a6a4a, 0.7, 0, 1.0], p_fabric: ['lino', 0x9fa38f, 1, 0, 1.0], p_white: ['tileWall', 0xe8ece6, 0.6, 0, 3.0],
    p_dark: ['concrete', 0x3a3d3e, 0.8, 0.1, 1.0], p_pipe: ['metal', 0x6f6a5c, 0.8, 0.5, 0.8], p_yellow: ['metal', 0xb89a2a, 0.7, 0.2, 1.0],
    p_conc: ['concrete', 0x9a9a98, 1, 0, 2.0], p_green: ['paint', 0x7f9a86, 0.9, 0.1, 1.2],
  };
  L.mat = function (key) {
    if (L.mats[key]) return L.mats[key];
    const d = MATDEF[key];
    const t = NP.Tex.get(d[0]);
    const m = bakedMaterial({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, color: d[1], roughness: d[2], metalness: d[3] });
    m.normalScale = new THREE.Vector2(1, 1);
    m.userData.uvScale = d[4];
    L.mats[key] = m;
    return m;
  };
  // unbaked materials for moving objects (doors, items, levers)
  L.dynMat = function (key, extra) {
    const d = MATDEF[key];
    const t = NP.Tex.get(d[0]);
    return new THREE.MeshStandardMaterial(Object.assign({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, color: d[1], roughness: d[2], metalness: d[3] }, extra || {}));
  };

  /* ---------------- geometry batches ---------------- */
  const batches = {};   // key -> {pos[], nor[], uv[], idx[], cell[], ao[]}
  function batch(key) {
    return batches[key] || (batches[key] = { key, pos: [], nor: [], uv: [], idx: [], cell: [], ao: [] });
  }
  // subdivided quad. origin o, axis a (len la), axis b (len lb), normal n
  function quad(key, o, a, b, la, lb, n, cell, aoFn, sa, sb) {
    const B = batch(key);
    const sc = 1 / L.mat(key).userData.uvScale;
    const base = B.pos.length / 3;
    for (let j = 0; j <= sb; j++) for (let i = 0; i <= sa; i++) {
      const u = i / sa, v = j / sb;
      const x = o[0] + a[0] * la * u + b[0] * lb * v, y = o[1] + a[1] * la * u + b[1] * lb * v, z = o[2] + a[2] * la * u + b[2] * lb * v;
      B.pos.push(x, y, z); B.nor.push(n[0], n[1], n[2]);
      // world-projected UVs
      if (Math.abs(n[1]) > 0.5) B.uv.push(x * sc, z * sc);
      else if (Math.abs(n[0]) > 0.5) B.uv.push(z * sc, y * sc);
      else B.uv.push(x * sc, y * sc);
      B.cell.push(cell);
      B.ao.push(aoFn ? aoFn(x, y, z) : 1);
    }
    for (let j = 0; j < sb; j++) for (let i = 0; i < sa; i++) {
      const a0 = base + j * (sa + 1) + i, a1 = a0 + 1, b0 = a0 + sa + 1, b1 = b0 + 1;
      B.idx.push(a0, b0, a1, a1, b0, b1);
    }
  }
  // fix triangle winding so normals face n
  function quadN(key, o, a, b, la, lb, n, cell, aoFn, sa, sb) {
    const cr = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    if (cr[0] * n[0] + cr[1] * n[1] + cr[2] * n[2] > 0) {
      // swap axes to flip winding
      quad(key, o, b, a, lb, la, n, cell, aoFn, sb, sa);
    } else quad(key, o, a, b, la, lb, n, cell, aoFn, sa, sb);
  }

  /* Add an arbitrary THREE geometry (in local space) to a static baked batch */
  const _m3 = new THREE.Matrix3(), _v = new THREE.Vector3(), _n = new THREE.Vector3();
  L.addStatic = function (geo, matrix, key, cellIdx) {
    const B = batch(key);
    const sc = 1 / L.mat(key).userData.uvScale;
    const p = geo.attributes.position, nr = geo.attributes.normal;
    _m3.getNormalMatrix(matrix);
    const base = B.pos.length / 3;
    for (let i = 0; i < p.count; i++) {
      _v.fromBufferAttribute(p, i).applyMatrix4(matrix);
      _n.fromBufferAttribute(nr, i).applyMatrix3(_m3).normalize();
      B.pos.push(_v.x, _v.y, _v.z); B.nor.push(_n.x, _n.y, _n.z);
      const ax = Math.abs(_n.x), ay = Math.abs(_n.y), az = Math.abs(_n.z);
      if (ay >= ax && ay >= az) B.uv.push(_v.x * sc, _v.z * sc);
      else if (ax >= az) B.uv.push(_v.z * sc, _v.y * sc);
      else B.uv.push(_v.x * sc, _v.y * sc);
      let ci = cellIdx;
      if (ci == null) { const gx = Math.floor(_v.x / C), gz = Math.floor(_v.z / C); ci = gz * W + gx; }
      B.cell.push(ci);
      B.ao.push(_v.y < 0.25 ? 0.75 : 1);
    }
    if (geo.index) { const ix = geo.index.array; for (let i = 0; i < ix.length; i++) B.idx.push(base + ix[i]); }
    else for (let i = 0; i < p.count; i++) B.idx.push(base + i);
  };

  /* ---------------- fixtures & circuits ---------------- */
  L.fixtures = [];
  L.circuits = {};
  L.circuitTarget = {};
  L.addFixture = function (f) {
    f = Object.assign({ color: [1, 1, 1], intensity: 1, range: 8, circuit: 'emer', flicker: 'stable', kind: 'fluor', bake: true, seed: Math.random() * 100, n: [0, -1, 0] }, f);
    if (f.flicker === 'dying' || f.flicker === 'strobe' || f.flicker === 'beacon') f.bake = false;
    f.pos = new THREE.Vector3(f.x, f.y, f.z);
    f.level = 0; f.cur = 0; f.override = null; // override = forced brightness for scares
    if (!(f.circuit in L.circuits)) { L.circuits[f.circuit] = 0; L.circuitTarget[f.circuit] = 0; }
    L.fixtures.push(f);
    return f;
  };
  function flickerVal(f, t) {
    const s = f.seed;
    switch (f.flicker) {
      case 'buzz': return NP.noise1(t * 9 + s) > 0.82 ? 0.55 : 0.97 + NP.noise1(t * 40 + s) * 0.03;
      case 'dying': {
        const ph = NP.noise1(t * 0.55 + s);
        if (ph > 0.45) return 0.02;
        if (ph > 0.15) return ((Math.floor(t * 22 + s * 7) * 2654435761) >>> 0) % 7 < 3 ? 0.1 : 1;
        return 0.95;
      }
      case 'strobe': return Math.max(0, Math.sin(t * 6 + s)) > 0.25 ? 1 : 0.08;
      case 'beacon': return 0.15 + 0.85 * Math.pow(Math.max(0, Math.cos(t * 3.4 + s)), 6);
      default: return 0.985 + NP.noise1(t * 30 + s) * 0.015;
    }
  }

  /* ---------------- doors ---------------- */
  L.doors = {};
  class Door {
    constructor(def) {
      Object.assign(this, def);
      this.open = !!def.startOpen; this.t = this.open ? 1 : 0; this.locked = !!def.lock; this.speed = def.kind === 'heavy' ? 0.45 : def.kind === 'shutter' ? 0.38 : def.kind === 'slide' ? 1.4 : 1.8;
      const wx = L.isFloorish(this.x - 1, this.z) && L.isFloorish(this.x + 1, this.z);
      this.axis = wx ? 'x' : 'z'; // direction of passage
      this.center = L.center(this.x, this.z);
      this.width = def.kind === 'heavy' ? 1.9 : 1.4;
      this.h = def.kind === 'heavy' ? 2.5 : 2.25;
      this.meshes = []; this.monsterCanOpen = def.kind === 'hinged';
      this.swingDir = 1; this.slamT = 0;
    }
    blocking() { return this.t < 0.85; }
    setOpen(o, opts) {
      if (this.open === o) return;
      this.open = o;
      opts = opts || {};
      if (opts.slam) this.speed2 = 7; else this.speed2 = null;
      if (!opts.silent) NP.Bus.emit('door', { door: this, open: o, slam: !!opts.slam });
    }
    update(dt) {
      const target = this.open ? 1 : 0;
      const sp = this.speed2 || this.speed;
      if (this.t !== target) {
        this.t = target > this.t ? Math.min(1, this.t + dt * sp) : Math.max(0, this.t - dt * sp);
        if (this.t === target) { this.speed2 = null; NP.Bus.emit('doorDone', { door: this }); }
      }
      this.pose();
    }
    pose() {
      const k = NP.smooth(this.t);
      if (this.kind === 'hinged') this.pivot.rotation.y = this.swingDir * k * 1.75;
      else if (this.kind === 'slide') this.panel.position.x = -k * (this.width - 0.05);
      else if (this.kind === 'heavy') { this.panelL.position.x = -this.width / 4 - k * this.width / 2; this.panelR.position.x = this.width / 4 + k * this.width / 2; }
      else if (this.kind === 'shutter') this.panel.position.y = this.h / 2 + k * (this.h - 0.1);
      if (this.led) {
        const c = this.locked ? [1.6, 0.05, 0.03] : [0.1, 1.4, 0.35];
        this.led.material.color.setRGB(c[0], c[1], c[2]);
      }
    }
  }
  L.Door = Door;

  function buildDoor(def, scene) {
    const d = new Door(def);
    L.doors[d.id] = d;
    L.doorAtCell[d.z * W + d.x] = d;
    const g = new THREE.Group();
    g.position.copy(d.center);
    // local frame: door plane spans local X, passage along local Z
    if (d.axis === 'x') g.rotation.y = Math.PI / 2;
    scene.add(g); d.group = g;
    const frameKey = d.kind === 'heavy' || d.kind === 'shutter' ? 'p_yellow' : 'p_metal';
    const ch = L.ceilH(d.x, d.z);
    const jw = (C - d.width) / 2;
    const th = d.kind === 'heavy' ? 0.5 : 0.28;
    const mtx = new THREE.Matrix4();
    const cellIdx = d.z * W + d.x;
    const box = (w, h, dd, x, y, z, key) => { mtx.makeTranslation(x, y, z); mtx.premultiply(g.matrixWorld); L.addStatic(new THREE.BoxGeometry(w, h, dd), mtx, key, cellIdx); };
    g.updateMatrixWorld(true);
    box(jw, ch, th, -C / 2 + jw / 2, ch / 2, 0, frameKey);
    box(jw, ch, th, C / 2 - jw / 2, ch / 2, 0, frameKey);
    box(d.width, ch - d.h, th, 0, d.h + (ch - d.h) / 2, 0, frameKey);
    // collision for jambs (world AABB)
    const hw = C / 2, ht = th / 2;
    if (d.axis === 'z') {
      L.addBox(d.center.x - hw, d.center.z - ht, d.center.x - hw + jw, d.center.z + ht, 3);
      L.addBox(d.center.x + hw - jw, d.center.z - ht, d.center.x + hw, d.center.z + ht, 3);
      d.slab = [d.center.x - hw, d.center.z - 0.14, d.center.x + hw, d.center.z + 0.14];
    } else {
      L.addBox(d.center.x - ht, d.center.z - hw, d.center.x + ht, d.center.z - hw + jw, 3);
      L.addBox(d.center.x - ht, d.center.z + hw - jw, d.center.x + ht, d.center.z + hw, 3);
      d.slab = [d.center.x - 0.14, d.center.z - hw, d.center.x + 0.14, d.center.z + hw];
    }
    // moving panels
    const doorMat = d.kind === 'hinged' ? L.dynMat('p_green') : d.kind === 'slide' ? L.dynMat('p_metal') : L.dynMat('p_steel', { color: 0x8a8f90 });
    d.mat = doorMat;
    if (d.kind === 'hinged') {
      d.pivot = new THREE.Group(); d.pivot.position.set(-d.width / 2, 0, 0); g.add(d.pivot);
      const p = new THREE.Mesh(new THREE.BoxGeometry(d.width - 0.04, d.h - 0.02, 0.06), doorMat);
      p.position.set(d.width / 2, d.h / 2, 0); d.pivot.add(p); d.panel = p;
      // window slot + handle
      const win = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 0.5), NP.Level.glassMat);
      win.position.set(d.width / 2 + 0.25, 1.55, 0.032); d.pivot.add(win);
      const win2 = win.clone(); win2.rotation.y = Math.PI; win2.position.z = -0.032; d.pivot.add(win2);
      const hnd = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, 0.12), L.dynMat('p_steel'));
      hnd.position.set(d.width - 0.18, 1.0, 0); d.pivot.add(hnd);
      d.meshes.push(p, hnd);
    } else if (d.kind === 'slide') {
      const p = new THREE.Mesh(new THREE.BoxGeometry(d.width, d.h, 0.1), doorMat);
      p.position.set(0, d.h / 2, 0); g.add(p); d.panel = p; d.meshes.push(p);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(d.width * 0.98, 0.18, 0.11), L.dynMat('p_yellow'));
      stripe.position.y = -0.2; p.add(stripe);
      const win = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 0.11), NP.Level.glassMat); win.position.y = 0.4; p.add(win);
    } else if (d.kind === 'heavy') {
      for (const s of [-1, 1]) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(d.width / 2, d.h, 0.22), doorMat);
        p.position.set(s * d.width / 4, d.h / 2, 0); g.add(p); d.meshes.push(p);
        const hz = new THREE.Mesh(new THREE.BoxGeometry(d.width / 2 - 0.05, 0.3, 0.24), L.dynMat('p_yellow'));
        hz.position.y = -d.h / 2 + 0.3; p.add(hz);
        const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.26, 10), L.dynMat('p_steel'));
        bolt.rotation.x = Math.PI / 2; bolt.position.set(-s * 0.2, 0.4, 0); p.add(bolt);
        if (s < 0) d.panelL = p; else d.panelR = p;
      }
    } else if (d.kind === 'shutter') {
      const p = new THREE.Mesh(new THREE.BoxGeometry(d.width, d.h, 0.12), L.dynMat('p_rust'));
      p.position.y = d.h / 2; g.add(p); d.panel = p; d.meshes.push(p);
    }
    d.meshes.forEach((m) => { m.castShadow = true; m.receiveShadow = true; m.userData.door = d; });
    // status LED + reader on both faces
    if (d.lock || d.kind !== 'hinged') {
      d.led = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, th + 0.04), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
      d.led.position.set(d.width / 2 + 0.22, 1.75, 0); g.add(d.led);
      if (d.lock === 'L1' || d.lock === 'L2' || d.lock === 'keypad' || d.lock === 'fuse') {
        const r = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.24, th + 0.08), L.dynMat('p_dark'));
        r.position.set(d.width / 2 + 0.22, 1.35, 0); g.add(r); d.reader = r; r.userData.door = d;
      }
    }
    // sign above door
    if (d.label && d.kind !== 'shutter') {
      const sgTex = NP.Tex.sign(d.label.toUpperCase(), d.lock === 'L1' ? 'ACCESS LEVEL 1' : d.lock === 'L2' ? 'ACCESS LEVEL 2' : d.lock === 'keypad' ? 'CODE REQUIRED' : null);
      const sm = new THREE.MeshStandardMaterial({ map: sgTex, roughness: 0.7, emissive: 0xffffff, emissiveMap: sgTex, emissiveIntensity: 0.05 });
      for (const s of [-1, 1]) {
        const sg = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.225), sm);
        sg.position.set(0, d.h + 0.18, s * (th / 2 + 0.01)); sg.rotation.y = s < 0 ? Math.PI : 0;
        if (d.h + 0.3 < ch) g.add(sg);
      }
    }
    d.pose();
    return d;
  }

  /* ---------------- collision boxes ---------------- */
  L.boxes = []; L.boxBuckets = new Map();
  L.addBox = function (x0, z0, x1, z1, top) {
    const b = { x0: Math.min(x0, x1), z0: Math.min(z0, z1), x1: Math.max(x0, x1), z1: Math.max(z0, z1), top: top == null ? 3 : top };
    L.boxes.push(b);
    const gx0 = Math.floor(b.x0 / C), gx1 = Math.floor(b.x1 / C), gz0 = Math.floor(b.z0 / C), gz1 = Math.floor(b.z1 / C);
    for (let gz = gz0; gz <= gz1; gz++) for (let gx = gx0; gx <= gx1; gx++) {
      const k = gz * W + gx; if (!L.boxBuckets.has(k)) L.boxBuckets.set(k, []); L.boxBuckets.get(k).push(b);
    }
    return b;
  };
  const _out = [];
  L.boxesNear = function (x, z, r, who) {
    _out.length = 0;
    const gx0 = Math.floor((x - r) / C) - 1, gx1 = Math.floor((x + r) / C) + 1, gz0 = Math.floor((z - r) / C) - 1, gz1 = Math.floor((z + r) / C) + 1;
    for (let gz = gz0; gz <= gz1; gz++) for (let gx = gx0; gx <= gx1; gx++) {
      const c = L.ch(gx, gz);
      if (c === '#' || c === 'M' || c === 'G') _out.push({ x0: gx * C, z0: gz * C, x1: gx * C + C, z1: gz * C + C, top: 99 });
      const bl = L.boxBuckets.get(gz * W + gx); if (bl) for (const b of bl) if (!b.disabled && (!who || !b.playerOnly)) _out.push(b);
      const d = L.doorAtCell[gz * W + gx];
      if (d && d.blocking()) _out.push({ x0: d.slab[0], z0: d.slab[1], x1: d.slab[2], z1: d.slab[3], top: 99 });
    }
    return _out;
  };

  /* circle vs boxes resolve (xz). returns corrected position in-place */
  L.collideCircle = function (p, r, who) {
    for (let it = 0; it < 3; it++) {
      const bs = L.boxesNear(p.x, p.z, r, who);
      let moved = false;
      for (const b of bs) {
        const cx = NP.clamp(p.x, b.x0, b.x1), cz = NP.clamp(p.z, b.z0, b.z1);
        let dx = p.x - cx, dz = p.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 < r * r) {
          if (d2 < 1e-8) { // centre inside box: push out along least penetration
            const l = p.x - b.x0, rr = b.x1 - p.x, u = p.z - b.z0, dd = b.z1 - p.z;
            const m = Math.min(l, rr, u, dd);
            if (m === l) p.x = b.x0 - r; else if (m === rr) p.x = b.x1 + r; else if (m === u) p.z = b.z0 - r; else p.z = b.z1 + r;
          } else {
            const d = Math.sqrt(d2), push = r - d;
            p.x += (dx / d) * push; p.z += (dz / d) * push;
          }
          moved = true;
        }
      }
      if (!moved) break;
    }
    return p;
  };

  /* ---------------- line of sight (grid DDA) ---------------- */
  function cellBlocks(gx, gz, mode) {
    const c = L.ch(gx, gz);
    if (c === '#' || c === 'M') return true;
    if (c === 'G') return mode === 'move';
    if (c === '+') {
      const d = L.doorAtCell[gz * W + gx];
      if (mode === 'light') return true;
      return d ? d.t < 0.5 : false;
    }
    return false;
  }
  L.los = function (ax, az, bx, bz, mode) {
    let gx = Math.floor(ax / C), gz = Math.floor(az / C);
    const tx = Math.floor(bx / C), tz = Math.floor(bz / C);
    const dx = bx - ax, dz = bz - az;
    const sx = Math.sign(dx), sz = Math.sign(dz);
    const tdx = sx ? Math.abs(C / dx) : Infinity, tdz = sz ? Math.abs(C / dz) : Infinity;
    let tmx = sx > 0 ? ((gx + 1) * C - ax) / dx : sx < 0 ? (gx * C - ax) / dx : Infinity;
    let tmz = sz > 0 ? ((gz + 1) * C - az) / dz : sz < 0 ? (gz * C - az) / dz : Infinity;
    let n = 0;
    while ((gx !== tx || gz !== tz) && n++ < 120) {
      if (tmx < tmz) { tmx += tdx; gx += sx; } else { tmz += tdz; gz += sz; }
      if ((gx !== tx || gz !== tz) && cellBlocks(gx, gz, mode)) return false;
    }
    return true;
  };

  /* ---------------- build level geometry ---------------- */
  L.glassMat = new THREE.MeshStandardMaterial({ color: 0x1a2426, roughness: 0.05, metalness: 0.6, transparent: true, opacity: 0.35, depthWrite: false });

  function aoFloorFn(gx, gz) {
    const x0 = gx * C, z0 = gz * C;
    const sw = L.isSolid(gx - 1, gz) || (L.ch(gx - 1, gz) === '+' && L.ch(gx, gz) !== '+'), se = L.isSolid(gx + 1, gz), sn = L.isSolid(gx, gz - 1), ss = L.isSolid(gx, gz + 1);
    return (x, y, z) => {
      let d = 9;
      if (sw) d = Math.min(d, x - x0); if (se) d = Math.min(d, x0 + C - x); if (sn) d = Math.min(d, z - z0); if (ss) d = Math.min(d, z0 + C - z);
      return 0.5 + 0.5 * NP.smooth(NP.clamp(d / 0.9, 0, 1));
    };
  }

  L.build = function (scene) {
    L.scene = scene;
    const cellIdx = (x, z) => z * W + x;
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (let gz = 0; gz < H; gz++) for (let gx = 0; gx < W; gx++) {
      if (!L.isFloorish(gx, gz)) continue;
      const zk = L.zoneKey(gx, gz); if (!zk) continue;
      const Z = L.ZONES[zk];
      const h = L.ceilH(gx, gz);
      const ci = cellIdx(gx, gz);
      const x0 = gx * C, z0 = gz * C;
      const isGlass = L.ch(gx, gz) === 'G';
      // floor & ceiling
      quadN('floor_' + Z.floor, [x0, 0, z0], [1, 0, 0], [0, 0, 1], C, C, [0, 1, 0], ci, aoFloorFn(gx, gz), 2, 2);
      quadN('ceil_' + Z.ceil, [x0, h, z0], [1, 0, 0], [0, 0, 1], C, C, [0, -1, 0], ci, aoFloorFn(gx, gz), 2, 2);
      // walls
      for (const [dx, dz] of dirs) {
        const nx = gx + dx, nz = gz + dz;
        let y0 = null, y1 = h;
        if (L.isSolid(nx, nz)) y0 = 0;
        else { const nh = L.ceilH(nx, nz); if (nh < h - 0.01) y0 = nh; }
        if (y0 === null) continue;
        const n = [-dx, 0, -dz];
        let o, a;
        if (dx === 1) { o = [x0 + C, y0, z0]; a = [0, 0, 1]; }
        else if (dx === -1) { o = [x0, y0, z0]; a = [0, 0, 1]; }
        else if (dz === 1) { o = [x0, y0, z0 + C]; a = [1, 0, 0]; }
        else { o = [x0, y0, z0]; a = [1, 0, 0]; }
        const hh = y1 - y0;
        const segV = Math.max(1, Math.ceil(hh / 1.1));
        const key = 'wall_' + (L.ch(gx, gz) === '+' ? 'concrete' : Z.wall);
        const ao = (x, y) => (0.55 + 0.45 * NP.smooth(NP.clamp(y / 0.7, 0, 1))) * (0.75 + 0.25 * NP.smooth(NP.clamp((h - y) / 0.5, 0, 1)));
        quadN(key, o, a, [0, 1, 0], C, hh, n, ci, ao, 3, segV);
        // skirting / baseboard on room walls
        if (y0 === 0 && !isGlass && L.ch(gx, gz) !== '+' && zk !== 't' && zk !== 'c') {
          const len = C;
          const g = new THREE.BoxGeometry(dx ? 0.04 : len, 0.12, dx ? len : 0.04);
          const m = new THREE.Matrix4().makeTranslation(o[0] + a[0] * len / 2 + n[0] * 0.02, 0.06, o[2] + a[2] * len / 2 + n[2] * 0.02);
          L.addStatic(g, m, 'p_dark', ci);
        }
      }
      if (isGlass) {
        // sill + glass pane + header
        const horiz = L.isFloorish(gx, gz - 1) && L.isFloorish(gx, gz + 1); // pane plane along x
        const c = L.center(gx, gz);
        const mk = (w, hh, y) => {
          const g = horiz ? new THREE.BoxGeometry(C, hh, w) : new THREE.BoxGeometry(w, hh, C);
          L.addStatic(g, new THREE.Matrix4().makeTranslation(c.x, y, c.z), 'p_metal', ci);
        };
        mk(0.4, 0.95, 0.475); mk(0.4, h - 2.45, 2.45 + (h - 2.45) / 2);
        const pane = new THREE.Mesh(new THREE.PlaneGeometry(C, 1.5), L.glassMat);
        pane.position.set(c.x, 1.7, c.z); if (!horiz) pane.rotation.y = Math.PI / 2;
        pane.userData.glass = true;
        scene.add(pane); L.glassPanes = (L.glassPanes || []); L.glassPanes.push(pane);
        // mullion
        L.addStatic(horiz ? new THREE.BoxGeometry(0.08, 1.5, 0.12) : new THREE.BoxGeometry(0.12, 1.5, 0.08), new THREE.Matrix4().makeTranslation(c.x + (horiz ? C / 2 - 0.04 : 0), 1.7, c.z + (horiz ? 0 : C / 2 - 0.04)), 'p_metal', ci);
      }
    }
    DOORS.forEach((d) => buildDoor(d, scene));
  };

  /* ---------------- baking ---------------- */
  L.groups = [];
  L.finalize = function (scene) {
    // fixture housings first so they get baked too
    buildFixtureVisuals(scene);
    for (const key in batches) {
      const B = batches[key];
      if (!B.idx.length) continue;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(B.pos, 3));
      g.setAttribute('normal', new THREE.Float32BufferAttribute(B.nor, 3));
      g.setAttribute('uv', new THREE.Float32BufferAttribute(B.uv, 2));
      const nv = B.pos.length / 3;
      const col = new Float32Array(nv * 3);
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      g.setIndex(B.idx.length > 65535 ? new THREE.Uint32BufferAttribute(B.idx, 1) : new THREE.Uint16BufferAttribute(B.idx, 1));
      if (nv > 65535 && !(g.index instanceof THREE.Uint32BufferAttribute)) g.setIndex(new THREE.Uint32BufferAttribute(B.idx, 1));
      g.computeBoundingSphere();
      const mesh = new THREE.Mesh(g, L.mat(key));
      mesh.receiveShadow = true;
      mesh.castShadow = key.startsWith('p_');
      mesh.matrixAutoUpdate = false;
      scene.add(mesh);
      const grp = { key, mesh, col, nv, pos: B.pos, nor: B.nor, cell: B.cell, ao: B.ao, contrib: {}, buckets: new Map() };
      grp.amb = new Float32Array(nv * 3);
      for (let i = 0; i < nv; i++) {
        const c = B.cell[i]; if (!grp.buckets.has(c)) grp.buckets.set(c, []); grp.buckets.get(c).push(i);
        const zk = L.zoneKey(c % W, Math.floor(c / W));
        const a = zk ? L.ZONES[zk].amb : [0.008, 0.008, 0.01];
        grp.amb[i * 3] = a[0] * B.ao[i]; grp.amb[i * 3 + 1] = a[1] * B.ao[i]; grp.amb[i * 3 + 2] = a[2] * B.ao[i];
      }
      L.groups.push(grp);
    }
    bakeAll();
    L.applyLighting(true);
  };

  function bakeAll() {
    const t0 = performance.now();
    for (const f of L.fixtures) if (f.bake) bakeFixture(f);
    NP.Bus.emit('baked', { ms: performance.now() - t0 });
  }
  function bakeFixture(f) {
    const R = f.range, rc = Math.ceil(R / C);
    const [lx, lz] = L.cellOf(f.x, f.z);
    // light position nudged into the floor cell it illuminates
    const lpx = f.x - f.n[0] * 0.05, lpz = f.z - f.n[2] * 0.05;
    for (const grp of L.groups) {
      let arr = null;
      for (let gz = lz - rc; gz <= lz + rc; gz++) for (let gx = lx - rc; gx <= lx + rc; gx++) {
        const list = grp.buckets.get(gz * W + gx); if (!list) continue;
        const ccx = (gx + 0.5) * C, ccz = (gz + 0.5) * C;
        for (const i of list) {
          const px = grp.pos[i * 3], py = grp.pos[i * 3 + 1], pz = grp.pos[i * 3 + 2];
          let dx = f.x - px, dy = f.y - py, dz = f.z - pz;
          const d2 = dx * dx + dy * dy + dz * dz;
          if (d2 > R * R) continue;
          const d = Math.sqrt(d2) || 1e-3;
          dx /= d; dy /= d; dz /= d;
          const ndl = grp.nor[i * 3] * dx + grp.nor[i * 3 + 1] * dy + grp.nor[i * 3 + 2] * dz;
          // emitter facing (wall lamps shine away from wall)
          const emit = Math.max(0.15, -(f.n[0] * dx + f.n[1] * dy + f.n[2] * dz));
          let diff = Math.max(0, ndl) * 0.85 + 0.12;
          const fall = f.intensity / (1 + d2 / 3.2) * NP.smooth(NP.clamp((R - d) / (R * 0.45), 0, 1)) * emit;
          if (fall < 0.002) continue;
          const sx = px + (ccx - px) * 0.08, sz = pz + (ccz - pz) * 0.08;
          if (!L.los(sx, sz, lpx, lpz, 'light')) { diff = 0.03; }
          const v = fall * diff * grp.ao[i];
          if (!arr) { arr = grp.contrib[f.circuit] || (grp.contrib[f.circuit] = new Float32Array(grp.nv * 3)); }
          arr[i * 3] += f.color[0] * v; arr[i * 3 + 1] += f.color[1] * v; arr[i * 3 + 2] += f.color[2] * v;
        }
      }
    }
  }

  L.applyLighting = function () {
    for (const grp of L.groups) {
      const col = grp.col;
      col.set(grp.amb);
      for (const c in grp.contrib) {
        const lv = L.circuits[c] || 0; if (lv <= 0.001) continue;
        const arr = grp.contrib[c];
        for (let i = 0; i < col.length; i++) col[i] += arr[i] * lv;
      }
      grp.mesh.geometry.attributes.color.needsUpdate = true;
    }
    NP.Bus.emit('lighting');
  };
  L.setCircuit = function (name, level, fade) {
    if (!(name in L.circuits)) { L.circuits[name] = 0; }
    L.circuitTarget[name] = level;
    if (!fade) { L.circuits[name] = level; L._dirty = true; }
  };
  L.circuitFade = 0;
  L.updateCircuits = function (dt) {
    let changed = L._dirty; L._dirty = false;
    for (const c in L.circuitTarget) {
      const t = L.circuitTarget[c];
      if (Math.abs(L.circuits[c] - t) > 0.001) { L.circuits[c] = NP.damp(L.circuits[c], t, 3, dt); if (Math.abs(L.circuits[c] - t) < 0.01) L.circuits[c] = t; changed = true; }
    }
    if (changed) { L.circuitFade += dt; if (L.circuitFade > 0.12 || L._force) { L.circuitFade = 0; L.applyLighting(); } }
  };
  L.forceApply = () => L.applyLighting();

  // sample baked irradiance at a world point (for dynamic objects)
  L.sampleLight = function (p) {
    const out = [0, 0, 0];
    for (const f of L.fixtures) {
      if (!f.bake) continue;
      const lv = L.circuits[f.circuit] || 0; if (lv < 0.01) continue;
      const d2 = f.pos.distanceToSquared(p); if (d2 > f.range * f.range) continue;
      if (!L.los(p.x, p.z, f.x, f.z, 'light')) continue;
      const v = lv * f.intensity / (1 + d2 / 3.2) * 0.55;
      out[0] += f.color[0] * v; out[1] += f.color[1] * v; out[2] += f.color[2] * v;
    }
    return out;
  };

  /* ---------------- fixture visuals (instanced emissive parts) ---------------- */
  L.emitters = {};
  function buildFixtureVisuals(scene) {
    const byKind = {};
    for (const f of L.fixtures) (byKind[f.kind] = byKind[f.kind] || []).push(f);
    const geos = {
      fluor: new THREE.BoxGeometry(1.15, 0.035, 0.16),
      emer: new THREE.BoxGeometry(0.26, 0.12, 0.05),
      cage: new THREE.SphereGeometry(0.07, 10, 8),
      beacon: new THREE.SphereGeometry(0.11, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2),
      bulb: new THREE.SphereGeometry(0.06, 10, 8),
      strip: new THREE.BoxGeometry(2.2, 0.03, 0.08),
    };
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1);
    for (const kind in byKind) {
      const list = byKind[kind];
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const im = new THREE.InstancedMesh(geos[kind], mat, list.length);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      list.forEach((f, i) => {
        // orientation: wall-mounted fixtures face along n
        const yaw = Math.atan2(f.n[0], f.n[2]);
        q.setFromEuler(new THREE.Euler(0, f.n[1] !== 0 ? (f.rotY || 0) : yaw, 0));
        m4.compose(f.pos, q, s); im.setMatrixAt(i, m4);
        im.setColorAt(i, new THREE.Color(0, 0, 0));
        f.inst = im; f.instIdx = i;
        // housings into static batch
        const ci = L.cellOf(f.x, f.z); const cidx = ci[1] * W + ci[0];
        const hm = new THREE.Matrix4().compose(new THREE.Vector3(f.x, f.y + (kind === 'fluor' ? 0.035 : 0), f.z), q, s);
        if (kind === 'fluor') L.addStatic(new THREE.BoxGeometry(1.3, 0.06, 0.32), hm, 'p_white', cidx);
        else if (kind === 'emer') { const off = new THREE.Matrix4().makeTranslation(0, 0, -0.04); L.addStatic(new THREE.BoxGeometry(0.34, 0.2, 0.06), hm.clone().multiply(off), 'p_dark', cidx); }
        else if (kind === 'cage') { const off = new THREE.Matrix4().makeTranslation(0, 0.1, 0); L.addStatic(new THREE.CylinderGeometry(0.1, 0.12, 0.08, 8), hm.clone().multiply(off), 'p_dark', cidx); }
        else if (kind === 'beacon') { L.addStatic(new THREE.CylinderGeometry(0.13, 0.13, 0.06, 10), hm, 'p_dark', cidx); }
      });
      im.frustumCulled = false;
      scene.add(im);
      L.emitters[kind] = im;
    }
  }

  /* per-frame fixture brightness; returns list for the dynamic light pool */
  const _c = new THREE.Color();
  L.updateFixtures = function (t) {
    const dirty = new Set();
    for (const f of L.fixtures) {
      const lv = L.circuits[f.circuit] || 0;
      let b = lv > 0.001 ? lv * flickerVal(f, t) : 0;
      if (f.override != null) b = f.override;
      b *= L.bakeUniform.value;
      f.cur = b;
      if (f.inst) {
        const k = f.kind === 'emer' || f.kind === 'beacon' ? 6 : f.kind === 'fluor' || f.kind === 'strip' ? 5 : 4;
        _c.setRGB(f.color[0] * b * k, f.color[1] * b * k, f.color[2] * b * k);
        f.inst.setColorAt(f.instIdx, _c); dirty.add(f.inst);
      }
    }
    dirty.forEach((im) => { im.instanceColor.needsUpdate = true; });
  };

  L.updateDoors = function (dt) { for (const id in L.doors) L.doors[id].update(dt); };
  L.DOOR_DEFS = DOORS;
})(window.NP);
