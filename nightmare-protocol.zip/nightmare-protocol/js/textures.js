/* NIGHTMARE PROTOCOL — procedural PBR textures (albedo + normal + roughness) generated on canvas */
'use strict';
(function (NP) {
  const TX = (NP.Tex = {});

  /* tileable value noise */
  function hash(x, y, seed) {
    let h = (x * 374761393 + y * 668265263 + seed * 2147483647) | 0;
    h = (h ^ (h >>> 13)) * 1274126177;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  function vnoise(x, y, period, seed) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    const x0 = ((xi % period) + period) % period, y0 = ((yi % period) + period) % period;
    const x1 = (x0 + 1) % period, y1 = (y0 + 1) % period;
    const a = hash(x0, y0, seed), b = hash(x1, y0, seed), c = hash(x0, y1, seed), d = hash(x1, y1, seed);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function fbm(u, v, base, oct, seed) {
    let s = 0, amp = 0.5, f = base, n = 0;
    for (let o = 0; o < oct; o++) { s += vnoise(u * f, v * f, f, seed + o * 17) * amp; n += amp; amp *= 0.5; f *= 2; }
    return s / n;
  }
  TX.fbm = fbm;

  function canvas(n) { const c = document.createElement('canvas'); c.width = c.height = n; return c; }

  /* Builds albedo/height/rough buffers from a per-pixel function and optional overlay painter. */
  function build(name, size, pixel, overlay, opts) {
    opts = opts || {};
    const N = size;
    const col = new Uint8ClampedArray(N * N * 4), hgt = new Float32Array(N * N), rgh = new Uint8ClampedArray(N * N * 4);
    const o = { r: 0, g: 0, b: 0, h: 0, ro: 0.8 };
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        o.r = o.g = o.b = 0.5; o.h = 0.5; o.ro = 0.8;
        pixel(x / N, y / N, o);
        const i = (y * N + x);
        col[i * 4] = o.r * 255; col[i * 4 + 1] = o.g * 255; col[i * 4 + 2] = o.b * 255; col[i * 4 + 3] = 255;
        hgt[i] = o.h;
        const rv = o.ro * 255; rgh[i * 4] = rv; rgh[i * 4 + 1] = rv; rgh[i * 4 + 2] = rv; rgh[i * 4 + 3] = 255;
      }
    }
    const cc = canvas(N), cx = cc.getContext('2d');
    cx.putImageData(new ImageData(col, N, N), 0, 0);
    // overlays paint into colour canvas and a height canvas that is then merged
    let hc = null;
    if (overlay) {
      hc = canvas(N);
      const hx = hc.getContext('2d');
      hx.fillStyle = '#808080'; hx.fillRect(0, 0, N, N);
      overlay(cx, hx, N);
      const hd = hx.getImageData(0, 0, N, N).data;
      for (let i = 0; i < N * N; i++) hgt[i] += (hd[i * 4] - 128) / 255;
    }
    // normal map via sobel on wrapped height
    const nc = canvas(N), nx = nc.getContext('2d'), nd = new Uint8ClampedArray(N * N * 4);
    const st = opts.normal || 2.5;
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const l = hgt[y * N + ((x - 1 + N) % N)], r = hgt[y * N + ((x + 1) % N)];
        const u = hgt[((y - 1 + N) % N) * N + x], d = hgt[((y + 1) % N) * N + x];
        let dx = (l - r) * st, dy = (u - d) * st, dz = 1 / 1;
        const len = Math.hypot(dx, dy, dz);
        dx /= len; dy /= len; dz /= len;
        const i = (y * N + x) * 4;
        nd[i] = (dx * 0.5 + 0.5) * 255; nd[i + 1] = (dy * 0.5 + 0.5) * 255; nd[i + 2] = (dz * 0.5 + 0.5) * 255; nd[i + 3] = 255;
      }
    }
    nx.putImageData(new ImageData(nd, N, N), 0, 0);
    const rc = canvas(N); rc.getContext('2d').putImageData(new ImageData(rgh, N, N), 0, 0);
    return { name, color: cc, normal: nc, rough: rc };
  }

  function tex(c, srgb, repeat) {
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    if (srgb) t.encoding = THREE.sRGBEncoding;
    t.anisotropy = NP.q().aniso;
    if (repeat) t.repeat.set(repeat, repeat);
    return t;
  }

  function crack(cx, hx, N, x, y, len, ang, w, colr) {
    cx.strokeStyle = colr || 'rgba(15,14,12,0.85)';
    hx.strokeStyle = 'rgba(0,0,0,0.9)';
    cx.lineWidth = w; hx.lineWidth = w * 1.6;
    cx.beginPath(); hx.beginPath();
    cx.moveTo(x, y); hx.moveTo(x, y);
    for (let i = 0; i < len; i++) {
      ang += (Math.random() - 0.5) * 0.9;
      x += Math.cos(ang) * 6; y += Math.sin(ang) * 6;
      cx.lineTo(x, y); hx.lineTo(x, y);
      if (Math.random() < 0.06 && w > 0.6) crack(cx, hx, N, x, y, len * 0.4, ang + (Math.random() - 0.5) * 2, w * 0.6, colr);
    }
    cx.stroke(); hx.stroke();
  }
  function stain(cx, x, y, r, rgba) {
    for (const ox of [-1, 0, 1]) for (const oy of [-1, 0, 1]) {
      const N = cx.canvas.width;
      const g = cx.createRadialGradient(x + ox * N, y + oy * N, 0, x + ox * N, y + oy * N, r);
      g.addColorStop(0, rgba); g.addColorStop(1, 'rgba(0,0,0,0)');
      cx.fillStyle = g; cx.fillRect(x + ox * N - r, y + oy * N - r, r * 2, r * 2);
    }
  }
  function drips(cx, N, count, rgba) {
    cx.strokeStyle = rgba;
    for (let i = 0; i < count; i++) {
      const x = Math.random() * N, len = N * (0.2 + Math.random() * 0.7);
      cx.lineWidth = 1 + Math.random() * 3;
      cx.beginPath(); cx.moveTo(x, 0); cx.lineTo(x + (Math.random() - 0.5) * 6, len); cx.stroke();
    }
  }

  /* ---------- texture recipes ---------- */
  const recipes = {
    concrete: (S) => build('concrete', S, (u, v, o) => {
      const n = fbm(u, v, 6, 5, 3), f = fbm(u, v, 40, 2, 9), p = fbm(u, v, 3, 3, 21);
      const b = 0.36 + n * 0.22 + f * 0.06 - (p > 0.62 ? (p - 0.62) * 0.6 : 0);
      o.r = b * 0.95; o.g = b * 0.97; o.b = b * 1.0;
      o.h = n * 0.6 + f * 0.4; o.ro = 0.88 - p * 0.2;
      if (hash((u * 512) | 0, (v * 512) | 0, 77) > 0.996) { o.r = o.g = o.b = b * 0.4; o.h -= 0.3; }
    }, (cx, hx, N) => {
      for (let i = 0; i < 5; i++) crack(cx, hx, N, Math.random() * N, Math.random() * N, 18, Math.random() * 6, 1.2);
      for (let i = 0; i < 4; i++) stain(cx, Math.random() * N, Math.random() * N, N * 0.2, 'rgba(30,26,18,0.25)');
      drips(cx, N, 10, 'rgba(25,22,16,0.18)');
    }, { normal: 3 }),

    tileFloor: (S) => build('tileFloor', S, (u, v, o) => {
      const t = 8, gu = (u * t) % 1, gv = (v * t) % 1;
      const grout = gu < 0.04 || gv < 0.04;
      const ti = Math.floor(u * t), tj = Math.floor(v * t);
      const tv = hash(ti, tj, 5) * 0.08;
      const dirt = fbm(u, v, 5, 4, 11);
      const b = grout ? 0.16 : 0.5 + tv - dirt * 0.28;
      o.r = b * 0.92; o.g = b * 0.96; o.b = b * 0.94;
      o.h = grout ? 0.1 : 0.6 + fbm(u, v, 30, 2, 2) * 0.1;
      o.ro = grout ? 0.95 : 0.35 + dirt * 0.45;
      if (!grout && hash(ti, tj, 99) > 0.93) { o.r *= 0.6; o.g *= 0.62; o.b *= 0.6; o.h -= 0.15; } // broken tile
    }, (cx, hx, N) => {
      for (let i = 0; i < 6; i++) crack(cx, hx, N, Math.random() * N, Math.random() * N, 10, Math.random() * 6, 0.9);
      for (let i = 0; i < 6; i++) stain(cx, Math.random() * N, Math.random() * N, N * 0.12, 'rgba(40,34,20,0.3)');
    }, { normal: 4 }),

    tileWall: (S) => build('tileWall', S, (u, v, o) => {
      const tu = 6, tvv = 10, gu = (u * tu) % 1, gv = (v * tvv) % 1;
      const grout = gu < 0.035 || gv < 0.05;
      const ti = Math.floor(u * tu), tj = Math.floor(v * tvv);
      const g = fbm(u, v, 4, 4, 41), low = Math.pow(v, 3);
      const b = grout ? 0.3 : 0.74 + hash(ti, tj, 3) * 0.06 - g * 0.25 - low * 0.25;
      o.r = b * 0.93; o.g = b * 0.98; o.b = b * 0.95;
      o.h = grout ? 0.15 : 0.62; o.ro = grout ? 0.9 : 0.22 + g * 0.3;
      if (!grout && hash(ti, tj, 17) > 0.95) { o.h = 0.3; o.r = o.g = o.b = 0.32; o.ro = 0.9; } // missing tile
    }, (cx, hx, N) => {
      drips(cx, N, 18, 'rgba(70,60,30,0.22)');
      for (let i = 0; i < 4; i++) crack(cx, hx, N, Math.random() * N, Math.random() * N, 12, Math.random() * 6, 0.8);
      stain(cx, Math.random() * N, N * 0.9, N * 0.35, 'rgba(50,45,25,0.35)');
    }, { normal: 3 }),

    paint: (S) => build('paint', S, (u, v, o) => {
      const peel = fbm(u, v, 5, 5, 61), g = fbm(u, v, 3, 4, 7), low = Math.pow(v, 2.5);
      const peeled = peel > 0.6;
      if (peeled) { const b = 0.3 + g * 0.1; o.r = b; o.g = b * 0.98; o.b = b * 0.95; o.h = 0.25; o.ro = 0.95; }
      else { const b = 0.55 - g * 0.18 - low * 0.18; o.r = b * 0.78; o.g = b * 0.86; o.b = b * 0.8; o.h = 0.6 + (peel > 0.56 ? 0.15 : 0); o.ro = 0.6; }
    }, (cx, hx, N) => {
      drips(cx, N, 14, 'rgba(60,50,30,0.2)');
      for (let i = 0; i < 3; i++) crack(cx, hx, N, Math.random() * N, Math.random() * N, 20, Math.PI / 2, 1);
    }, { normal: 3 }),

    metal: (S) => build('metal', S, (u, v, o) => {
      const rust = fbm(u, v, 4, 5, 13), sc = fbm(u * 1, v * 30, 2, 3, 5);
      const r = rust > 0.55 ? (rust - 0.55) * 2.2 : 0;
      const plateU = (u * 2) % 1, plateV = (v * 2) % 1;
      const seam = plateU < 0.012 || plateV < 0.012;
      const rivet = (Math.hypot(plateU - 0.05, plateV - 0.05) < 0.012) || (Math.hypot(plateU - 0.95, plateV - 0.05) < 0.012);
      const b = 0.36 + sc * 0.1;
      o.r = NP.lerp(b, 0.36, r); o.g = NP.lerp(b * 1.02, 0.2, r); o.b = NP.lerp(b * 1.06, 0.1, r);
      o.h = seam ? 0.2 : rivet ? 0.95 : 0.55 + r * 0.25;
      o.ro = NP.lerp(0.45, 0.9, r);
    }, null, { normal: 4 }),

    grate: (S) => build('grate', S, (u, v, o) => {
      const t = 16, gu = (u * t) % 1, gv = (v * t) % 1;
      const bar = gu < 0.25 || gv < 0.25;
      const rust = fbm(u, v, 4, 4, 31);
      if (bar) { const b = 0.32; o.r = NP.lerp(b, 0.34, rust); o.g = NP.lerp(b, 0.2, rust); o.b = NP.lerp(b * 1.05, 0.12, rust); o.h = 0.8; o.ro = 0.45 + rust * 0.4; }
      else { o.r = o.g = o.b = 0.04; o.h = 0.0; o.ro = 1; }
    }, null, { normal: 6 }),

    ceiling: (S) => build('ceiling', S, (u, v, o) => {
      const t = 4, gu = (u * t) % 1, gv = (v * t) % 1;
      const frame = gu < 0.03 || gv < 0.03;
      const g = fbm(u, v, 8, 4, 91), stn = fbm(u, v, 3, 4, 92);
      const b = frame ? 0.22 : 0.52 - g * 0.12 - (stn > 0.58 ? (stn - 0.58) * 1.6 : 0);
      o.r = b; o.g = b * 0.97; o.b = b * 0.88;
      o.h = frame ? 0.2 : 0.55 + g * 0.2; o.ro = 0.9;
      const ti = Math.floor(u * t), tj = Math.floor(v * t);
      if (!frame && hash(ti, tj, 44) > 0.88) { o.r = o.g = o.b = 0.05; o.h = 0; } // missing panel
    }, null, { normal: 3 }),

    lino: (S) => build('lino', S, (u, v, o) => {
      const g = fbm(u, v, 6, 5, 71), sc = fbm(u * 1, v * 1, 40, 2, 72);
      const b = 0.42 - g * 0.18 + sc * 0.05;
      o.r = b * 0.85; o.g = b * 0.95; o.b = b * 0.9;
      o.h = 0.5 + sc * 0.15; o.ro = 0.4 + g * 0.4;
    }, (cx, hx, N) => {
      for (let i = 0; i < 8; i++) stain(cx, Math.random() * N, Math.random() * N, N * 0.15, 'rgba(45,35,20,0.3)');
      for (let i = 0; i < 3; i++) crack(cx, hx, N, Math.random() * N, Math.random() * N, 14, Math.random() * 6, 1);
    }, { normal: 2 }),

    labPanel: (S) => build('labPanel', S, (u, v, o) => {
      const pu = (u * 2) % 1, pv = (v * 1) % 1;
      const seam = pu < 0.01 || pv < 0.01 || Math.abs(pv - 0.5) < 0.004;
      const g = fbm(u, v, 4, 4, 81);
      const b = seam ? 0.2 : 0.62 - g * 0.15;
      o.r = b * 0.9; o.g = b * 0.96; o.b = b; o.h = seam ? 0.1 : 0.6; o.ro = seam ? 0.8 : 0.3 + g * 0.3;
    }, (cx) => { drips(cx, cx.canvas.width, 8, 'rgba(40,40,30,0.18)'); }, { normal: 3 }),

    skin: (S) => build('skin', S, (u, v, o) => {
      const g = fbm(u, v, 6, 5, 101), vein = Math.abs(fbm(u, v, 5, 4, 102) - 0.5);
      const b = 0.3 + g * 0.12;
      o.r = b * 0.92; o.g = b * 0.94; o.b = b * 0.86;
      if (vein < 0.02) { o.r *= 0.55; o.g *= 0.62; o.b *= 0.75; }
      o.h = g + (vein < 0.025 ? 0.2 : 0); o.ro = 0.48 + g * 0.3;
    }, null, { normal: 5 }),
  };

  TX.cache = {};
  TX.get = function (name) {
    if (TX.cache[name]) return TX.cache[name];
    const S = NP.settings.quality === 'low' ? 256 : 512;
    const t0 = performance.now();
    const b = recipes[name](S);
    TX.cache[name] = { map: tex(b.color, true), normalMap: tex(b.normal, false), roughnessMap: tex(b.rough, false) };
    NP.Bus.emit('texgen', { name, ms: performance.now() - t0 });
    return TX.cache[name];
  };

  /* ---------- decal / sign / document textures ---------- */
  TX.canvasTex = function (w, h, draw, srgb = true) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c);
    if (srgb) t.encoding = THREE.sRGBEncoding;
    t.anisotropy = NP.q().aniso;
    return t;
  };

  TX.bloodDecal = function (seed) {
    return TX.canvasTex(256, 256, (cx, w, h) => {
      const r = NP.makeRng(seed);
      cx.fillStyle = 'rgba(0,0,0,0)'; cx.clearRect(0, 0, w, h);
      for (let i = 0; i < 14; i++) {
        const x = w / 2 + r.range(-60, 60), y = h / 2 + r.range(-60, 60), rad = r.range(8, 50);
        const g = cx.createRadialGradient(x, y, 0, x, y, rad);
        g.addColorStop(0, 'rgba(48,6,6,0.9)'); g.addColorStop(0.7, 'rgba(36,4,4,0.7)'); g.addColorStop(1, 'rgba(20,2,2,0)');
        cx.fillStyle = g; cx.beginPath(); cx.arc(x, y, rad, 0, 7); cx.fill();
      }
      for (let i = 0; i < 30; i++) { cx.fillStyle = 'rgba(40,5,5,0.8)'; cx.beginPath(); cx.arc(r.range(10, w - 10), r.range(10, h - 10), r.range(1, 4), 0, 7); cx.fill(); }
    });
  };
  TX.puddle = function (seed) {
    return TX.canvasTex(256, 256, (cx, w, h) => {
      const r = NP.makeRng(seed);
      cx.clearRect(0, 0, w, h);
      for (let i = 0; i < 9; i++) {
        const x = w / 2 + r.range(-50, 50), y = h / 2 + r.range(-50, 50), rad = r.range(30, 80);
        const g = cx.createRadialGradient(x, y, 0, x, y, rad);
        g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.8, 'rgba(255,255,255,0.9)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        cx.fillStyle = g; cx.beginPath(); cx.arc(x, y, rad, 0, 7); cx.fill();
      }
    }, false);
  };
  TX.footprints = function () {
    return TX.canvasTex(128, 512, (cx, w, h) => {
      cx.clearRect(0, 0, w, h);
      for (let i = 0; i < 6; i++) {
        const y = h - 40 - i * 80, x = i % 2 ? 40 : 88;
        cx.save(); cx.translate(x, y); cx.rotate((i % 2 ? -0.1 : 0.1));
        cx.fillStyle = `rgba(30,6,6,${0.85 - i * 0.12})`;
        // elongated, unnatural footprint: long toes
        cx.beginPath(); cx.ellipse(0, 0, 11, 26, 0, 0, 7); cx.fill();
        for (let t = 0; t < 4; t++) { cx.beginPath(); cx.ellipse(-12 + t * 8, -38 - (t % 2) * 6, 3, 10, (t - 1.5) * 0.15, 0, 7); cx.fill(); }
        cx.restore();
      }
    });
  };
  TX.sign = function (text, sub, opt) {
    opt = opt || {};
    return TX.canvasTex(512, 128, (cx, w, h) => {
      cx.fillStyle = opt.bg || '#1b2421'; cx.fillRect(0, 0, w, h);
      cx.strokeStyle = opt.edge || '#55605a'; cx.lineWidth = 6; cx.strokeRect(6, 6, w - 12, h - 12);
      cx.fillStyle = opt.fg || '#c9d3c4';
      cx.font = '700 58px "Big Shoulders Stencil Display", Impact, sans-serif';
      cx.textBaseline = 'middle';
      cx.fillText(text, 26, sub ? 50 : 66);
      if (sub) { cx.font = '500 26px "IBM Plex Mono", monospace'; cx.fillStyle = opt.sub || '#8a978e'; cx.fillText(sub, 28, 98); }
      // grime
      for (let i = 0; i < 40; i++) { cx.fillStyle = `rgba(0,0,0,${Math.random() * 0.25})`; cx.fillRect(Math.random() * w, Math.random() * h, Math.random() * 60, Math.random() * 8); }
    });
  };
  TX.scrawl = function (text, w = 512, h = 256, size = 150) {
    return TX.canvasTex(w, h, (cx) => {
      cx.clearRect(0, 0, w, h);
      cx.font = `700 ${size}px "Big Shoulders Stencil Display", Impact, sans-serif`;
      cx.textAlign = 'center'; cx.textBaseline = 'middle';
      cx.fillStyle = 'rgba(70,6,6,0.92)';
      cx.save(); cx.translate(w / 2, h / 2); cx.rotate(-0.06); cx.fillText(text, 0, 0); cx.restore();
      drips(cx, w, 22, 'rgba(60,5,5,0.5)');
    });
  };
  TX.paper = function (lines) {
    return TX.canvasTex(256, 330, (cx, w, h) => {
      cx.fillStyle = '#c9c3b0'; cx.fillRect(0, 0, w, h);
      for (let i = 0; i < 10; i++) stain(cx, Math.random() * w, Math.random() * h, 40, 'rgba(110,90,50,0.25)');
      cx.fillStyle = '#2b2a28'; cx.font = '600 15px "IBM Plex Mono", monospace';
      (lines || []).forEach((l, i) => cx.fillText(l, 18, 34 + i * 20));
      cx.fillStyle = 'rgba(40,40,40,0.5)';
      for (let i = 0; i < 9; i++) cx.fillRect(18, 120 + i * 18, 150 + Math.random() * 60, 3);
    });
  };
  TX.screen = function (lines, color) {
    return TX.canvasTex(512, 320, (cx, w, h) => {
      cx.fillStyle = '#020604'; cx.fillRect(0, 0, w, h);
      cx.fillStyle = color || '#5fe08a'; cx.font = '500 22px "IBM Plex Mono", monospace';
      (lines || []).forEach((l, i) => cx.fillText(l, 20, 40 + i * 30));
      for (let y = 0; y < h; y += 3) { cx.fillStyle = 'rgba(0,0,0,0.35)'; cx.fillRect(0, y, w, 1); }
    });
  };
  TX.softDot = function () {
    return TX.canvasTex(64, 64, (cx, w, h) => {
      const g = cx.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.4, 'rgba(255,255,255,0.35)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      cx.fillStyle = g; cx.fillRect(0, 0, w, h);
    }, false);
  };
  TX.smoke = function () {
    return TX.canvasTex(128, 128, (cx, w, h) => {
      const id = cx.createImageData(w, h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const d = Math.hypot(x - 64, y - 64) / 64;
        const n = fbm(x / w, y / h, 4, 4, 7);
        const a = Math.max(0, 1 - d) ** 1.6 * (0.4 + n * 0.9);
        const i = (y * w + x) * 4;
        id.data[i] = id.data[i + 1] = id.data[i + 2] = 255; id.data[i + 3] = a * 255;
      }
      cx.putImageData(id, 0, 0);
    }, false);
  };
})(window.NP);
