/* NIGHTMARE PROTOCOL — post-processing pipeline + particle systems */
'use strict';
(function (NP) {
  const FX = (NP.FX = {});
  const quadGeo = new THREE.PlaneGeometry(2, 2);
  const VS = 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.0,1.0); }';

  FX.u = {
    tScene: { value: null }, tDepth: { value: null }, tBloom: { value: null },
    uRes: { value: new THREE.Vector2(1, 1) }, uTime: { value: 0 },
    uExposure: { value: 1.0 }, uVignette: { value: 0.55 }, uChroma: { value: 0.0015 }, uGrain: { value: 0.05 },
    uDistort: { value: 0 }, uFlash: { value: new THREE.Vector3(0, 0, 0) }, uFade: { value: 0 },
    uDof: { value: 0 }, uFocus: { value: 3 }, uBloomStr: { value: 0.6 }, uSat: { value: 0.82 },
    uNear: { value: 0.05 }, uFar: { value: 120 }, uAO: { value: 0 }, uBlur: { value: 0 }, uLowHP: { value: 0 },
    uTint: { value: new THREE.Vector3(1, 1, 1) }, uGamma: { value: 1.0 }, uSlats: { value: 0 },
  };

  const COMPOSITE = `
precision highp float;
varying vec2 vUv;
uniform sampler2D tScene, tDepth, tBloom;
uniform vec2 uRes; uniform float uTime, uExposure, uVignette, uChroma, uGrain, uDistort, uFade, uDof, uFocus, uBloomStr, uSat, uNear, uFar, uAO, uBlur, uLowHP, uGamma, uSlats;
uniform vec3 uFlash, uTint;
float lin(float d){ float z=d*2.0-1.0; return (2.0*uNear*uFar)/(uFar+uNear-z*(uFar-uNear)); }
float h(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }
vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0); }
vec3 sampleScene(vec2 uv, float ca){
  vec2 d = (uv-0.5);
  float r = texture2D(tScene, uv + d*ca).r;
  float g = texture2D(tScene, uv).g;
  float b = texture2D(tScene, uv - d*ca).b;
  return vec3(r,g,b);
}
void main(){
  vec2 uv = vUv;
  // scare distortion: wave + tearing
  if(uDistort>0.001){
    float tear = step(0.96, h(vec2(floor(uv.y*42.0), floor(uTime*24.0))));
    uv.x += (sin(uv.y*60.0+uTime*40.0)*0.004 + tear*(h(vec2(uTime))-0.5)*0.08)*uDistort;
    uv += (vec2(h(uv+uTime),h(uv-uTime))-0.5)*0.004*uDistort;
  }
  float ca = uChroma + uDistort*0.02 + uLowHP*0.004;
  vec3 col = sampleScene(uv, ca);
  float dc = texture2D(tDepth, uv).r;
  float zc = lin(dc);
  // depth of field (scripted scenes) / blur
  float coc = clamp(abs(zc-uFocus)/max(uFocus,0.5),0.0,1.0)*uDof + uBlur;
  if(coc>0.01){
    vec3 acc = col; float wsum = 1.0;
    for(int i=0;i<12;i++){
      float a = float(i)*2.39996; float r = (float(i)+1.0)/12.0;
      vec2 o = vec2(cos(a),sin(a))*r*coc*9.0/uRes;
      acc += texture2D(tScene, uv+o).rgb; wsum += 1.0;
    }
    col = acc/wsum;
  }
  // screen-space contact shadows (depth-based AO approximation)
  if(uAO>0.0){
    float occ=0.0;
    float rad = clamp(14.0/zc, 1.5, 22.0);
    for(int i=0;i<8;i++){
      float a = float(i)*0.785398 + h(uv*uRes)*0.785;
      vec2 o = vec2(cos(a),sin(a))*rad*(0.5+0.5*fract(float(i)*0.618))/uRes;
      float zs = lin(texture2D(tDepth, uv+o).r);
      float dz = zc - zs;
      occ += smoothstep(0.03,0.25,dz) * (1.0-smoothstep(0.6,1.4,dz));
    }
    col *= 1.0 - uAO*clamp(occ/8.0,0.0,1.0)*0.75;
  }
  col += texture2D(tBloom, uv).rgb * uBloomStr;
  col *= uExposure * uTint;
  col = aces(col);
  // grade: desaturate + cold shadows
  float l = dot(col, vec3(0.2126,0.7152,0.0722));
  col = mix(vec3(l), col, uSat);
  col = mix(col, col*vec3(0.86,0.95,1.08), (1.0-smoothstep(0.0,0.45,l))*0.6);
  col = pow(col, vec3(1.0/2.2)) ;
  col = pow(col, vec3(1.0/uGamma));
  // flash overlay (rgb = colour * amount)
  col += uFlash;
  // vignette
  vec2 vd = vUv-0.5; float v = 1.0 - dot(vd,vd)*uVignette*2.2 - uLowHP*dot(vd,vd)*3.0;
  col *= clamp(v,0.0,1.0);
  // locker slats
  if(uSlats>0.0){ float s = smoothstep(0.35,0.5,abs(fract(vUv.y*9.0)-0.5)); col *= mix(1.0, 0.03 + 0.97*(1.0-s), uSlats); col *= mix(1.0, 1.0-smoothstep(0.25,0.55,abs(vUv.x-0.5)), uSlats); }
  // film grain + scanline flicker
  float g = h(vUv*uRes + fract(uTime*7.13)*100.0) - 0.5;
  col += g*uGrain;
  col *= 1.0 - uFade;
  gl_FragColor = vec4(col,1.0);
}`;

  const BRIGHT = `varying vec2 vUv; uniform sampler2D tScene; uniform float uThresh;
void main(){ vec3 c = texture2D(tScene, vUv).rgb; float l = max(c.r,max(c.g,c.b)); gl_FragColor = vec4(c*smoothstep(uThresh, uThresh+0.8, l), 1.0); }`;
  const BLUR = `varying vec2 vUv; uniform sampler2D tIn; uniform vec2 uDir;
void main(){ vec3 s = texture2D(tIn, vUv).rgb*0.227;
 s += texture2D(tIn, vUv+uDir*1.385).rgb*0.316; s += texture2D(tIn, vUv-uDir*1.385).rgb*0.316;
 s += texture2D(tIn, vUv+uDir*3.231).rgb*0.07; s += texture2D(tIn, vUv-uDir*3.231).rgb*0.07;
 gl_FragColor = vec4(s,1.0); }`;

  FX.init = function (renderer) {
    this.renderer = renderer;
    const gl2 = renderer.capabilities.isWebGL2;
    const ext = renderer.extensions;
    this.hdr = gl2 ? (ext.get('EXT_color_buffer_float') || ext.get('EXT_color_buffer_half_float')) : ext.get('OES_texture_half_float') && ext.get('EXT_color_buffer_half_float');
    this.type = this.hdr ? THREE.HalfFloatType : THREE.UnsignedByteType;
    this.scene2 = new THREE.Scene(); this.cam2 = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.quad = new THREE.Mesh(quadGeo, null); this.quad.frustumCulled = false; this.scene2.add(this.quad);
    this.compMat = new THREE.ShaderMaterial({ uniforms: FX.u, vertexShader: VS, fragmentShader: COMPOSITE, depthTest: false, depthWrite: false });
    this.brightMat = new THREE.ShaderMaterial({ uniforms: { tScene: { value: null }, uThresh: { value: 1.0 } }, vertexShader: VS, fragmentShader: BRIGHT, depthTest: false });
    this.blurMat = new THREE.ShaderMaterial({ uniforms: { tIn: { value: null }, uDir: { value: new THREE.Vector2() } }, vertexShader: VS, fragmentShader: BLUR, depthTest: false });
    this.resize();
  };
  FX.resize = function () {
    const r = this.renderer, s = new THREE.Vector2(); r.getDrawingBufferSize(s);
    const w = Math.max(2, s.x), h = Math.max(2, s.y);
    [this.rt, this.b1, this.b2].forEach((t) => t && t.dispose());
    this.rt = new THREE.WebGLRenderTarget(w, h, { type: this.type, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true });
    this.rt.depthTexture = new THREE.DepthTexture(w, h); this.rt.depthTexture.type = THREE.UnsignedIntType;
    const bw = Math.max(2, w >> 2), bh = Math.max(2, h >> 2);
    this.b1 = new THREE.WebGLRenderTarget(bw, bh, { type: this.type, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false });
    this.b2 = this.b1.clone();
    FX.u.uRes.value.set(w, h);
    this.bw = bw; this.bh = bh;
  };
  FX.pass = function (mat, target) { this.quad.material = mat; this.renderer.setRenderTarget(target); this.renderer.render(this.scene2, this.cam2); };
  FX.render = function (scene, camera) {
    const r = this.renderer, q = NP.q();
    FX.u.uNear.value = camera.near; FX.u.uFar.value = camera.far;
    r.setRenderTarget(this.rt); r.clear(); r.render(scene, camera);
    FX.u.tScene.value = this.rt.texture; FX.u.tDepth.value = this.rt.depthTexture;
    if (q.bloom) {
      this.brightMat.uniforms.tScene.value = this.rt.texture; this.brightMat.uniforms.uThresh.value = this.hdr ? 0.9 : 0.7;
      this.pass(this.brightMat, this.b1);
      for (let i = 0; i < 2; i++) {
        this.blurMat.uniforms.tIn.value = this.b1.texture; this.blurMat.uniforms.uDir.value.set((1 + i) / this.bw, 0); this.pass(this.blurMat, this.b2);
        this.blurMat.uniforms.tIn.value = this.b2.texture; this.blurMat.uniforms.uDir.value.set(0, (1 + i) / this.bh); this.pass(this.blurMat, this.b1);
      }
      FX.u.tBloom.value = this.b1.texture; FX.u.uBloomStr.value = 0.55;
    } else { FX.u.tBloom.value = this.b1.texture; FX.u.uBloomStr.value = 0; }
    FX.u.uAO.value = q.ssao ? 1 : 0;
    this.pass(this.compMat, null);
  };

  /* transient effects driven per frame */
  FX.state = { distort: 0, flash: new THREE.Vector3(), flashDecay: 4, fade: 0, fadeTarget: 0, fadeRate: 2, dof: 0, dofTarget: 0, blur: 0, blurTarget: 0 };
  FX.distort = (amt) => { FX.state.distort = Math.max(FX.state.distort, amt); };
  FX.flash = (r, g, b, decay) => { FX.state.flash.set(r, g, b); FX.state.flashDecay = decay || 4; };
  FX.fadeTo = (v, rate) => { FX.state.fadeTarget = v; FX.state.fadeRate = rate || 2; };
  FX.setFade = (v) => { FX.state.fade = FX.state.fadeTarget = v; };
  FX.dof = (v, focus) => { FX.state.dofTarget = v; if (focus) FX.u.uFocus.value = focus; };
  FX.blur = (v) => { FX.state.blurTarget = v; };
  FX.update = function (dt) {
    const s = FX.state, u = FX.u;
    u.uTime.value += dt;
    s.distort = Math.max(0, s.distort - dt * 1.6); u.uDistort.value = s.distort;
    s.flash.multiplyScalar(Math.exp(-s.flashDecay * dt)); u.uFlash.value.copy(s.flash);
    s.fade = NP.damp(s.fade, s.fadeTarget, s.fadeRate * 2, dt); if (Math.abs(s.fade - s.fadeTarget) < 0.002) s.fade = s.fadeTarget; u.uFade.value = s.fade;
    s.dof = NP.damp(s.dof, s.dofTarget, 3, dt); u.uDof.value = s.dof;
    s.blur = NP.damp(s.blur, s.blurTarget, 3, dt); u.uBlur.value = s.blur;
    u.uGamma.value = NP.settings.brightness;
  };

  /* ================= PARTICLES ================= */
  const PVS = `attribute float aSize; attribute float aAlpha; varying float vA; uniform float uScale;
void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); gl_PointSize = aSize*uScale/max(-mv.z,0.1); vA=aAlpha; gl_Position = projectionMatrix*mv; }`;
  const PFS = `uniform sampler2D uMap; uniform vec3 uColor; varying float vA; void main(){ vec4 t = texture2D(uMap, gl_PointCoord); gl_FragColor = vec4(uColor*t.rgb, t.a*vA); }`;

  class Emitter {
    constructor(scene, max, opts) {
      this.max = max; this.o = Object.assign({ color: [1, 1, 1], additive: false, map: NP.Tex.softDot() }, opts);
      this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
      this.size = new Float32Array(max); this.alpha = new Float32Array(max); this.baseSize = new Float32Array(max);
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('aAlpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
      this.mat = new THREE.ShaderMaterial({ uniforms: { uMap: { value: this.o.map }, uColor: { value: new THREE.Vector3(...this.o.color) }, uScale: { value: 600 } }, vertexShader: PVS, fragmentShader: PFS, transparent: true, depthWrite: false, blending: this.o.additive ? THREE.AdditiveBlending : THREE.NormalBlending });
      this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; this.points.renderOrder = 6;
      scene.add(this.points); this.geo = g; this.n = 0;
    }
    spawn(x, y, z, vx, vy, vz, life, size) {
      let i = -1;
      for (let k = 0; k < this.max; k++) if (this.life[k] <= 0) { i = k; break; }
      if (i < 0) return;
      this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
      this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
      this.life[i] = this.maxLife[i] = life; this.baseSize[i] = size;
    }
    update(dt) {
      const o = this.o;
      for (let i = 0; i < this.max; i++) {
        if (this.life[i] <= 0) { this.alpha[i] = 0; this.size[i] = 0; continue; }
        this.life[i] -= dt;
        const k = 1 - this.life[i] / this.maxLife[i];
        this.vel[i * 3 + 1] += (o.gravity || 0) * dt;
        const dr = o.drag || 0; if (dr) { this.vel[i * 3] *= 1 - dr * dt; this.vel[i * 3 + 1] *= 1 - dr * dt; this.vel[i * 3 + 2] *= 1 - dr * dt; }
        this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
        if (o.floor && this.pos[i * 3 + 1] < 0.02) { this.pos[i * 3 + 1] = 0.02; this.vel[i * 3 + 1] *= -0.3; this.vel[i * 3] *= 0.5; this.vel[i * 3 + 2] *= 0.5; }
        this.size[i] = this.baseSize[i] * (o.grow ? 1 + k * o.grow : 1);
        this.alpha[i] = (o.alpha || 1) * Math.sin(Math.min(1, k) * Math.PI) * (o.fadeIn === false ? (1 - k) * 2 : 1);
      }
      this.geo.attributes.position.needsUpdate = true; this.geo.attributes.aSize.needsUpdate = true; this.geo.attributes.aAlpha.needsUpdate = true;
      this.mat.uniforms.uScale.value = FX.renderer ? FX.renderer.getDrawingBufferSize(new THREE.Vector2()).y * 0.9 : 600;
    }
  }
  FX.Emitter = Emitter;

  FX.initParticles = function (scene, camera) {
    const q = NP.q();
    this.scene = scene; this.camera = camera;
    // steam / smoke
    this.smoke = new Emitter(scene, Math.floor(q.particles * 0.35), { map: NP.Tex.smoke(), color: [0.55, 0.6, 0.62], alpha: 0.22, grow: 2.2, drag: 0.6 });
    // sparks
    this.sparks = new Emitter(scene, 120, { color: [6, 3.2, 1.2], additive: true, gravity: -9, floor: true, alpha: 1, fadeIn: false });
    this.vents = []; this.sparkPoints = [];
    // dust motes that only glow inside the flashlight beam
    const N = Math.floor(q.particles * 0.7);
    const dp = new Float32Array(N * 3), ds = new Float32Array(N);
    for (let i = 0; i < N; i++) { dp[i * 3] = (Math.random() - 0.5) * 12; dp[i * 3 + 1] = Math.random() * 3; dp[i * 3 + 2] = (Math.random() - 0.5) * 12; ds[i] = Math.random(); }
    const dg = new THREE.BufferGeometry(); dg.setAttribute('position', new THREE.BufferAttribute(dp, 3)); dg.setAttribute('aSeed', new THREE.BufferAttribute(ds, 1));
    this.dustMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uCam: { value: new THREE.Vector3() }, uDir: { value: new THREE.Vector3() }, uI: { value: 0 }, uT: { value: 0 }, uScale: { value: 600 } },
      vertexShader: `attribute float aSeed; uniform vec3 uCam; uniform vec3 uDir; uniform float uI; uniform float uT; uniform float uScale; varying float vB;
void main(){ vec3 p = position; p.x += sin(uT*0.13+aSeed*40.0)*0.4; p.y += sin(uT*0.09+aSeed*20.0)*0.3; p.z += cos(uT*0.11+aSeed*30.0)*0.4;
 vec3 rel = mod(p - uCam + vec3(6.0,0.0,6.0), vec3(12.0,3.2,12.0)) - vec3(6.0,0.0,6.0);
 vec3 w = vec3(uCam.x+rel.x, rel.y+0.05, uCam.z+rel.z);
 vec3 d = w-uCam; float dist = length(d); float c = dot(d/dist, uDir);
 vB = uI*smoothstep(0.88,0.97,c)*(1.0-smoothstep(1.0,9.0,dist))*(0.4+0.6*fract(aSeed*7.0)) + 0.025;
 vec4 mv = modelViewMatrix*vec4(w,1.0); gl_PointSize = (1.2+aSeed*1.6)*uScale*0.012/max(-mv.z,0.2)*3.0; gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `varying float vB; void main(){ vec2 c=gl_PointCoord-0.5; float a = 1.0-smoothstep(0.2,0.5,length(c)); gl_FragColor = vec4(vec3(1.0,0.95,0.85)*vB*a, 1.0); }`,
    });
    this.dust = new THREE.Points(dg, this.dustMat); this.dust.frustumCulled = false; this.dust.renderOrder = 7;
    scene.add(this.dust);
    // fog sprites
    this.fogs = [];
    const fogMat = new THREE.SpriteMaterial({ map: NP.Tex.smoke(), color: 0x6f7a80, transparent: true, opacity: 0.06, depthWrite: false });
    this.fogMat = fogMat;
    FX.fogZones = [];
  };
  FX.addFogZone = function (x0, z0, x1, z1, y0, y1, count, op) {
    const q = NP.q();
    const n = Math.max(1, Math.round(count * q.fogSprites / 36));
    for (let i = 0; i < n; i++) {
      const s = new THREE.Sprite(this.fogMat.clone());
      s.material.opacity = (op || 0.07) * (0.5 + Math.random() * 0.8);
      s.material.rotation = Math.random() * 6;
      const sc = 2.5 + Math.random() * 3; s.scale.set(sc, sc, 1);
      s.position.set(x0 + Math.random() * (x1 - x0), y0 + Math.random() * (y1 - y0), z0 + Math.random() * (z1 - z0));
      s.userData = { b: s.position.clone(), sp: 0.1 + Math.random() * 0.2, ph: Math.random() * 6, op: s.material.opacity };
      s.renderOrder = 4;
      this.scene.add(s); this.fogs.push(s);
    }
  };
  FX.addVent = function (pos, dir, rate, size) { this.vents.push({ pos, dir: dir || new THREE.Vector3(0, 1, 0), rate: rate || 6, size: size || 0.7, acc: 0, on: true }); };
  FX.addSparkPoint = function (pos, chance) { this.sparkPoints.push({ pos, chance: chance || 0.08, t: Math.random() * 5 }); };
  FX.burstSparks = function (pos, n) {
    for (let i = 0; i < (n || 20); i++) this.sparks.spawn(pos.x, pos.y, pos.z, (Math.random() - 0.5) * 4, Math.random() * 3, (Math.random() - 0.5) * 4, 0.4 + Math.random() * 0.6, 0.04 + Math.random() * 0.03);
    NP.Audio && NP.Audio.spark(pos);
    if (FX.eventLight) { FX.eventLight.position.copy(pos); FX.eventLight.intensity = 3; FX.eventLight.color.setRGB(1, 0.6, 0.25); }
  };
  FX.burstSmoke = function (pos, n, spread) {
    for (let i = 0; i < (n || 20); i++) this.smoke.spawn(pos.x + (Math.random() - 0.5) * (spread || 0.4), pos.y, pos.z + (Math.random() - 0.5) * (spread || 0.4), (Math.random() - 0.5) * 1.2, -0.4 - Math.random() * 0.8, (Math.random() - 0.5) * 1.2, 2.2 + Math.random() * 1.5, 0.8 + Math.random() * 0.7);
  };
  FX.updateParticles = function (dt, camera) {
    const P = NP.Player;
    for (const v of this.vents) {
      if (!v.on) continue;
      if (camera.position.distanceTo(v.pos) > 22) continue;
      v.acc += dt * v.rate;
      while (v.acc > 1) {
        v.acc -= 1;
        this.smoke.spawn(v.pos.x + (Math.random() - 0.5) * 0.2, v.pos.y, v.pos.z + (Math.random() - 0.5) * 0.2, v.dir.x * 1.2 + (Math.random() - 0.5) * 0.4, v.dir.y * 1.2 + Math.random() * 0.3, v.dir.z * 1.2 + (Math.random() - 0.5) * 0.4, 2 + Math.random() * 1.5, v.size * (0.6 + Math.random() * 0.6));
      }
    }
    for (const s of this.sparkPoints) {
      s.t -= dt;
      if (s.t <= 0) { s.t = 1 + Math.random() * 4; if (Math.random() < s.chance * 6 && camera.position.distanceTo(s.pos) < 18) FX.burstSparks(s.pos, 10 + Math.random() * 14); }
    }
    this.smoke.update(dt); this.sparks.update(dt);
    if (FX.eventLight) FX.eventLight.intensity *= Math.exp(-dt * 9);
    const t = NP.Timers.time;
    for (const f of this.fogs) {
      const u = f.userData;
      f.position.x = u.b.x + Math.sin(t * u.sp + u.ph) * 0.8; f.position.z = u.b.z + Math.cos(t * u.sp * 0.8 + u.ph) * 0.8;
      f.material.rotation += dt * 0.03;
      // fade sprites that get too close to the camera (prevents flat card look)
      const d = f.position.distanceTo(camera.position);
      f.material.opacity = u.op * NP.smooth(NP.clamp((d - 1.0) / 2.5, 0, 1));
    }
    // dust
    this.dustMat.uniforms.uCam.value.copy(camera.position);
    this.dustMat.uniforms.uDir.value.set(0, 0, -1).applyQuaternion(camera.quaternion);
    this.dustMat.uniforms.uI.value = P && P.light ? P.light.flick * 0.9 : 0;
    this.dustMat.uniforms.uT.value = t;
    this.dustMat.uniforms.uScale.value = this.smoke.mat.uniforms.uScale.value;
  };
})(window.NP);
