/* NIGHTMARE PROTOCOL — UI: menus, settings, HUD, prompts, subtitles, documents, keypad, terminal, death/ending */
'use strict';
(function (NP) {
  const UI = (NP.UI = {});
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  UI.init = function () {
    this.el = {
      hud: $('#hud'), prompt: $('#prompt'), promptText: $('#prompt .t'), cross: $('#cross'), toast: $('#toast'), sub: $('#subtitle'),
      obj: $('#objective'), objText: $('#objective .txt'), objSub: $('#objective .sub'), loc: $('#location'),
      bat: $('#battery'), batSegs: $$('#battery .seg'), batSpare: $('#battery .spare'), stam: $('#stamina'), stamFill: $('#stamina i'),
      timer: $('#timer'), doc: $('#doc'), keypad: $('#keypad'), term: $('#terminal'), hideV: $('#hidevig'),
    };
    // menu buttons
    $$('[data-act]').forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); NP.Audio.init(); NP.Audio.click(0.6); NP.Game.menuAction(b.dataset.act, b); }));
    this.bindSettings();
    $$('#keypad [data-k]').forEach((b) => b.addEventListener('click', () => UI.keypadInput(b.dataset.k)));
    $('#doc').addEventListener('click', () => UI.closeModal());
    // ticker on the menu
    const lines = ['EMERGENCY BROADCAST 03:12 — ALL STAFF EVACUATE SUB-LEVEL 4', 'GENERATOR RESERVE: 0%', 'CONTAINMENT CELL 0: STATUS UNKNOWN', 'IF YOU CAN HEAR THIS, DO NOT FALL ASLEEP', 'ANCHORS 1–11: SEDATED · ANCHOR 12: —'];
    let li = 0; setInterval(() => { const t = $('#ticker'); if (t) { t.textContent = lines[li++ % lines.length]; t.classList.remove('in'); void t.offsetWidth; t.classList.add('in'); } }, 4200);
  };

  UI.screen = function (name) {
    $$('.screen').forEach((s) => { s.hidden = s.id !== 'scr-' + name; });
    this.el.hud.hidden = !(name === 'play');
    this.current = name;
  };
  UI.overlay = function (id, on) { const e = $('#' + id); if (e) e.hidden = !on; };

  /* ---------------- HUD ---------------- */
  UI.prompt = function (txt) {
    if (txt === this._p) return; this._p = txt;
    if (txt) { this.el.promptText.textContent = txt; this.el.prompt.classList.add('on'); this.el.cross.classList.add('on'); }
    else { this.el.prompt.classList.remove('on'); this.el.cross.classList.remove('on'); }
  };
  UI.toast = function (txt, dur) {
    const t = this.el.toast; t.textContent = txt; t.classList.add('on');
    clearTimeout(this._tt); this._tt = setTimeout(() => t.classList.remove('on'), (dur || 3.2) * 1000);
  };
  UI.subtitle = function (txt, who, dur) {
    if (!NP.settings.subtitles) return;
    const s = this.el.sub; s.innerHTML = ''; const w = document.createElement('b'); w.textContent = who ? who + ' ' : ''; s.appendChild(w); s.appendChild(document.createTextNode(txt));
    s.classList.add('on'); clearTimeout(this._st); this._st = setTimeout(() => s.classList.remove('on'), (dur || 4) * 1000);
  };
  UI.objective = function (txt, sub) {
    const changed = txt !== this._obj;
    this._obj = txt; this.el.objText.textContent = txt; this.el.objSub.textContent = sub || ''; this.el.objSub.hidden = !sub;
    if (changed) { this.el.obj.classList.remove('flash'); void this.el.obj.offsetWidth; this.el.obj.classList.add('flash'); this.el.obj.classList.remove('min'); clearTimeout(this._om); this._om = setTimeout(() => { if (!NP.settings.showObjective) this.el.obj.classList.add('min'); }, 6000); }
  };
  UI.toggleObjective = function () { NP.settings.showObjective = !NP.settings.showObjective; NP.saveSettings(); this.el.obj.classList.toggle('min', !NP.settings.showObjective); };
  UI.location = function (name, sub) {
    const l = this.el.loc; l.querySelector('.n').textContent = name; l.querySelector('.s').textContent = sub || '';
    l.classList.remove('on'); void l.offsetWidth; l.classList.add('on');
  };
  UI.timer = function (s) { const t = this.el.timer; if (s == null) { t.hidden = true; return; } t.hidden = false; t.textContent = (s < 10 ? '0' : '') + Math.ceil(s) + 's'; t.classList.toggle('crit', s < 10); };
  UI.hud = function (P) {
    const l = P.light;
    this.el.bat.hidden = !l.owned;
    if (l.owned) {
      const n = Math.ceil(l.battery * 5);
      this.el.batSegs.forEach((s, i) => { s.classList.toggle('on', i < n); s.classList.toggle('low', n <= 1); });
      this.el.batSpare.textContent = '× ' + l.spares;
      this.el.bat.classList.toggle('off', !l.on);
    }
    const st = P.stamina;
    this.el.stam.classList.toggle('on', st < 0.995);
    this.el.stamFill.style.transform = 'scaleX(' + st.toFixed(3) + ')';
    this.el.stam.classList.toggle('ex', P.exhausted);
    this.el.hideV.hidden = !P.hidden;
  };

  /* ---------------- documents ---------------- */
  UI.readDoc = function (d) {
    if (!d) return;
    const e = this.el.doc;
    e.querySelector('h2').textContent = d.title;
    e.querySelector('.body').textContent = d.body;
    e.querySelector('.tag').textContent = d.evidence ? 'Evidence ' + d.evidence + ' of 3' : d.tape ? 'Audio transcript' : 'Document';
    e.hidden = false; this.modal = 'doc';
    NP.Player.frozen = true;
  };
  UI.closeModal = function () {
    if (!this.modal) return false;
    if (this.modal === 'doc') this.el.doc.hidden = true;
    if (this.modal === 'keypad') this.el.keypad.hidden = true;
    if (this.modal === 'term') { this.el.term.hidden = true; }
    this.modal = null; NP.Player.frozen = false;
    return true;
  };

  /* ---------------- keypad (keyboard digits, or click when the pointer is free) ---------------- */
  UI.keypad = function (onSubmit) {
    const e = this.el.keypad; const disp = e.querySelector('.disp');
    this.kp = { code: '', onSubmit, busy: false };
    disp.textContent = '— — — —'; disp.className = 'disp';
    e.hidden = false; this.modal = 'keypad'; NP.Player.frozen = true;
  };
  UI.keypadInput = function (k) {
    const kp = this.kp; if (!kp || kp.busy) return;
    const disp = this.el.keypad.querySelector('.disp');
    if (k === 'C') kp.code = '';
    else if (k === '<') kp.code = kp.code.slice(0, -1);
    else if (/^[0-9]$/.test(k) && kp.code.length < 4) kp.code += k;
    NP.Audio.beep('key');
    const btn = this.el.keypad.querySelector('[data-k="' + k + '"]'); if (btn) { btn.classList.add('hit'); setTimeout(() => btn.classList.remove('hit'), 120); }
    disp.textContent = (kp.code + '____').slice(0, 4).split('').join(' ');
    if (kp.code.length === 4) {
      kp.busy = true;
      setTimeout(() => {
        const ok = kp.onSubmit(kp.code);
        disp.classList.add(ok ? 'ok' : 'bad');
        setTimeout(() => { if (ok) UI.closeModal(); else { kp.code = ''; kp.busy = false; disp.className = 'disp'; disp.textContent = '— — — —'; } }, ok ? 600 : 700);
      }, 200);
    }
  };

  /* ---------------- terminal ---------------- */
  UI.terminal = function (onSubmit) {
    const e = this.el.term; const inp = e.querySelector('.in'); const log = e.querySelector('.log');
    this.tm = { txt: '', onSubmit, tries: 0 };
    log.textContent = 'HALE INSTITUTE // RESEARCH NODE 3\nRESTRICTED. Enter the director\'s password.\nType, then press Enter. Esc to leave.\n';
    inp.textContent = '';
    e.hidden = false; this.modal = 'term'; NP.Player.frozen = true;
  };
  UI.termKey = function (ev) {
    const tm = this.tm, e = this.el.term, inp = e.querySelector('.in'), log = e.querySelector('.log');
    if (ev.key === 'Enter') {
      const ok = tm.onSubmit(tm.txt);
      log.textContent += '\n> ' + '*'.repeat(tm.txt.length) + (ok ? '\nACCESS GRANTED' : '\nACCESS DENIED');
      if (!ok && ++tm.tries >= 2) log.textContent += '\nHINT: the director reuses the first subject\'s name.';
      tm.txt = ''; inp.textContent = '';
      if (ok) setTimeout(() => UI.closeModal(), 500);
      return;
    }
    if (ev.key === 'Backspace') tm.txt = tm.txt.slice(0, -1);
    else if (ev.key.length === 1 && /[a-zA-Z0-9]/.test(ev.key) && tm.txt.length < 16) tm.txt += ev.key.toUpperCase();
    else return;
    NP.Audio.beep('key');
    inp.textContent = tm.txt;
  };

  /* ---------------- settings ---------------- */
  UI.bindSettings = function () {
    const S = NP.settings;
    $$('#set-quality button').forEach((b) => b.addEventListener('click', () => { S.quality = b.dataset.q; NP.saveSettings(); UI.syncSettings(); UI.toast('Graphics quality applies when you start or load a game.'); NP.Game.applyQualityLive(); }));
    const rng = (id, key, fmt, cb) => {
      const el = $('#' + id); const out = $('#' + id + '-v');
      el.value = S[key]; out.textContent = fmt(S[key]);
      el.addEventListener('input', () => { S[key] = parseFloat(el.value); out.textContent = fmt(S[key]); NP.saveSettings(); if (cb) cb(S[key]); });
    };
    rng('set-sens', 'sensitivity', (v) => v.toFixed(2) + '×');
    rng('set-fov', 'fov', (v) => Math.round(v) + '°', (v) => NP.Game.setFov(v));
    rng('set-bright', 'brightness', (v) => Math.round(v * 100) + '%');
    rng('set-vol', 'volume', (v) => Math.round(v * 100) + '%', (v) => NP.Audio.setVolume(v));
    rng('set-mus', 'musicVolume', (v) => Math.round(v * 100) + '%', (v) => NP.Audio.setMusicVolume(v));
    const tog = (id, key) => { const el = $('#' + id); el.checked = !!S[key]; el.addEventListener('change', () => { S[key] = el.checked; NP.saveSettings(); }); };
    tog('set-invert', 'invertY'); tog('set-bob', 'headBob'); tog('set-subs', 'subtitles');
    $('#set-fs').addEventListener('click', () => NP.Game.toggleFullscreen());
    this.syncSettings();
  };
  UI.syncSettings = function () { $$('#set-quality button').forEach((b) => b.setAttribute('aria-pressed', b.dataset.q === NP.settings.quality ? 'true' : 'false')); };

  UI.setContinue = function (cp) {
    const b = $('[data-act="continue"]'); const s = b.querySelector('small');
    b.disabled = !cp; s.textContent = cp ? cp.label : 'No saved checkpoint';
  };
  UI.death = function (stats) { $('#death-cp').textContent = stats.cp; this.screen('death'); };
  UI.ending = function (st) {
    $('#end-time').textContent = st.time; $('#end-deaths').textContent = st.deaths; $('#end-scares').textContent = st.scares; $('#end-docs').textContent = st.docs;
    this.screen('ending');
  };
  UI.loading = function (txt, k) { $('#load-txt').textContent = txt; $('#load-bar i').style.transform = 'scaleX(' + (k || 0) + ')'; };
})(window.NP);
