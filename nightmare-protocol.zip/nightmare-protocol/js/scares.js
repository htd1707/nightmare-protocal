/* NIGHTMARE PROTOCOL — scare director: pacing (build → scare → recovery → escalate) + 28 scripted scare events */
'use strict';
(function (NP) {
  const L = NP.Level, C = L.C, V3 = THREE.Vector3;
  const S = (NP.Scares = { defs: [], done: new Set(), running: [], lastT: -999, lastInt: 0, tension: 0, log: [] });
  const at = (gx, gz, ox = 0, oz = 0, y = 0) => new V3((gx + 0.5) * C + ox, y, (gz + 0.5) * C + oz);
  const F = () => NP.Game.flags;
  const Pl = () => NP.Player;
  const T = () => NP.Timers.time;
  const zoneIs = (k) => { const p = Pl().pos; const [gx, gz] = L.cellOf(p.x, p.z); return L.zoneKey(gx, gz) === k; };
  const inRect = (x0, z0, x1, z1) => { const p = Pl().pos; const [gx, gz] = L.cellOf(p.x, p.z); return gx >= x0 && gx <= x1 && gz >= z0 && gz <= z1; };
  const dist = (p) => Math.hypot(p.x - Pl().pos.x, p.z - Pl().pos.z);
  const facing = (p, y = 1.3) => Pl().facingDot(new V3(p.x, y, p.z));
  const sees = (p, c = 0.55, y = 1.3) => Pl().canSee(new V3(p.x, y, p.z), c);

  /* recovery window after a scare scales with its intensity */
  const RECOVER = [0, 14, 22, 32];

  S.def = function (d) { this.defs.push(Object.assign({ once: true, intensity: 1, major: false, cooldown: 0, last: -999 }, d)); };

  /* ---------- helpers for scare choreography ---------- */
  const H = (S.H = {});
  H.show = (app, pos, yaw, state) => { app.place(pos.x, pos.z, yaw, pos.y || 0); app.root.rotation.x = 0; app.setState(state || 'stand'); app.setVisible(true); app.setFade(0, true); app.lookAt = null; app.snapPose(); return app; };
  H.hide = (app) => { app.setVisible(false); app.lookAt = null; app.root.rotation.x = 0; };
  H.lightsOut = (dur, opts) => {
    opts = opts || {};
    L.bakeUniform.value = opts.level || 0; Pl().interfere = Math.max(Pl().interfere || 0, dur);
    NP.Timers.after(dur, () => { L.bakeUniform.value = 1; }, 'lights');
  };
  H.flicker = (dur, rate) => {
    const n = Math.floor(dur * (rate || 9));
    for (let i = 0; i < n; i++) NP.Timers.after(i / (rate || 9), () => { L.bakeUniform.value = Math.random() < 0.5 ? 0.05 : 1; }, 'lights');
    NP.Timers.after(dur + 0.02, () => { L.bakeUniform.value = 1; }, 'lights');
    Pl().interfere = Math.max(Pl().interfere || 0, dur * 0.7);
  };
  H.jolt = (int) => { Pl().addShake(0.25 + int * 0.25, 0.35 + int * 0.15); NP.FX.distort(0.3 + int * 0.35); };
  H.behind = (d) => { const p = Pl(); return new V3(p.pos.x + Math.sin(p.yaw) * d, 0, p.pos.z + Math.cos(p.yaw) * d); };
  H.yawTo = (from, to) => Math.atan2(to.x - from.x, to.z - from.z);
  H.tween = (dur, fn, done) => NP.Tweens.add(dur, fn, done, 'scare');
  /* put the creature's head exactly `d` metres in front of the player's eyes, facing them, and light its face */
  H.placeFace = (a, d, state) => {
    const P = Pl(); const e = P.eyePos(new V3()); const f = P.forward(new V3()); f.y = 0; f.normalize();
    const tgt = e.clone().addScaledVector(f, d);
    H.show(a, new V3(tgt.x, 0, tgt.z), H.yawTo(tgt, e), state || 'attack');
    a.lookAt = e; a.snapPose(); a.root.updateMatrixWorld(true);
    const head = a.headPos(new V3());
    a.root.position.add(tgt.clone().sub(head));
    a.root.updateMatrixWorld(true);
    if (S.faceLight) { S.faceLight.position.copy(e).addScaledVector(f, d * 0.45).add(new V3(0, 0.3, 0)); S.faceLight.intensity = 4.5; }
    return { e, f };
  };
  H.faceLightOff = () => { if (S.faceLight) S.faceLight.intensity = 0; };

  /* a standalone long-fingered hand + forearm for doorframe / vent reveals */
  function makeHand(scene) {
    const sk = NP.Tex.get('skin');
    const mat = new THREE.MeshStandardMaterial({ map: sk.map, normalMap: sk.normalMap, color: 0x7d8077, roughness: 0.5 });
    const g = new THREE.Group();
    const fa = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.6, 8), mat); fa.rotation.z = Math.PI / 2; fa.position.x = -0.3; g.add(fa);
    const palm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.03, 0.08), mat); palm.position.x = 0.03; g.add(palm);
    const fingers = [];
    for (let i = 0; i < 4; i++) {
      const f1 = new THREE.Group(); f1.position.set(0.08, 0, (i - 1.5) * 0.022); g.add(f1);
      const m1 = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.007, 0.18, 6), mat); m1.rotation.z = -Math.PI / 2; m1.position.x = 0.09; f1.add(m1);
      const f2 = new THREE.Group(); f2.position.x = 0.18; f1.add(f2);
      const m2 = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.004, 0.14, 6), mat); m2.rotation.z = -Math.PI / 2; m2.position.x = 0.07; f2.add(m2);
      fingers.push([f1, f2]);
    }
    g.traverse((m) => { if (m.isMesh) m.castShadow = true; });
    g.visible = false; scene.add(g);
    return { g, fingers, curl(k) { fingers.forEach(([a, b], i) => { a.rotation.y = -k * (0.7 + i * 0.05); b.rotation.y = -k * 1.1; }); } };
  }

  /* ---------- per-frame scare tickers ---------- */
  S.tick = function (fn) { this.running.push(fn); };

  S.init = function (scene) {
    S.hand = makeHand(scene);
    S.faceLight = new THREE.PointLight(0xffd8c8, 0, 3.5, 2); scene.add(S.faceLight);
    const W = NP.World;
    const app = () => W.app;

    /* 0 — FIRST LEVEL: the moment you step out of the recovery room, it is right in your face */
    S.def({ id: 'first_exit', major: true, intensity: 3, cond: () => !NP.Game.introOn && zoneIs('r') && dist(at(8, 32)) < 5,
      run: () => {
        const a = app(), A = NP.Audio, P = Pl();
        // 1. the door slams behind you and the lights convulse
        const d = L.doors.recovery; if (d.open) d.setOpen(false, { slam: true }); else A.metal(d.center, 1.2, 0.8);
        P.addShake(0.5, 0.4); H.flicker(0.5, 16);
        // 2. total darkness and dead silence
        NP.Timers.after(0.5, () => { L.bakeUniform.value = 0; P.interfere = 1.2; A.duck(1, 0.9); A.stopSpeech(); }, 'scare');
        NP.Timers.after(0.9, () => A.creature(H.behind(0.6).setY(1.6), 'breath'), 'scare');
        // 3. light snaps back: it is inches from your face, screaming
        NP.Timers.after(1.55, () => {
          const { e, f } = H.placeFace(a, 0.75);
          const hp = a.headPos(new V3());
          L.bakeUniform.value = 1.6; P.interfere = 0;
          A.stinger('screech', 1.3); A.stinger('hit', 1.2); A.creature(hp, 'screech'); A.creature(hp, 'growl');
          P.addShake(2.2, 1.1); NP.FX.distort(1.8); NP.FX.flash(0.9, 0.04, 0.02, 3);
          P.kick.set((Math.random() - 0.5) * 0.12, 0.09);
          // strobing lunge straight into the camera
          let k = 0;
          const start = a.root.position.clone();
          H.tween(0.45, (t) => {
            // lunge from 0.75 m to 0.35 m from your eyes
            a.root.position.x = start.x - f.x * t * 0.4; a.root.position.z = start.z - f.z * t * 0.4;
            if (Math.floor(t * 14) !== k) { k = Math.floor(t * 14); L.bakeUniform.value = k % 2 ? 0.05 : 1.8; S.faceLight.intensity = k % 2 ? 1.2 : 5.5; NP.FX.flash(k % 2 ? 0 : 0.35, 0, 0, 8); }
          });
        }, 'scare');
        // 4. blackout, it is gone, the lights limp back
        NP.Timers.after(2.2, () => { L.bakeUniform.value = 0; H.hide(a); H.faceLightOff(); NP.FX.distort(0.9); A.metal(P.pos, 0.9, 0.4); }, 'scare');
        NP.Timers.after(2.6, () => { H.flicker(0.8, 10); }, 'scare');
        NP.Timers.after(3.5, () => { L.bakeUniform.value = 1; A.heartbeat(0.9); A.whisper(H.behind(1.2).setY(1.6)); }, 'scare');
        NP.Timers.after(4.4, () => A.heartbeat(0.8), 'scare');
        NP.Timers.after(5.2, () => A.heartbeat(0.6), 'scare');
      } });

    /* 1 — figure at the end of the service corridor; vanishes when the light goes off */
    S.def({ id: 'corridor_figure', intensity: 1, cond: () => F().flashlight && F().card1 && zoneIs('g') && Pl().pos.z < at(0, 33).z,
      run: () => {
        const p = at(24, 37, 0.3, 0.4);
        H.show(app(), p, Math.PI, 'watch');
        let seen = false, t0 = T(), beamT = 0;
        NP.Bus.on('flash', function off(e) { if (!e.on && app().visible && S._cf) { S._cf = false; H.hide(app()); NP.Audio.whisper(p); } });
        S._cf = true;
        S.tick((dt) => {
          if (!S._cf) return true;
          app().lookAt = Pl().eyePos(new V3());
          if (!seen && sees(p, 0.8, 1.6)) { seen = true; NP.Audio.stinger('low', 0.8); NP.Audio.duck(0.6, 3); }
          if (Pl().inBeam(new V3(p.x, 1.6, p.z), 20)) beamT += dt;
          if (beamT > 1.4) { app().setFade(1); S._cf = false; NP.Audio.whisper(p); NP.Timers.after(1, () => H.hide(app())); return true; }
          if (dist(p) < 8 || T() - t0 > 16) { H.flicker(0.35); NP.Timers.after(0.12, () => H.hide(app())); S._cf = false; return true; }
          return false;
        });
      } });

    /* 16 — scratching inside the ceiling vent follows the player, then the grate bursts */
    S.def({ id: 'vent_scratch', intensity: 2, cond: () => F().power && !F().fuse && zoneIs('g') && dist(at(24, 30)) < 7,
      run: () => {
        const v = W.vents.service;
        [0, 0.9, 1.8].forEach((d, i) => NP.Timers.after(d, () => NP.Audio.scratch(at(24, 28 + i, 0, 0, 2.95), 1.0)));
        NP.Timers.after(2.6, () => { NP.Audio.metal(v.base, 0.5, 1.6); H.tween(0.4, (k) => { v.g.rotation.z = Math.sin(k * 40) * 0.05; }); });
        NP.Timers.after(4.0, () => {
          NP.Audio.duck(0.9, 1.2);
        });
        NP.Timers.after(4.8, () => {
          NP.Audio.metal(v.base, 1.1, 1.1); NP.Audio.stinger('screech', 0.7);
          H.tween(0.6, (k) => { v.g.position.y = v.base.y - k * k * 2.9; v.g.rotation.x = k * 1.3; v.g.position.x = v.base.x + k * 0.4; });
          NP.FX.burstSmoke(v.base.clone().setY(2.8), 26, 0.6);
          const h = S.hand; h.g.position.copy(v.base).setY(2.95); h.g.rotation.set(0, 0, -Math.PI / 2); h.g.visible = true; h.curl(0);
          H.tween(0.25, (k) => { h.g.position.y = 2.95 - k * 0.55; h.curl(k * 0.3); }, () => H.tween(0.5, (k) => { h.curl(0.3 + k * 0.7); }, () => H.tween(0.2, (k) => { h.g.position.y = 2.4 + k * 0.7; }, () => { h.g.visible = false; })));
          H.jolt(2);
        });
      } });

    /* 10 — false scare: tray falls off a shelf in storage */
    S.def({ id: 'false_tray', intensity: 1, cond: () => zoneIs('k') && F().power,
      run: () => {
        NP.Timers.after(1.6, () => {
          const tr = W.tray;
          NP.Audio.clatter(tr.base);
          H.tween(0.45, (k) => { tr.g.position.y = tr.base.y - k * k * 1.95; tr.g.position.z = tr.base.z - k * 0.5; tr.g.rotation.x = k * 2.6; tr.g.rotation.z = k * 0.8; });
          Pl().addShake(0.15, 0.2);
        });
      } });

    /* 6 — creature drops from the ceiling hatch after the fuse is taken */
    S.def({ id: 'ceiling_hatch', intensity: 3, cond: () => F().fuse && zoneIs('k') && facing(W.hatch.pos, 2.0) > 0.35,
      run: () => {
        const hp = W.hatch.pos, a = app();
        NP.Audio.duck(1, 1.5); NP.Audio.scratch(hp, 0.6);
        NP.Timers.after(0.8, () => {
          NP.Audio.metal(hp, 1.2, 1.3); NP.Audio.stinger('hit'); NP.Audio.creature(hp, 'screech');
          H.tween(0.15, (k) => { W.hatch.g.rotation.z = -k * 1.9; });
          H.show(a, new V3(hp.x, 5.8, hp.z + 0.1), H.yawTo(hp, Pl().pos), 'hang');
          a.root.rotation.x = Math.PI; a.root.rotation.y = H.yawTo(hp, Pl().pos) + Math.PI;
          a.snapPose();
          H.tween(0.22, (k) => { a.root.position.y = 5.8 - k * 1.75; });
          H.jolt(3); NP.FX.burstSmoke(hp.clone().setY(2.95), 18, 0.5);
          NP.Timers.after(1.25, () => H.tween(0.35, (k) => { a.root.position.y = 4.05 + k * 2; }, () => { H.hide(a); H.tween(0.2, (k) => { W.hatch.g.rotation.z = -1.9 + k * 1.9; }, () => NP.Audio.metal(hp, 0.9, 1.4)); }));
        });
      } });

    /* 17 — reception lift opens on a figure facing the wall */
    S.def({ id: 'elevator_figure', intensity: 2, cond: () => F().power && !F().fuse && zoneIs('r') && dist(W.elevator.pos) < 11 && facing(W.elevator.pos) > 0.6,
      run: () => {
        const el = W.elevator, a = app();
        NP.Audio.ding(el.pos);
        const inside = el.pos.clone(); inside.z -= 0.75; inside.y = 0;
        H.show(a, inside, Math.PI, 'stand'); a.root.rotation.y = 0; // back to the player (facing the wall)
        el.lamp.intensity = 1.2;
        H.tween(1.2, (k) => { el.open = NP.smooth(k); el.lamp.intensity = Math.random() < 0.15 ? 0 : 1.2; });
        NP.Timers.after(2.6, () => { a.setState('turnhead'); a.lookAt = Pl().eyePos(new V3()); NP.Audio.creature(inside, 'click'); NP.Audio.stinger('low', 0.8); });
        NP.Timers.after(5.4, () => { H.tween(0.3, (k) => { el.open = 1 - k; }, () => { NP.Audio.metal(el.pos, 1, 1.1); H.hide(a); el.lamp.intensity = 0; }); });
      } });

    /* 25 — the reception phone rings */
    S.def({ id: 'phone', intensity: 1, cond: () => F().fuse && zoneIs('r') && !F().fuseIn,
      run: () => {
        W.phone.ringing = true; let n = 0;
        const ring = () => { if (!W.phone.ringing || n++ > 7) { W.phone.ringing = false; return; } NP.Audio.phone(W.phone.pos); NP.Timers.after(2.2, ring); };
        ring();
      } });
    S.answerPhone = function () {
      if (!W.phone.ringing) { NP.Audio.click(1); NP.UI.toast('Dead line.'); return; }
      W.phone.ringing = false; NP.Audio.click(1);
      NP.Audio.intercom('...twelve... you were supposed to stay asleep... it can only find you if you remember it...', { who: 'PHONE', dur: 6, pitch: 0.3, rate: 0.75 });
      NP.Timers.after(5.5, () => { NP.Audio.creature({ x: Pl().pos.x, y: 1.6, z: Pl().pos.z }, 'breath'); NP.Audio.stinger('static', 0.8); });
    };

    /* 12 — reflection: the creature stands behind you, but only in the two-way mirror */
    S.def({ id: 'mirror', intensity: 1, cond: () => F().flashlight && zoneIs('v') && W.mirror.rt && dist(W.mirror.pos) < 5.5 && facing(W.mirror.pos, 1.6) > 0.75 && T() > 8,
      run: () => {
        const b = H.behind(1.3);
        if (!L.isFloorish(...L.cellOf(b.x, b.z))) { b.copy(H.behind(0.8)); }
        H.show(W.appMirror, b, Pl().yaw + Math.PI, 'watch');
        W.appMirror.lookAt = Pl().eyePos(new V3());
        let t0 = T();
        S.tick(() => {
          W.appMirror.place(H.behind(1.2).x, H.behind(1.2).z, Pl().yaw);
          if (facing(W.mirror.pos, 1.6) < 0.3 || T() - t0 > 2.4) { H.hide(W.appMirror); NP.Audio.whisper(H.behind(1)); NP.Audio.stinger('low', 0.6); return true; }
          return false;
        });
      } });

    /* 3 — face lunges out of a pharmacy cabinet */
    {
      const cp = at(11, 22, 0, -C / 2 + 0.25);
      const doorG = new THREE.Group(); doorG.position.set(cp.x - 0.5, 0.05, cp.z + 0.22); scene.add(doorG);
      const dm = new THREE.Mesh(new THREE.BoxGeometry(0.98, 1.9, 0.03), L.dynMat('p_white')); dm.position.set(0.49, 0.95, 0.0); doorG.add(dm);
      const knob = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.12, 0.03), L.dynMat('p_steel')); knob.position.set(0.9, 1.0, 0.03); doorG.add(knob);
      S.cab = { doorG, open: false };
      NP.Interact.add({ meshes: [dm], pos: new V3(cp.x, 1, cp.z), label: () => 'Search cabinet', enabled: () => !S.cab.open,
        use: () => {
          S.cab.open = true; NP.Audio.locked(cp);
          H.tween(0.3, (k) => { doorG.rotation.y = -k * 1.7; });
          if (S.done.has('cabinet_face')) return;
          S.done.add('cabinet_face'); S.mark('cabinet_face', 3);
          const a = app();
          NP.Timers.after(0.18, () => {
            H.placeFace(a, 0.55);
            const hp = a.headPos(new V3());
            NP.Audio.stinger('screech'); NP.Audio.creature(hp, 'screech'); H.jolt(3); NP.FX.flash(0.25, 0.02, 0.0, 6);
            NP.Timers.after(0.45, () => { H.hide(a); H.faceLightOff(); H.lightsOut(0.18); });
            NP.Timers.after(1.2, () => { const b = NP.World.items.bat3; if (b && !b.taken) { b.mesh.position.set(cp.x, 0.9, cp.z + 0.1); } });
          });
        } });
    }

    /* 27 — silhouette behind the exam-room curtain */
    S.def({ id: 'curtain_shadow', intensity: 1, cond: () => F().fuseIn && inRect(18, 23, 22, 26),
      run: () => {
        const cpos = at(19, 22, 0.3, -1.45);
        H.show(app(), cpos, 0, 'stand'); app().lookAt = Pl().eyePos(new V3());
        W.curtain.sway = 1;
        NP.Audio.creature(cpos, 'breath');
        let t0 = T();
        S._curt = true;
        const off = () => { if (S._curt && app().visible) { S._curt = false; H.hide(app()); NP.Audio.whisper(cpos); } };
        NP.Bus.on('curtain', (e) => { if (e.open) off(); });
        S.tick(() => { if (!app().visible) return true; W.curtain.sway = Math.max(W.curtain.sway, 0.6); if (!S._curt) return true; if (T() - t0 > 12 || dist(cpos) < 1.4) { off(); return true; } return false; });
      } });

    /* 4 — a silhouette sprints past the exam room doorway */
    S.def({ id: 'doorway_rush', intensity: 2, cond: () => F().fuseIn && S.done.has('curtain_shadow') && !app().visible && inRect(18, 22, 22, 26) && facing(at(17, 24)) > 0.85 && dist(at(17, 24)) > 2.5,
      run: () => {
        const a = app(); const z0 = at(15, 20).z, z1 = at(15, 27).z, x = at(15, 24, 0.9).x;
        H.show(a, new V3(x, 0, z0), 0, 'sprint');
        NP.Audio.footstepsAt({ x, y: 0.2, z: at(15, 24).z }, true, 4);
        H.tween(0.85, (k) => { a.root.position.z = NP.lerp(z0, z1, k); a.update(0.016); }, () => H.hide(a));
        NP.FX.distort(0.35); NP.Audio.stinger('static', 0.5);
      } });

    /* 26 — gurney rolls on its own behind the player */
    S.def({ id: 'gurney', intensity: 1, cond: () => F().fuseIn && inRect(15, 21, 16, 26) && facing(NP.World.gurney.position, 0.8) < -0.2,
      run: () => {
        const g = NP.World.gurney; const z0 = g.position.z;
        NP.World.gurneyBox.disabled = true;
        const sq = () => { NP.Audio.beep('key', g.position); };
        for (let i = 0; i < 6; i++) NP.Timers.after(i * 0.3, sq);
        H.tween(1.8, (k) => { g.position.z = z0 + NP.smooth(k) * 2.2; g.rotation.y = 0.15 + k * 0.5; }, () => {
          const p = g.position; NP.World.gurneyBox.x0 = p.x - 0.5; NP.World.gurneyBox.x1 = p.x + 0.5; NP.World.gurneyBox.z0 = p.z - 1; NP.World.gurneyBox.z1 = p.z + 1; NP.World.gurneyBox.disabled = false;
          NP.Audio.metal(p, 0.4, 1.5);
        });
      } });

    /* 7 — simulation room: every mannequin turns to face you during a blackout */
    S.def({ id: 'mannequins_turn', intensity: 2, cond: () => F().fuseIn && inRect(18, 14, 22, 19) && dist(at(20, 16, 0, 0.6)) < 2.2,
      run: () => {
        NP.Audio.duck(1, 1.3);
        NP.Timers.after(0.9, () => {
          const was = L.circuits.sim; L.setCircuit('sim', 0); H.lightsOut(0.7);
          NP.Audio.zap(at(20, 16, 0, 0, 2.8));
          NP.Timers.after(0.35, () => {
            W.mannequins.forEach((m) => { m.root.rotation.y = H.yawTo(m.root.position, Pl().pos); m.setPose(2, true); });
          });
          NP.Timers.after(0.75, () => { L.setCircuit('sim', was || 1); NP.Audio.stinger('low'); NP.Audio.whisper(H.behind(1.2)); });
        });
        S.tick(() => {
          if (!inRect(18, 14, 22, 19)) return true;
          W.mannequins.forEach((m) => { const want = H.yawTo(m.root.position, Pl().pos); m.root.rotation.y += NP.angDiff(m.root.rotation.y, want) * 0.08; });
          return false;
        });
      } });

    /* 5 — ward mannequin creeps closer every time you look away */
    S.def({ id: 'mannequin_creep', intensity: 1, cond: () => F().fuseIn && zoneIs('w'),
      run: () => {
        const m = W.wardMannequin; let steps = 0; let lastP = Pl().pos.clone(); let lastStepT = T();
        S.tick(() => {
          if (steps >= 4) return true;
          const mp = m.root.position;
          const visible = Pl().canSee(new V3(mp.x, 1.5, mp.z), 0.35, 30);
          if (!visible && Pl().pos.distanceTo(lastP) > 2.2 && T() - lastStepT > 1.5 && zoneIs('w')) {
            const toP = Pl().pos.clone().sub(mp).setY(0); const d = toP.length();
            if (d > 3) {
              toP.normalize(); const np = mp.clone().addScaledVector(toP, Math.min(1.8, d - 2.5));
              const [gx, gz] = L.cellOf(np.x, np.z);
              if (L.ch(gx, gz) === 'w') {
                mp.copy(np); m.root.rotation.y = H.yawTo(mp, Pl().pos); m.setPose(1 + (steps % 4), true); steps++;
                lastP.copy(Pl().pos); lastStepT = T();
                if (steps === 4) NP.Timers.after(0.1, () => NP.Audio.whisper(mp));
                else NP.Audio.footstepsAt({ x: mp.x, y: 0.1, z: mp.z }, false, 1);
              }
            }
          }
          return !F().fuseIn;
        });
      } });

    /* 13 — a long hand curls around a doorframe */
    S.def({ id: 'hand_door', intensity: 1, cond: () => F().fuseIn && inRect(5, 14, 11, 15) && dist(at(7, 13)) > 3 && dist(at(7, 13)) < 9 && facing(at(7, 13), 1.4) > 0.7,
      run: () => {
        const d = L.doors.r105; d.swingDir = -1; d.setOpen(true, { silent: true }); d.t = 0.9;
        const h = S.hand; const c = d.center;
        h.g.position.set(c.x + 0.78, 1.45, c.z - 0.05); h.g.rotation.set(0, Math.PI / 2, 0); h.g.visible = true; h.curl(0);
        const base = h.g.position.clone();
        H.tween(0.9, (k) => { h.g.position.x = base.x - k * 0.12; h.curl(NP.smooth(k) * 0.9); });
        NP.Audio.scratch({ x: c.x + 0.7, y: 1.4, z: c.z }, 0.8);
        let t0 = T();
        S.tick(() => {
          if (Pl().inBeam(new V3(c.x + 0.7, 1.45, c.z), 15) || dist(c) < 3 || T() - t0 > 3.5) {
            H.tween(0.15, (k) => { h.g.position.x = base.x - 0.12 + k * 0.5; h.curl(0.9 - k); }, () => { h.g.visible = false; NP.Audio.metal(c, 0.5, 1.5); d.setOpen(false, { slam: true }); });
            return true;
          }
          return false;
        });
      } });

    /* 8 — room 104's door slams and something scratches outside */
    S.def({ id: 'door_slam', intensity: 2, cond: () => F().ev2 && inRect(2, 9, 4, 12),
      run: () => {
        const d = L.doors.r104;
        NP.Timers.after(0.6, () => {
          d.setOpen(false, { slam: true }); d.locked = true; d.lock = 'jam';
          NP.Audio.stinger('hit', 0.8); H.jolt(2); H.flicker(0.5);
          NP.Timers.after(1.2, () => NP.Audio.scratch({ x: d.center.x, y: 1.2, z: d.center.z + 0.6 }, 3));
          NP.Timers.after(3.0, () => NP.Audio.creature({ x: d.center.x, y: 1.6, z: d.center.z + 0.8 }, 'breath'));
          NP.Timers.after(6.5, () => { d.locked = false; d.lock = null; d.swingDir = 1; d.speed2 = 0.5; d.open = true; NP.Audio.door(d, true, false); });
        });
      } });

    /* 14 — power failure; a silhouette waits under the emergency light */
    S.def({ id: 'outage', intensity: 3, major: true, cond: () => F().ev2 && S.done.has('door_slam') && !F().wardBlackout && zoneIs('w') && inRect(2, 14, 13, 15),
      run: () => {
        NP.Audio.powerDown(); H.flicker(1.2, 12);
        NP.Timers.after(1.25, () => { F().wardBlackout = true; NP.Game.applyLighting(); L.bakeUniform.value = 0; Pl().interfere = 2.5; NP.Audio.duck(1, 2.6); });
        NP.Timers.after(3.4, () => {
          L.bakeUniform.value = 1;
          const p = Pl().pos.x > at(8, 14).x ? at(4, 14, 0, 0.6) : at(12, 14, 0, 0.6);
          H.show(app(), p, H.yawTo(p, Pl().pos), 'watch'); app().lookAt = Pl().eyePos(new V3());
          NP.Audio.stinger('low');
          NP.Audio.intercom('Anchor twelve is awake. Anchor twelve... please return to your bed.', { who: 'INTERCOM', dur: 5, pitch: 0.2, rate: 0.7 });
        });
        NP.Timers.after(6.2, () => { H.lightsOut(0.2); NP.Timers.after(0.08, () => H.hide(app())); });
      } });

    /* 9 — figure at the end of the dark ward hallway breaks into a sprint */
    S.def({ id: 'hallway_sprinter', intensity: 3, cond: () => F().wardBlackout && S.done.has('outage') && NP.Timers.time - S.lastT > 18 && inRect(9, 14, 13, 15) && facing(at(2, 14)) > 0.85 && NP.AI.state !== 'chase',
      run: () => {
        const a = app(); const p = at(2, 14, 0, 0.6);
        H.show(a, p, Math.PI / 2, 'watch'); a.lookAt = Pl().eyePos(new V3());
        NP.Audio.duck(1, 1.5);
        NP.Timers.after(1.4, () => {
          a.setState('sprint'); NP.Audio.creature(p, 'screech');
          S.tick((dt) => {
            if (!a.visible) return true;
            const d = dist(a.pos);
            a.root.position.x += 8.5 * dt; a.root.rotation.y = Math.PI / 2;
            a.update(0);
            if (Math.random() < dt * 6) NP.Audio.footstepsAt({ x: a.pos.x, y: 0.2, z: a.pos.z }, true, 1);
            if (d < 3.0) { H.lightsOut(0.3); H.hide(a); NP.Audio.stinger('hit'); H.jolt(3); NP.FX.flash(0.3, 0.02, 0.02, 7); return true; }
            return false;
          });
        });
      } });

    /* 15 — something charges out of the dark lab as the door opens; lights die before it reaches you */
    S.def({ id: 'lab_rush', intensity: 3, cond: () => F().labOpen && L.doors.lab.t > 0.95 && dist(at(15, 12)) < 4.5 && facing(at(15, 9)) > 0.7,
      run: () => {
        const a = app(); const p = at(18, 8, 0, 0.3);
        H.show(a, p, H.yawTo(p, Pl().pos), 'sprint');
        NP.Audio.creature(p, 'screech');
        S.tick((dt) => {
          const tgt = Pl().pos; const pos = a.pos; const d = dist(pos);
          const yaw = H.yawTo(pos, tgt); pos.x += Math.sin(yaw) * 7.5 * dt; pos.z += Math.cos(yaw) * 7.5 * dt; a.root.rotation.y = yaw;
          if (d < 2.6) { H.lightsOut(0.6); H.hide(a); NP.Audio.stinger('hit'); H.jolt(3); NP.FX.flash(0.0, 0.0, 0.0); return true; }
          return false;
        });
      } });

    /* 2 — the creature slams against the observation glass of Cell 0 */
    S.def({ id: 'observation_glass', intensity: 3, cond: () => F().labOpen && !F().terminal && zoneIs('l') && dist(at(20, 7)) < 7.5 && facing(at(20, 6, 0, 0)) > 0.8 && T() - S.lastT > 15,
      run: () => {
        NP.Audio.duck(1, 2.0);
        NP.Timers.after(1.5, () => {
          const p = at(19, 6, 0.4, 0.6);
          L.setCircuit('cell', 1.4);
          H.show(app(), p, 0, 'attack'); app().lookAt = Pl().eyePos(new V3());
          NP.Audio.glassBang(at(19, 7, 0.4, 0, 1.5)); NP.Audio.stinger('hit'); NP.Audio.creature(p, 'screech');
          H.jolt(2);
          NP.Timers.after(0.5, () => NP.Audio.glassBang(at(19, 7, 0.4, 0, 1.5)));
          NP.Timers.after(1.3, () => { L.setCircuit('cell', 0); NP.Timers.after(0.06, () => H.hide(app())); });
        });
      } });

    /* 18 — the cleared storage room is no longer empty */
    S.def({ id: 'cleared_room', intensity: 2, cond: () => F().fuseIn && F().ev1 && zoneIs('k'),
      run: () => {
        const p = at(31, 30, 0.6, 0.6);
        H.show(app(), p, Math.PI * 0.25, 'stand');
        let seen = false, t0 = T();
        S.tick(() => {
          if (!seen && sees(p, 0.7, 1.6)) { seen = true; t0 = T(); app().setState('turnhead'); app().lookAt = Pl().eyePos(new V3()); NP.Audio.creature(p, 'click'); }
          if (seen && T() - t0 > 2.6) { H.flicker(0.4); NP.Timers.after(0.15, () => H.hide(app())); NP.Audio.stinger('low'); return true; }
          if (!seen && T() - t0 > 14) { H.hide(app()); return true; }
          return false;
        });
      } });

    /* 11 — security monitor shows it standing right behind you */
    S.def({ id: 'cctv', intensity: 2, cond: () => F().secReached && zoneIs('q') && dist(W.cctv.pos) < 3.6 && facing(W.cctv.pos, 1.7) > 0.88 && T() - S.lastT > 6,
      run: () => {
        const a = W.appCCTV;
        const place = () => { const b = H.behind(1.1); a.place(b.x, b.z, Pl().yaw); };
        H.show(a, H.behind(1.1), Pl().yaw, 'watch'); place(); a.lookAt = Pl().eyePos(new V3());
        NP.Audio.duck(0.8, 3); NP.Audio.creature(H.behind(1.1).setY(1.7), 'breath');
        let t0 = T(), raised = false;
        S.tick(() => {
          place(); a.lookAt = Pl().eyePos(new V3());
          if (facing(H.behind(1.1), 1.4) > -0.2 && facing(W.cctv.pos, 1.7) < 0.5) { H.hide(a); H.flicker(0.3); NP.Audio.stinger('low'); NP.Audio.whisper(H.behind(1.5)); return true; }
          if (!raised && T() - t0 > 2.2) { raised = true; a.setState('attack'); NP.Audio.stinger('static'); }
          if (T() - t0 > 3.2) { H.hide(a); W.cctv.mat.uniforms.uNoise.value = 2; NP.Timers.after(0.5, () => { W.cctv.mat.uniforms.uNoise.value = 0.15; }); NP.Audio.stinger('hit', 0.8); H.jolt(2); NP.Audio.whisper(H.behind(0.6)); return true; }
          return false;
        });
      } });

    /* 21–24 — ambient, repeatable unease (only when the director allows) */
    S.def({ id: 'whisper_behind', once: false, cooldown: 70, intensity: 1, ambient: true, cond: () => F().flashlight && S.tension > 0.35,
      run: () => NP.Audio.whisper(H.behind(1.4).setY(1.6)) });
    S.def({ id: 'distant_steps', once: false, cooldown: 55, intensity: 1, ambient: true, cond: () => F().flashlight && S.tension > 0.3,
      run: () => {
        for (let i = 0; i < 20; i++) {
          const a = Math.random() * 6.28, r = 7 + Math.random() * 6; const p = Pl().pos;
          const x = p.x + Math.cos(a) * r, z = p.z + Math.sin(a) * r; const [gx, gz] = L.cellOf(x, z);
          if (L.isFloorish(gx, gz) && !L.los(p.x, p.z, x, z, 'sight')) { NP.Audio.footstepsAt({ x, y: 0.5, z }, Math.random() < 0.5, 5 + Math.floor(Math.random() * 4)); return; }
        }
      } });
    S.def({ id: 'flicker_wave', once: false, cooldown: 45, intensity: 1, ambient: true, cond: () => F().power && S.tension > 0.25,
      run: () => {
        const near = L.fixtures.filter((f) => f.cur > 0.2 && f.pos.distanceTo(Pl().pos) < 14).sort((a, b) => a.pos.distanceTo(Pl().pos) - b.pos.distanceTo(Pl().pos));
        near.slice(0, 6).forEach((f, i) => { NP.Timers.after(i * 0.18, () => { f.override = 0.02; NP.Audio.zap(f.pos); }); NP.Timers.after(i * 0.18 + 0.25, () => { f.override = null; }); });
      } });
    S.def({ id: 'wall_scratch', once: false, cooldown: 80, intensity: 1, ambient: true, cond: () => S.tension > 0.45,
      run: () => { const p = Pl().pos; const side = Math.random() < 0.5 ? 1 : -1; NP.Audio.scratch({ x: p.x + Math.cos(Pl().yaw) * 1.8 * side, y: 1.2, z: p.z - Math.sin(Pl().yaw) * 1.8 * side }, 2.2); } });
  };

  /* bookkeeping for scares triggered outside the director (story beats) */
  S.mark = function (id, intensity) { this.done.add(id); this.lastT = T(); this.lastInt = intensity || 2; this.tension = Math.max(0, this.tension - 0.35 * (intensity || 2)); this.log.push(id); NP.Bus.emit('scare', { id }); };

  S.update = function (dt) {
    // tension builds while nothing happens; danger pushes it up faster
    const danger = NP.AI.danger || 0;
    this.tension = NP.clamp(this.tension + dt * (0.006 + danger * 0.03), 0, 1);
    NP.Audio.setTension(Math.max(this.tension * 0.7, danger));
    // run tickers
    for (let i = this.running.length - 1; i >= 0; i--) { let doneT = false; try { doneT = this.running[i](dt); } catch (e) { console.error('[scare tick]', e); doneT = true; } if (doneT) this.running.splice(i, 1); }
    if (NP.Player.cine || NP.Game.state !== 'play') return;
    const since = T() - this.lastT;
    for (const d of this.defs) {
      if (d.once && this.done.has(d.id)) continue;
      if (!d.once && T() - d.last < d.cooldown) continue;
      if (!d.major && since < RECOVER[this.lastInt] * (d.ambient ? 1.4 : 1)) continue;
      if (d.ambient && (NP.AI.state === 'chase' || Math.random() > dt * 0.25)) continue;
      let ok = false; try { ok = d.cond(); } catch (e) { ok = false; }
      if (!ok) continue;
      d.last = T();
      if (d.once) this.done.add(d.id);
      if (!d.ambient) { this.lastT = T(); this.lastInt = d.intensity; this.tension = Math.max(0, this.tension - 0.3 * d.intensity); this.log.push(d.id); NP.Bus.emit('scare', { id: d.id }); }
      try { d.run(); } catch (e) { console.error('[scare]', d.id, e); }
      break; // one per frame
    }
  };
  S.reset = function (doneList) {
    this.done = new Set(doneList || []); this.running = []; this.lastT = T() - 10; this.lastInt = 0; this.tension = 0.1;
    NP.Timers.cancel('scare'); NP.Tweens.cancel('scare'); NP.Timers.cancel('lights'); L.bakeUniform.value = 1;
    S._cf = false; if (S.hand) S.hand.g.visible = false; if (S.cab) { S.cab.open = false; S.cab.doorG.rotation.y = 0; }
  };
})(window.NP);
