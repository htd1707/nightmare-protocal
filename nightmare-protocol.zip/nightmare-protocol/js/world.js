/* NIGHTMARE PROTOCOL — gameplay world: interactables, items, documents, puzzles, lockers, mirror, CCTV, world state from flags */
'use strict';
(function (NP) {
  const L = NP.Level, C = L.C, P = NP.Props;
  const V3 = THREE.Vector3;
  const Wd = (NP.World = {});
  const at = (gx, gz, ox = 0, oz = 0, y = 0) => new V3((gx + 0.5) * C + ox, y, (gz + 0.5) * C + oz);

  /* =============== INTERACTION =============== */
  const I = (NP.Interact = { list: [], current: null });
  I.add = function (o) {
    o = Object.assign({ radius: 2.3, enabled: () => true }, o);
    o.meshes = (o.meshes || []).filter(Boolean);
    o.meshes.forEach((m) => m.traverse((c) => { c.userData.inter = o; }));
    this.list.push(o); return o;
  };
  const ray = new THREE.Raycaster(); ray.far = 2.6;
  const _f = new V3(), _e = new V3();
  I.update = function (camera) {
    const Pl = NP.Player;
    this.current = null;
    if (Pl.hidden) { NP.UI.prompt(Pl.hidden.exitLabel || 'Leave hiding spot'); this.current = { use: () => Wd.exitLocker() }; return; }
    if (Pl.cine || Pl.frozen) { NP.UI.prompt(null); return; }
    camera.getWorldPosition(_e); camera.getWorldDirection(_f);
    ray.set(_e, _f);
    const cands = [];
    for (const o of this.list) {
      if (!o.enabled()) continue;
      const p = o.pos; if (!p) continue;
      if (Math.hypot(p.x - _e.x, p.z - _e.z) > 3.2) continue;
      for (const m of o.meshes) if (m.visible !== false) cands.push(m);
    }
    let hit = null;
    if (cands.length) {
      const hs = ray.intersectObjects(cands, true);
      for (const h of hs) {
        const o = h.object.userData.inter; if (!o || !o.enabled()) continue;
        if (!L.los(_e.x, _e.z, o.pos.x, o.pos.z, 'sight') && Math.hypot(o.pos.x - _e.x, o.pos.z - _e.z) > 1.4) continue;
        hit = o; break;
      }
    }
    // fallback: generous cone check for small items lying on surfaces
    if (!hit) {
      let best = 0.965;
      for (const o of this.list) {
        if (!o.small || !o.enabled() || !o.pos) continue;
        const dx = o.pos.x - _e.x, dy = o.pos.y - _e.y, dz = o.pos.z - _e.z, d = Math.hypot(dx, dy, dz);
        if (d > 2.4) continue;
        const c = (dx * _f.x + dy * _f.y + dz * _f.z) / d;
        if (c > best && L.los(_e.x, _e.z, o.pos.x, o.pos.z, 'sight')) { best = c; hit = o; }
      }
    }
    this.current = hit;
    NP.UI.prompt(hit ? (typeof hit.label === 'function' ? hit.label() : hit.label) : null);
  };
  I.use = function () { if (this.current && this.current.use) { const c = this.current; c.use(); } };

  /* =============== SHARED MATERIALS / MODELS =============== */
  const M = {};
  function mats() {
    M.plastic = new THREE.MeshStandardMaterial({ color: 0x1d2021, roughness: 0.45, metalness: 0.3 });
    M.card1 = new THREE.MeshStandardMaterial({ map: NP.Tex.canvasTex(256, 160, (c, w, h) => { c.fillStyle = '#d7d2c4'; c.fillRect(0, 0, w, h); c.fillStyle = '#2f6b4e'; c.fillRect(0, 0, w, 36); c.fillStyle = '#e8e6df'; c.font = '700 26px "IBM Plex Mono", monospace'; c.fillText('HALE INSTITUTE', 14, 27); c.fillStyle = '#222'; c.font = '700 40px "Big Shoulders Stencil Display", Impact'; c.fillText('ACCESS 1', 14, 92); c.font = '500 18px "IBM Plex Mono", monospace'; c.fillText('R. OKAFOR — NURSING', 14, 130); }), roughness: 0.4, emissive: 0x112211, emissiveIntensity: 0.4 });
    M.card2 = new THREE.MeshStandardMaterial({ map: NP.Tex.canvasTex(256, 160, (c, w, h) => { c.fillStyle = '#d7d2c4'; c.fillRect(0, 0, w, h); c.fillStyle = '#8b2a22'; c.fillRect(0, 0, w, 36); c.fillStyle = '#eee'; c.font = '700 26px "IBM Plex Mono", monospace'; c.fillText('HALE INSTITUTE', 14, 27); c.fillStyle = '#222'; c.font = '700 40px "Big Shoulders Stencil Display", Impact'; c.fillText('ACCESS 2', 14, 92); c.font = '500 18px "IBM Plex Mono", monospace'; c.fillText('DR. M. HALE — DIRECTOR', 14, 130); }), roughness: 0.4, emissive: 0x221111, emissiveIntensity: 0.4 });
    M.battery = new THREE.MeshStandardMaterial({ color: 0x2b4f3a, roughness: 0.35, metalness: 0.5, emissive: 0x0b2214 });
    M.cap = new THREE.MeshStandardMaterial({ color: 0xb0b3b0, roughness: 0.3, metalness: 0.9 });
    M.fuse = new THREE.MeshStandardMaterial({ color: 0xd4c27a, roughness: 0.3, metalness: 0.7, emissive: 0x221c08 });
    M.paper = new THREE.MeshStandardMaterial({ color: 0xd8d2bf, roughness: 0.9 });
    M.folder = new THREE.MeshStandardMaterial({ color: 0x8a5a2a, roughness: 0.8, emissive: 0x150c04 });
    M.lever = new THREE.MeshStandardMaterial({ color: 0x9a2a1e, roughness: 0.5, metalness: 0.4 });
    M.leverMetal = L.dynMat('p_steel');
    M.panel = L.dynMat('p_metal');
    M.screenOff = new THREE.MeshBasicMaterial({ color: 0x020403 });
  }
  function glowRing(mesh) { // faint pick-up glint so items read in the dark
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    s.userData.glint = true; mesh.add(s); s.position.y = 0.03; Wd.glints.push(s); return s;
  }
  function itemMesh(kind) {
    const g = new THREE.Group();
    if (kind === 'flashlight') {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.028, 0.24, 12), M.plastic); b.rotation.z = Math.PI / 2; g.add(b);
      const h = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.028, 0.06, 12), M.cap); h.rotation.z = Math.PI / 2; h.position.x = 0.14; g.add(h);
      g.position.y = 0.03;
    } else if (kind === 'battery') {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.017, 0.017, 0.07, 10), M.battery); b.rotation.z = Math.PI / 2; g.add(b);
      const b2 = b.clone(); b2.position.z = 0.04; g.add(b2);
      const c1 = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.08, 6), M.cap); c1.rotation.z = Math.PI / 2; g.add(c1);
      g.position.y = 0.017;
    } else if (kind === 'card1' || kind === 'card2') {
      const c = new THREE.Mesh(new THREE.BoxGeometry(0.086, 0.002, 0.054), [M.paper, M.paper, M[kind], M.paper, M.paper, M.paper]); g.add(c);
      g.position.y = 0.002;
    } else if (kind === 'fuse') {
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.09, 10), new THREE.MeshStandardMaterial({ color: 0xe6e0c8, roughness: 0.2, transparent: true, opacity: 0.85 })); b.rotation.z = Math.PI / 2; g.add(b);
      for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.02, 10), M.fuse); e.rotation.z = Math.PI / 2; e.position.x = s * 0.05; g.add(e); }
      g.position.y = 0.022;
    } else if (kind === 'doc') {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.002, 0.29), M.paper); g.add(p);
    } else if (kind === 'evidence') {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.025, 0.31), M.folder); g.add(p);
      const s = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.004, 0.06), new THREE.MeshStandardMaterial({ color: 0xc23a2e, emissive: 0x220000 })); s.position.set(0, 0.014, -0.08); g.add(s);
      g.position.y = 0.012;
    } else if (kind === 'tape') {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.04, 0.09), M.plastic); g.add(p);
      const r = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.042, 10), M.cap); r.position.set(-0.03, 0, 0.0); g.add(r);
      const r2 = r.clone(); r2.position.x = 0.03; g.add(r2);
      g.position.y = 0.02;
    }
    g.traverse((m) => { if (m.isMesh) { m.castShadow = true; } });
    return g;
  }

  /* =============== DOCUMENTS =============== */
  Wd.docs = {};
  function docs(v) {
    Wd.docs = {
      chart: { title: 'Patient Chart — P-12', body: `Admitted: [smeared]\nProtocol stage: 4 — NIGHTMARE\nSedation discontinued: 03:12\n\nNotes: Subject reports a "tall man" standing at the foot of the bed during every session.\n\nSubject is NOT to be told that the other eleven report him too.\n\n— Dr. M. Hale` },
      memo: { title: 'Lockdown Notice', body: `Building systems are on emergency reserve.\n\nThe main entrance has been sealed by order of Dr. Hale.\n\nStaff: restart the backup generator on the service level. The cold-start procedure is posted beside it. Your access cards open the service door.\n\nDo not open Containment for any reason.` },
      genManual: { title: 'Diesel Backup — Cold Start', body: `1.  FUEL PUMP — prime the line.\n2.  GLOW PLUG — wait for the tick.\n3.  STARTER — hold until it catches.\n\nPulling the levers in the wrong order floods the engine. Let it reset, then try again.` },
      fuseNote: { title: 'Maintenance Tag', body: `Medical Wing door — blew its 30A fuse when they sealed the ward. Door panel is beside the door in reception.\n\nSpare fuses: storage room, top shelf.\n\nDon't go up there alone. Reyes heard knocking from INSIDE the ceiling.` },
      ev1: { title: 'Evidence — Trial Log 41', evidence: 1, body: `Protocol NIGHTMARE. Twelve subjects held in a shared REM state.\n\nHypothesis: a nightmare dreamed by enough minds becomes stable enough to persist on waking.\n\nSession 38: all twelve describe the same figure. They call it THE PATIENT.\nSession 40: Orderly Reyes saw it in the corridor. Reyes was awake.\n\nI have changed the lab door code.\nFirst half: ${v.code.slice(0, 2)}\nThe rest is written where it counts the days.\n\n— M. Hale` },
      ev2: { title: 'Evidence — Patient Diary (Room 104)', evidence: 2, body: `Day ?? — They took the clocks.\n\nWhen I close my eyes he is closer. When I open them he is closer.\n\nHale says it only exists in the dream. Then why are there scratches on the OUTSIDE of my door?\n\nNurse Okafor whispered that Hale uses the first subject's name for every password. The first subject was ${v.pw}.\n\nShe said he never woke up. She said he's still dreaming, in Cell 0.` },
      ev3: { title: 'Evidence — Hale / Private Log', evidence: 3, body: `Entry 112 — Subject 1 (${v.pw}) has not woken in 409 days. EEG shows the same figure every night. The figure now registers on thermal. It has mass.\n\nEntry 115 — The others were never subjects. They were ANCHORS. Every mind that remembers it keeps it solid.\n\nEntry 117 — Purge order: sedate the anchors, burn the records. If an anchor wakes, it will follow them. It always follows the one who remembers.\n\nEntry 118 — P-12 is awake.` },
      breakers: { title: 'Containment Override — Emergency Only', body: `Set breakers:\n\n   A — ${v.brk[0] ? 'ON' : 'OFF'}\n   B — ${v.brk[1] ? 'ON' : 'OFF'}\n   C — ${v.brk[2] ? 'ON' : 'OFF'}\n\nThen pull MASTER. The chamber lock releases.\n\nGod help whoever goes in.` },
      exitCycle: { title: 'Emergency Exit Cycle', body: `The chamber blast door needs 45 seconds to pressurise once the cycle starts.\n\nDO NOT remain inside the chamber during the cycle.\n\nService lift at the end of the exit corridor runs to the surface. Bulkheads seal automatically behind evacuees.` },
      tapeReyes: { title: 'Tape — Orderly Reyes', tape: true, body: `It's in the walls. Not the vents, the WALLS. I can hear it counting. If you're down here: don't run unless it sees you. It hears running. Get in a locker and hold your breath. It only checks the ones it watched you climb into.` },
      tapeHale: { title: 'Tape — Dr. Hale', tape: true, body: `If you can hear this, then I failed to purge the anchors, and one of you is awake. I'm sorry. It isn't hunting you. It's following you home. Get to the surface. Never sleep down here again.` },
    };
  }

  /* =============== WORLD BUILD =============== */
  Wd.items = {}; Wd.glints = []; Wd.lockers = []; Wd.objs = {};
  Wd.build = function (scene, rng) {
    mats();
    // per-playthrough puzzle solutions
    const code = String(rng.int(1000, 9999));
    const pw = rng.pick(['ORPHEUS', 'MORPHEUS', 'LAZARUS', 'SOMNUS', 'HYPNOS', 'ICARUS']);
    let brk; do { brk = [rng() > 0.5, rng() > 0.5, rng() > 0.5]; } while (brk.every((b) => b === brk[0]));
    const order = rng.shuffle([0, 1, 2]);
    Wd.sol = { code, pw, brk, order };
    docs(Wd.sol);
    Wd.scene = scene;

    /* ---- pickups ---- */
    const pickup = (id, kind, pos, ry, label, onTake) => {
      const m = itemMesh(kind); m.position.add(pos); m.rotation.y = ry || 0; scene.add(m);
      if (kind !== 'doc') glowRing(m);
      const it = { id, kind, mesh: m, base: pos.clone(), taken: false };
      Wd.items[id] = it;
      I.add({ meshes: [m], pos: pos.clone(), small: true, label: () => label, enabled: () => !it.taken && m.visible, use: () => { onTake(it); } });
      return it;
    };
    const take = (it) => { it.taken = true; it.mesh.visible = false; NP.Audio.pickup(); };
    const flag = (k) => { NP.Game.flags[k] = true; NP.Game.onFlag(k); };

    // flashlight on the recovery tray
    pickup('flashlight', 'flashlight', at(5, 31, 0.5, -0.3, 0.875), 0.6, 'Take flashlight', (it) => {
      take(it); NP.Player.light.owned = true; NP.Player.light.on = true; NP.Player.light.battery = 0.7; flag('flashlight');
      NP.UI.toast('F — toggle flashlight   R — swap batteries');
    });
    // batteries
    [['bat1', at(15, 32, 1.2, 0.5, 0.79), 'reception desk'], ['bat2', at(30, 27, 0.2, -0.85, 0.765), 'storage'], ['bat3', at(12, 24, 0.1, -0.4, 0.79), 'pharmacy'],
      ['bat4', at(11, 20, 0.6, 0.2, 0.0), 'room 103'], ['bat5', at(20, 10, 0.3, 0.6, 0.95), 'lab'], ['bat6', at(24, 15, -0.5, 0.2, 0), 'tunnel'], ['bat7', at(30, 21, 1.4, 0.4, 0.8), 'security'], ['bat8', at(34, 13, 0.3, 0, 0), 'containment']]
      .forEach(([id, p]) => pickup(id, 'battery', p, rng() * 6, 'Take battery', (it) => { take(it); NP.Player.light.spares++; NP.UI.toast('Battery +1  (' + NP.Player.light.spares + ' spare)'); NP.Game.flags[id] = true; }));
    // documents
    const doc = (id, pos, ry, docId) => pickup(id, 'doc', pos, ry, 'Read', (it) => { NP.Audio.paper(); NP.UI.readDoc(Wd.docs[docId]); NP.Game.flags['read_' + docId] = true; if (Wd.docs[docId].evidence) { take(it); flag('ev' + Wd.docs[docId].evidence); } });
    doc('d_chart', at(4, 32, 0.6, 0.2, 0.76), 0.2, 'chart');
    doc('d_memo', at(15, 32, 0.0, 1.0, 1.15), -0.1, 'memo');
    P.desk(at(26, 33).x, at(26, 33).z - 0.5, 0, 1.2, 0.6);
    doc('d_gen', at(26, 33, 0, -0.5, 0.79), 0, 'genManual');
    doc('d_fuse', at(26, 36, -0.4, 0.5, 0.0), 1.2, 'fuseNote');
    doc('d_brk', at(30, 21, 0.4, 0.3, 0.8), 0.3, 'breakers');
    doc('d_exit', at(29, 5, 0.25, -0.75, 1.02), 0.1, 'exitCycle');
    // evidence folders
    const ev = (id, pos, ry, docId) => pickup(id, 'evidence', pos, ry, 'Take evidence', (it) => { take(it); NP.Audio.paper(); NP.UI.readDoc(Wd.docs[docId]); NP.Game.flags['read_' + docId] = true; flag(id); });
    ev('ev1', at(12, 24, 0.0, 0.1, 0.8), 0.3, 'ev1');
    ev('ev2', at(3, 9, 0.6, 0.3, 0.0), 2.0, 'ev2');
    // tapes
    const tape = (id, pos, docId) => pickup(id, 'tape', pos, 0.4, 'Play tape', (it) => { take(it); NP.Audio.intercom(Wd.docs[docId].body, { who: Wd.docs[docId].title.replace('Tape — ', ''), dur: 14, pitch: docId === 'tapeHale' ? 0.5 : 0.8, rate: 0.95 }); NP.Game.flags[id] = true; });
    tape('tapeReyes', at(37, 27, 0.2, 0.6, 0), 'tapeReyes');
    tape('tapeHale', at(20, 10, -0.6, 0.6, 0.95), 'tapeHale');
    // cards & fuse
    pickup('card2', 'card2', at(21, 5, 0.2, -0.2, 0), 0.7, 'Take Level 2 keycard', (it) => { take(it); flag('card2'); });
    pickup('fuse', 'fuse', at(30, 27, -0.6, -0.85, 1.965), 0.2, 'Take 30A fuse', (it) => { take(it); flag('fuse'); });

    { const wp = at(8, 18, C / 2 - 0.015, 0); Wd.scrawl = P.decal(NP.Tex.scrawl(code.slice(2) + '  ||||', 512, 256, 150), wp.x, 1.5, wp.z, 1.8, 0.9, [-1, 0, 0], { color: 0xcc9a90 }); }

    /* ---- reception desk drawer with Level 1 card ---- */
    {
      const base = at(15, 32, 0.6, 0.4);
      const dr = new THREE.Group(); dr.position.set(base.x + 0.9, 0.62, base.z + 0.42); scene.add(dr);
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.42), M.panel); dr.add(box);
      const fr = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.16, 0.02), L.dynMat('p_wood')); fr.position.z = -0.22; dr.add(fr);
      const card = itemMesh('card1'); card.position.set(0, 0.075, 0.02); card.rotation.y = 0.4; dr.add(card); glowRing(card);
      const st = { open: false };
      Wd.objs.drawer = { g: dr, st, card, z0: dr.position.z };
      I.add({ meshes: [fr, box], pos: new V3(dr.position.x, 0.62, dr.position.z), label: () => (st.open ? 'Take Level 1 keycard' : 'Search drawer'),
        enabled: () => !NP.Game.flags.card1,
        use: () => {
          if (!st.open) { st.open = true; NP.Audio.locked(dr.position); NP.Tweens.add(0.35, (k) => { dr.position.z = Wd.objs.drawer.z0 - NP.smooth(k) * 0.32; }); return; }
          card.visible = false; NP.Audio.pickup(); flag('card1');
        } });
    }

    /* ---- lockers (hiding spots) ---- */
    const lockerAt = (gx, gz, side, ox = 0) => {
      // side = wall the locker backs against
      const n = { n: [0, 1], s: [0, -1], w: [1, 0], e: [-1, 0] }[side];
      const c = at(gx, gz, -n[0] * (C / 2 - 0.3) + (n[1] ? ox : 0), -n[1] * (C / 2 - 0.3) + (n[0] ? ox : 0));
      const yaw = Math.atan2(n[0], n[1]);
      P.locker(c.x, c.z, yaw);
      const door = new THREE.Group(); door.position.set(c.x, 0, c.z); door.rotation.y = yaw; scene.add(door);
      const hinge = new THREE.Group(); hinge.position.set(-0.3, 0, 0.28); door.add(hinge);
      const panel = new THREE.Mesh(new THREE.BoxGeometry(0.58, 1.94, 0.03), L.dynMat('p_green')); panel.position.set(0.3, 1.0, 0); panel.castShadow = true; hinge.add(panel);
      for (let i = 0; i < 6; i++) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.025, 0.035), M.plastic); s.position.set(0.3, 1.45 + i * 0.05, 0.003); hinge.add(s); }
      const lk = { pos: c.clone(), front: new V3(c.x + n[0] * 0.95, 0, c.z + n[1] * 0.95), eye: new V3(c.x + n[0] * 0.05, 1.58, c.z + n[1] * 0.05), yaw: Math.atan2(-n[0], -n[1]), hinge, open: 0 };
      lk.rattle = () => { NP.Audio.metal({ x: c.x, y: 1.2, z: c.z }, 0.6, 1.6); NP.Tweens.add(0.5, (k) => { hinge.rotation.y = Math.sin(k * 30) * 0.05 * (1 - k); }); if (NP.Player.hidden === lk) { NP.Player.addShake(0.5, 0.5); NP.FX.distort(0.4); } };
      Wd.lockers.push(lk);
      I.add({ meshes: [panel], pos: new V3(c.x, 1, c.z), label: 'Hide in locker', enabled: () => !NP.Player.hidden, use: () => Wd.enterLocker(lk) });
      return lk;
    };
    lockerAt(2, 18, 'w'); lockerAt(12, 19, 'e'); lockerAt(13, 25, 'e', 0); lockerAt(26, 37, 's');
    lockerAt(24, 11, 'w'); lockerAt(37, 27, 'e'); lockerAt(24, 18, 's', -0.4); lockerAt(33, 25, 's');
    lockerAt(28, 12, 'w'); lockerAt(37, 14, 'e', 0); lockerAt(36, 4, 'n');

    /* ---- generator: three levers + flywheel ---- */
    {
      const names = ['FUEL PUMP', 'GLOW PLUG', 'STARTER'];
      const st = { seq: [], running: false, cooldown: 0 };
      Wd.objs.gen = st;
      const panelPos = at(33, 34, C / 2 - 0.2, 0);
      const pk = new P.Kit(panelPos.x, panelPos.z, -Math.PI / 2);
      pk.box(2.2, 1.4, 0.3, 0, 1.0, 0, 'p_metal').box(2.3, 0.08, 0.36, 0, 1.74, 0, 'p_dark');
      st.levers = [];
      for (let i = 0; i < 3; i++) {
        const fn = Wd.sol.order[i];
        const g = new THREE.Group(); g.position.set(panelPos.x - 0.2, 1.0, panelPos.z - 0.7 + i * 0.7); g.rotation.y = -Math.PI / 2; scene.add(g);
        const base = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.3, 0.1), M.leverMetal); g.add(base);
        const arm = new THREE.Group(); arm.position.z = 0.05; g.add(arm);
        const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.36, 8), M.leverMetal); rod.position.y = 0.18; arm.add(rod);
        const knob = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), M.lever); knob.position.y = 0.37; arm.add(knob);
        arm.rotation.x = 0.7;
        const lbl = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.105), new THREE.MeshStandardMaterial({ map: NP.Tex.sign(names[fn], null, { bg: '#2a2416', fg: '#e6d7a4' }), roughness: 0.6 }));
        lbl.position.set(0, -0.28, 0.06); g.add(lbl);
        const lv = { fn, arm, down: false, pos: g.position.clone(), lbl, i };
        st.levers.push(lv);
        I.add({ meshes: [knob, rod, base], pos: lv.pos, label: () => (NP.Game.flags.power ? 'Generator running' : 'Pull ' + names[lv.fn]), enabled: () => !NP.Game.flags.power && !lv.down && st.cooldown <= 0, use: () => Wd.pullLever(lv) });
      }
      // flywheel & exhaust vent
      const fwp = at(29, 34, -1.0, 1.42);
      const fw = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.12, 20), L.dynMat('p_steel')); fw.rotation.x = Math.PI / 2; fw.position.set(fwp.x, 0.95, fwp.z); scene.add(fw);
      for (let i = 0; i < 4; i++) { const sp = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.06, 0.08), M.panel); sp.rotation.y = i * Math.PI / 4; sp.position.y = 0.0; fw.add(sp); sp.rotation.set(0, 0, i * Math.PI / 4); }
      st.fly = fw; st.spin = 0;
      st.loop = null;
      // control lamp
      st.lamp = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: 0x220000 })); st.lamp.position.set(panelPos.x - 0.16, 1.55, panelPos.z); scene.add(st.lamp);
    }

    /* ---- fuse panel (reception, beside medical door) ---- */
    {
      const p = at(14, 28, 0.6, -C / 2 + 0.14);
      const g = new THREE.Group(); g.position.set(p.x, 1.35, p.z); scene.add(g);
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.6, 0.18), M.panel); g.add(box);
      const lid = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.02), L.dynMat('p_yellow')); lid.position.z = 0.1; g.add(lid);
      const slot = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.05, 0.03), M.plastic); slot.position.set(0, 0, 0.115); g.add(slot);
      const f = itemMesh('fuse'); f.position.set(0, 0, 0.13); f.visible = false; g.add(f);
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 6), new THREE.MeshBasicMaterial({ color: 0x330000 })); lamp.position.set(0.15, 0.22, 0.11); g.add(lamp);
      Wd.objs.fusePanel = { f, lamp };
      I.add({ meshes: [box, lid], pos: new V3(p.x, 1.35, p.z), enabled: () => !NP.Game.flags.fuseIn,
        label: () => (!NP.Game.flags.power ? 'Fuse panel — no power' : NP.Game.flags.fuse ? 'Install 30A fuse' : 'Fuse panel — FUSE MISSING'),
        use: () => {
          if (!NP.Game.flags.power) { NP.Audio.locked(g.position); NP.UI.toast('The panel is dead. The building has no power.'); return; }
          if (!NP.Game.flags.fuse) { NP.Audio.locked(g.position); NP.UI.toast('The 30A fuse slot is empty.'); return; }
          f.visible = true; NP.Audio.lever(g.position); NP.FX.burstSparks(new V3(p.x, 1.4, p.z + 0.15), 14); flag('fuseIn');
        } });
    }

    /* ---- terminal (lab) ---- */
    {
      const p = at(12, 4, 0.4, -0.55);
      P.crt(p.x - 0.5, 0.78, p.z, 0, null);
      const scrMat = new THREE.MeshBasicMaterial({ map: NP.Tex.screen(['HALE INSTITUTE // RESEARCH NODE 3', '', 'USER: mhale', 'PASSWORD: _', '', '> awaiting input'], '#7fe0a0') });
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.26), scrMat); scr.position.set(p.x - 0.5, 0.97, p.z + 0.152); scene.add(scr);
      Wd.objs.term = { scr, scrMat };
      I.add({ meshes: [scr], pos: new V3(p.x - 0.5, 0.97, p.z), label: () => (NP.Game.flags.terminal ? 'Read terminal logs' : 'Use terminal'),
        use: () => {
          if (NP.Game.flags.terminal) { NP.UI.readDoc(Wd.docs.ev3); return; }
          NP.UI.terminal((txt) => {
            if (txt.trim().toUpperCase() === Wd.sol.pw) {
              NP.Audio.beep(true, scr.position);
              scrMat.map = NP.Tex.screen(['ACCESS GRANTED', '', '> LOG mhale/private ... loaded', '> CELL 0 LOCK ... RELEASED', '', 'it is awake it is awake it is awake'], '#7fe0a0');
              NP.Game.flags.read_ev3 = true; flag('terminal');
              NP.Timers.after(0.4, () => NP.UI.readDoc(Wd.docs.ev3));
              return true;
            }
            NP.Audio.beep(false, scr.position); return false;
          });
        } });
      // other monitors around the lab (decor screens with noise)
      Wd.labScreens = [];
      [[20, 11, 0.4, 0.2, Math.PI], [12, 9, 0.9, -0.3, Math.PI]].forEach(([gx, gz, ox, oz, ry]) => {
        const q = at(gx, gz, ox, oz); const m = P.crt(q.x, 0.95, q.z, ry, new THREE.MeshBasicMaterial({ map: NP.Tex.screen(['SOMNOGRAPH 2.1', 'EEG ch 1-12', '', 'delta ████████', 'theta ██', 'REM ███████████'], '#5fd08a') }));
        Wd.labScreens.push(m);
      });
    }

    /* ---- security: breakers + master + CCTV + door release ---- */
    {
      const st = { set: [false, false, false] };
      do { st.set = [rng() > 0.5, rng() > 0.5, rng() > 0.5]; } while (st.set.every((b, i) => b === Wd.sol.brk[i]));
      Wd.objs.brk = st;
      const bp = at(27, 22, -C / 2 + 0.16, 0.3);
      const bk = new P.Kit(bp.x, bp.z, Math.PI / 2);
      bk.box(1.6, 1.1, 0.25, 0, 1.4, 0, 'p_metal').box(1.7, 0.1, 0.3, 0, 2.0, 0, 'p_dark');
      st.sw = [];
      ['A', 'B', 'C'].forEach((n, i) => {
        const g = new THREE.Group(); g.position.set(bp.x + 0.15, 1.45, bp.z - 0.5 + i * 0.4); g.rotation.y = Math.PI / 2; scene.add(g);
        const b = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.24, 0.06), M.plastic); g.add(b);
        const tog = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 0.05), M.leverMetal); tog.position.z = 0.05; g.add(tog);
        const lbl = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.06), new THREE.MeshBasicMaterial({ map: NP.Tex.sign(n, null, { bg: '#111', fg: '#ddd' }) })); lbl.position.set(0, 0.2, 0.035); g.add(lbl);
        const led = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 4), new THREE.MeshBasicMaterial({ color: 0x000000 })); led.position.set(0, -0.16, 0.04); g.add(led);
        const sw = { tog, led, i };
        st.sw.push(sw);
        I.add({ meshes: [b, tog], pos: g.position.clone(), label: () => 'Breaker ' + n + ' — ' + (st.set[i] ? 'ON' : 'OFF'), enabled: () => !NP.Game.flags.lockOff,
          use: () => { st.set[i] = !st.set[i]; NP.Audio.lever(g.position); Wd.syncBreakers(); } });
      });
      // master lever
      const mg = new THREE.Group(); mg.position.set(bp.x + 0.15, 1.3, bp.z + 0.75); mg.rotation.y = Math.PI / 2; scene.add(mg);
      const mbase = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.4, 0.1), M.leverMetal); mg.add(mbase);
      const marm = new THREE.Group(); marm.position.z = 0.06; mg.add(marm);
      const mrod = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.4, 8), M.leverMetal); mrod.position.y = 0.2; marm.add(mrod);
      const mk = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), M.lever); mk.position.y = 0.42; marm.add(mk);
      marm.rotation.x = 0.8; st.master = marm;
      I.add({ meshes: [mk, mrod, mbase], pos: mg.position.clone(), label: 'Pull MASTER', enabled: () => !NP.Game.flags.lockOff,
        use: () => {
          NP.Audio.lever(mg.position);
          NP.Tweens.add(0.3, (k) => { marm.rotation.x = 0.8 - k * 1.6; }, () => {
            if (st.set.every((b, i) => b === Wd.sol.brk[i])) { NP.Audio.beep(true, mg.position); flag('lockOff'); }
            else { NP.Audio.beep(false, mg.position); NP.FX.burstSparks(mg.position.clone().add(new V3(0.1, 0.3, 0)), 18); NP.UI.toast('Breaker configuration rejected. Check the override sheet.'); NP.Tweens.add(0.6, (k) => { marm.rotation.x = -0.8 + k * 1.6; }); }
          });
        } });
      Wd.syncBreakers();
      // door release button by the security door (inside)
      const rb = at(34, 23, C / 2 - 0.12, 0.7);
      const btn = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.16), new THREE.MeshStandardMaterial({ color: 0x2a6b3a, emissive: 0x0a3010 })); btn.position.set(rb.x, 1.3, rb.z); scene.add(btn);
      I.add({ meshes: [btn], pos: btn.position.clone(), label: () => (NP.Game.flags.lockOff ? 'Release security door' : 'Door release — locked down'), enabled: () => NP.Game.flags.secReached,
        use: () => { if (!NP.Game.flags.lockOff) { NP.Audio.beep(false, btn.position); NP.UI.toast('Lockdown. Disable the containment lock first.'); return; } const d = L.doors.security; d.locked = false; d.setOpen(true); NP.Audio.beep(true, btn.position); } });
    }

    /* ---- containment exit console ---- */
    {
      const p = at(29, 5, 0.6, -0.6);
      const k = new P.Kit(p.x, p.z, 0); k.box(1.4, 1.0, 0.7, 0, 0.5, -0.2, 'p_metal').box(1.4, 0.06, 0.6, 0, 1.0, 0.0, 'p_dark', -0.4).solid(1.4, 0.8, 0, -0.2, 1.1);
      const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.06, 14), new THREE.MeshStandardMaterial({ color: 0x9a1a10, emissive: 0x400000 }));
      btn.position.set(p.x, 1.06, p.z + 0.05); btn.rotation.x = -0.4; scene.add(btn);
      Wd.objs.exitBtn = btn;
      I.add({ meshes: [btn], pos: btn.position.clone(), label: 'Start emergency exit cycle', enabled: () => NP.Game.flags.finalStarted && !NP.Game.flags.cycle, use: () => { NP.Audio.beep(true, btn.position); flag('cycle'); } });
    }

    /* ---- keypad on lab door (outside, medical corridor side) ---- */
    {
      const d = L.doors.lab;
      I.add({ meshes: [d.reader, d.panel], pos: d.center.clone().setY(1.3), label: () => (NP.Game.flags.labOpen ? (d.open ? 'Close door' : 'Open door') : 'Enter door code'),
        enabled: () => !NP.Game.flags.breach,
        use: () => {
          if (NP.Game.flags.labOpen) { Wd.useDoor(d); return; }
          NP.UI.keypad((code) => {
            if (code === Wd.sol.code) { NP.Audio.beep(true, d.center); d.locked = false; d.setOpen(true); flag('labOpen'); return true; }
            NP.Audio.beep(false, d.center); return false;
          });
        } });
    }

    /* ---- generic doors ---- */
    for (const id in L.doors) {
      const d = L.doors[id];
      if (id === 'lab') continue;
      const metas = d.meshes.concat(d.reader ? [d.reader] : []);
      I.add({ meshes: metas, pos: d.center.clone().setY(1.2),
        label: () => Wd.doorLabel(d), enabled: () => d.kind !== 'shutter' && !(d.id === 'cell' && !NP.Game.flags.terminal), use: () => Wd.useDoor(d) });
    }

    /* ---- render-target mirror (recovery) and CCTV (security) ---- */
    Wd.mirror = makeMirror(scene, at(3, 32, -C / 2 + 0.035, 0, 1.6), new V3(1, 0, 0), 1.9, 1.36);
    Wd.cctv = makeCCTV(scene);

    /* ---- scripted props used by scares ---- */
    Wd.app = new NP.Creature(scene); Wd.app.setVisible(false);              // world apparition
    Wd.appCCTV = new NP.Creature(scene, { layer: 2 }); Wd.appCCTV.setVisible(false); // only on CCTV
    Wd.appMirror = new NP.Creature(scene, { layer: 3 }); Wd.appMirror.setVisible(false); // only in the mirror
    // simulation room mannequins (face the walls)
    Wd.mannequins = [];
    [[19, 15, Math.PI], [21, 15, Math.PI], [19, 18, 0], [21, 18, 0.0], [22, 17, -Math.PI / 2]].forEach(([gx, gz, yaw], i) => {
      const p = at(gx, gz, (i % 2) * 0.3, 0); Wd.mannequins.push(new NP.Mannequin(scene, p.x, p.z, yaw, i % 3));
    });
    const wm = at(3, 15, 0, 0.3); Wd.wardMannequin = new NP.Mannequin(scene, wm.x, wm.z, Math.PI / 2, 0);
    // curtains in exam room
    Wd.curtain = makeCurtain(scene, at(19, 22, 0.3, -0.85), 2.2);
    // rolling gurney
    { const g = new THREE.Group(); const k = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; g.add(m); return m; };
      const st = L.dynMat('p_steel');
      k(new THREE.BoxGeometry(0.65, 0.05, 1.9), st, 0, 0.8, 0); k(new THREE.BoxGeometry(0.6, 0.12, 1.8), L.dynMat('p_fabric'), 0, 0.88, 0);
      for (const [x, z] of [[-0.28, -0.85], [0.28, -0.85], [-0.28, 0.85], [0.28, 0.85]]) { k(new THREE.CylinderGeometry(0.02, 0.02, 0.75, 6), st, x, 0.42, z); k(new THREE.SphereGeometry(0.05, 8, 6), M.plastic, x, 0.05, z); }
      // sheet with a shape underneath
      k(new THREE.SphereGeometry(0.3, 12, 8), L.dynMat('p_white'), 0, 0.95, -0.3).scale.set(0.9, 0.35, 2.2);
      const p = at(16, 20, -0.2, 0); g.position.set(p.x, 0, p.z); g.rotation.y = 0.15; scene.add(g);
      Wd.gurney = g; Wd.gurneyBox = L.addBox(p.x - 0.4, p.z - 1.0, p.x + 0.4, p.z + 1.0, 1);
    }
    // ceiling hatch (storage)
    { const p = at(28, 29, 0, 0); const g = new THREE.Group(); g.position.set(p.x - 0.4, 2.98, p.z); scene.add(g);
      const fr = new P.Kit(p.x, p.z, 0, 2.97); fr.box(0.9, 0.04, 0.06, 0, 0, -0.42, 'p_dark').box(0.9, 0.04, 0.06, 0, 0, 0.42, 'p_dark').box(0.06, 0.04, 0.9, -0.42, 0, 0, 'p_dark').box(0.06, 0.04, 0.9, 0.42, 0, 0, 'p_dark');
      const lid = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.03, 0.8), L.dynMat('p_metal')); lid.position.x = 0.4; g.add(lid);
      const hole = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.8), new THREE.MeshBasicMaterial({ color: 0x000000 })); hole.rotation.x = Math.PI / 2; hole.position.set(p.x, 2.995, p.z); scene.add(hole);
      Wd.hatch = { g, pos: p.setY(2.9) };
    }
    // falling tray on storage shelf (false scare)
    { const p = at(27, 30, 0.3, 0.6); const g = new THREE.Group(); g.position.set(p.x, 1.97, p.z);
      const tr = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.03, 0.28), L.dynMat('p_steel')); g.add(tr);
      for (let i = 0; i < 3; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.1, 8), L.dynMat('p_white')); c.position.set(-0.12 + i * 0.12, 0.065, 0); g.add(c); }
      scene.add(g); Wd.tray = { g, base: g.position.clone() };
    }
    // vent grates
    Wd.vents = {};
    const vent = (id, pos, rotX) => { const g = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.04, 0.5), L.dynMat('p_metal', { map: NP.Tex.get('grate').map })); g.position.copy(pos); if (rotX) g.rotation.x = rotX; scene.add(g); const hole = new THREE.Mesh(new THREE.PlaneGeometry(0.66, 0.46), new THREE.MeshBasicMaterial({ color: 0x000000 })); hole.position.copy(pos).add(new V3(0, 0.025, 0)); hole.rotation.x = Math.PI / 2; scene.add(hole); Wd.vents[id] = { g, base: pos.clone(), hole }; };
    vent('service', at(24, 30, 0, 0, 2.97));
    vent('tunnel', at(30, 17, 0, 0.4, 2.47));
    vent('gen', at(27, 36, 0, 0, 4.17));
    // reception lift: a shaft enclosure protruding from the south wall, doors facing north
    { const p = at(19, 36, 0, C / 2); const g = new THREE.Group(); g.position.set(p.x, 0, p.z); scene.add(g);
      const k = new P.Kit(p.x, p.z, 0);
      k.box(0.2, 2.9, 1.4, -1.0, 1.45, -0.7, 'p_steel').box(0.2, 2.9, 1.4, 1.0, 1.45, -0.7, 'p_steel').box(2.2, 0.4, 1.4, 0, 2.7, -0.7, 'p_steel');
      const car = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.5, 1.3), new THREE.MeshStandardMaterial({ color: 0x3a3a34, roughness: 0.6, metalness: 0.4, side: THREE.BackSide })); car.position.set(0, 1.25, -0.68); g.add(car);
      const lamp = new THREE.PointLight(0xffd9a0, 0, 3.2, 2); lamp.position.set(0, 2.2, -0.7); g.add(lamp);
      const dl = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.45, 0.05), L.dynMat('p_steel')); dl.position.set(-0.45, 1.225, -1.37); g.add(dl);
      const dr = dl.clone(); dr.position.x = 0.45; g.add(dr);
      const ind = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.1), new THREE.MeshBasicMaterial({ map: NP.Tex.sign('B4', null, { bg: '#100', fg: '#f43' }) })); ind.position.set(0, 2.62, -1.41); ind.rotation.y = Math.PI; g.add(ind);
      Wd.elevator = { g, dl, dr, lamp, open: 0, pos: new V3(p.x, 1.2, p.z - 1.4) };
      L.addBox(p.x - 1.1, p.z - 1.45, p.x + 1.1, p.z, 3);
    }
    // phone on reception desk
    { const p = at(15, 32, -0.9, 1.1); const ph = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.08, 0.18), M.plastic); ph.position.set(p.x, 1.18, p.z); scene.add(ph); Wd.phone = { m: ph, pos: ph.position.clone(), ringing: false };
      I.add({ meshes: [ph], pos: ph.position.clone(), label: () => (Wd.phone.ringing ? 'Answer phone' : 'Phone — no dial tone'), enabled: () => true, use: () => NP.Scares.answerPhone() });
    }
    // observation booth window highlight + sparks / vents for FX
    NP.FX.addVent(at(23, 33, -0.9, 0, 2.6), new V3(0.3, -0.4, 0), 3, 0.6);
    NP.FX.addVent(at(24, 9, -0.5, 0, 2.3), new V3(0.2, -0.5, 0.2), 5, 0.8);
    NP.FX.addVent(at(32, 18, 0, -0.6, 2.3), new V3(0, -0.6, 0.3), 5, 0.9);
    NP.FX.addVent(at(37, 22, 0.6, 0, 2.3), new V3(-0.3, -0.5, 0), 4, 0.8);
    NP.FX.addVent(at(30, 36, 0, 0.6, 3.9), new V3(0, -0.3, 0), 2, 1.0);
    NP.FX.addSparkPoint(at(24, 31, C / 2 - 0.14, 0, 1.6), 0.05);
    NP.FX.addSparkPoint(at(24, 12, -C / 2 + 0.14, 0, 1.4), 0.08);
    NP.FX.addSparkPoint(at(32, 9, 1.2, 0.6, 6.4), 0.12);
    NP.FX.addSparkPoint(at(20, 7, 0, 0, 2.6), 0.05);
    NP.FX.addFogZone(at(24, 5).x - 1, at(24, 5).z, at(25, 18).x + 1, at(25, 18).z, 0.5, 2.1, 14, 0.08);
    NP.FX.addFogZone(at(24, 17).x, at(24, 17).z - 1, at(37, 18).x, at(37, 18).z + 1, 0.5, 2.1, 14, 0.08);
    NP.FX.addFogZone(at(36, 19).x - 1, at(36, 19).z, at(37, 28).x + 1, at(37, 28).z, 0.5, 2.1, 10, 0.08);
    NP.FX.addFogZone(at(28, 4).x, at(28, 4).z, at(37, 15).x, at(37, 15).z, 0.5, 4, 24, 0.07);
    NP.FX.addFogZone(at(26, 32).x, at(26, 32).z, at(33, 37).x, at(33, 37).z, 0.5, 3, 8, 0.06);
    NP.FX.addFogZone(at(7, 1).x, at(7, 1).z, at(37, 2).x, at(37, 2).z, 0.6, 2.4, 12, 0.07);
    // positional loops
    Wd.loops = { hum: [NP.Audio.makeLoop('hum'), NP.Audio.makeLoop('hum')], vent: [NP.Audio.makeLoop('vent'), NP.Audio.makeLoop('vent')], gen: NP.Audio.makeLoop('gen'), steam: NP.Audio.makeLoop('steam') };
    Wd.ventSources = [at(24, 30, 0, 0, 2.9), at(24, 9, 0, 0, 2.3), at(32, 17, 0, 0, 2.3), at(37, 22, 0, 0, 2.3), at(15, 20, 0.9, 0, 2.9), at(7, 14, 0, 0, 2.9), at(33, 9, 0, 0, 5)];
    Wd.steamSources = [at(24, 9, -0.5, 0, 2.3), at(32, 18, 0, -0.6, 2.3), at(37, 22, 0.6, 0, 2.3), at(23, 33, -0.9, 0, 2.6)];
  };

  /* per-playthrough puzzle solutions (or restore saved ones) */
  Wd.rollSolutions = function (rng, saved) {
    if (saved) Wd.sol = JSON.parse(JSON.stringify(saved));
    else {
      const code = String(rng.int(1000, 9999));
      const pw = rng.pick(['ORPHEUS', 'MORPHEUS', 'LAZARUS', 'SOMNUS', 'HYPNOS', 'ICARUS']);
      let brk; do { brk = [rng() > 0.5, rng() > 0.5, rng() > 0.5]; } while (brk.every((b) => b === brk[0]));
      Wd.sol = { code, pw, brk, order: rng.shuffle([0, 1, 2]) };
    }
    docs(Wd.sol);
    const names = ['FUEL PUMP', 'GLOW PLUG', 'STARTER'];
    const g = Wd.objs.gen;
    if (g) g.levers.forEach((lv) => { lv.fn = Wd.sol.order[lv.i]; lv.lbl.material.map = NP.Tex.sign(names[lv.fn], null, { bg: '#2a2416', fg: '#e6d7a4' }); lv.lbl.material.needsUpdate = true; });
    const b = Wd.objs.brk;
    if (b) { const r = NP.rand; do { b.set = [r() > 0.5, r() > 0.5, r() > 0.5]; } while (b.set.every((v, i) => v === Wd.sol.brk[i])); }
    // the code's second half is scrawled on room 102's wall
    if (Wd.scrawl) { Wd.scrawl.material.map = NP.Tex.scrawl(Wd.sol.code.slice(2) + '  ||||', 512, 256, 150); Wd.scrawl.material.needsUpdate = true; }
  };

  /* =============== doors =============== */
  Wd.doorLabel = function (d) {
    const F = NP.Game.flags;
    if (d.locked) {
      if (d.lock === 'L1') return F.card1 ? 'Swipe Level 1 card' : 'Locked — Access Level 1';
      if (d.lock === 'L2') return F.card2 ? 'Swipe Level 2 card' : 'Locked — Access Level 2';
      if (d.lock === 'fuse') return 'Locked — no power to the door';
      if (d.lock === 'contain') return 'Sealed — containment lock engaged';
      if (d.lock === 'exit') return 'Blast door — sealed';
      if (d.lock === 'script') return d.id === 'tunnel' ? 'Maintenance hatch — jammed' : d.id === 'cell' ? 'Cell 0 — locked from the lab terminal' : 'Locked';
      if (d.lock === 'jam') return 'Jammed';
      return 'Locked';
    }
    return d.open ? 'Close door' : 'Open door';
  };
  Wd.useDoor = function (d) {
    const F = NP.Game.flags, Pl = NP.Player;
    if (d.t > 0.02 && d.t < 0.98) return;
    if (d.locked) {
      if (d.lock === 'L1' && F.card1) { d.locked = false; NP.Audio.beep(true, d.center); }
      else if (d.lock === 'L2' && F.card2) { d.locked = false; NP.Audio.beep(true, d.center); }
      else { NP.Audio.locked(d.center); if (d.lock === 'jam') { NP.Player.addShake(0.15, 0.2); } return; }
    }
    if (d.kind === 'hinged' && !d.open) {
      const c = d.center;
      d.swingDir = d.axis === 'x' ? (Pl.pos.x < c.x ? -1 : 1) : (Pl.pos.z < c.z ? 1 : -1);
    }
    d.setOpen(!d.open);
  };

  /* =============== generator =============== */
  Wd.pullLever = function (lv) {
    const st = Wd.objs.gen;
    lv.down = true; NP.Audio.lever(lv.pos);
    NP.Tweens.add(0.25, (k) => { lv.arm.rotation.x = 0.7 - k * 1.4; });
    st.seq.push(lv.fn);
    const i = st.seq.length - 1;
    if (st.seq[i] !== i) {
      // wrong order: flood + reset
      st.cooldown = 3;
      NP.Timers.after(0.35, () => { NP.Audio.metal(lv.pos, 0.7, 0.7); NP.FX.burstSparks(lv.pos.clone().add(new V3(-0.2, 0.3, 0)), 16); NP.FX.burstSmoke(NP.Level.center(29, 34, 1.5), 12, 1.2); NP.UI.toast('The engine coughs and floods. It needs a moment to reset.'); NP.Bus.emit('noise', { x: lv.pos.x, z: lv.pos.z, r: 12 }); });
      NP.Timers.after(2.8, () => { st.seq = []; st.levers.forEach((l) => { l.down = false; NP.Tweens.add(0.3, (k) => { l.arm.rotation.x = -0.7 + k * 1.4; }); }); st.cooldown = 0; });
      st.lamp.material.color.setRGB(2, 0.1, 0);
      NP.Timers.after(2.8, () => st.lamp.material.color.setRGB(0.2, 0, 0));
      return;
    }
    if (i === 1) { NP.Timers.after(0.5, () => NP.Audio.beep('key', lv.pos)); st.lamp.material.color.setRGB(2, 1.3, 0); }
    if (i === 2) { NP.Game.flags.power = true; NP.Game.onFlag('power'); }
  };
  Wd.syncBreakers = function () {
    const st = Wd.objs.brk; if (!st) return;
    st.sw.forEach((s, i) => { s.tog.rotation.x = st.set[i] ? -0.5 : 0.5; s.tog.position.y = st.set[i] ? 0.03 : -0.03; s.led.material.color.setRGB(st.set[i] ? 0.1 : 1.6, st.set[i] ? 1.5 : 0.05, 0.05); });
    if (NP.Game && NP.Game.flags.lockOff) st.master.rotation.x = -0.8;
  };

  /* =============== lockers =============== */
  Wd.enterLocker = function (lk) {
    const Pl = NP.Player;
    NP.AI.notifyHide();
    Pl.hidden = lk; Pl.yaw = lk.yaw; Pl.pitch = 0;
    NP.Audio.metal(lk.pos, 0.35, 1.7);
    NP.Tweens.add(0.25, (k) => { lk.hinge.rotation.y = Math.sin(k * Math.PI) * -1.2; });
    NP.UI.toast('Hiding. Stay still and quiet.');
    NP.Bus.emit('hide', { on: true, locker: lk });
  };
  Wd.exitLocker = function () {
    const Pl = NP.Player, lk = Pl.hidden; if (!lk) return;
    Pl.hidden = null; Pl.pos.set(lk.front.x, 0, lk.front.z);
    L.collideCircle(Pl.pos, Pl.r, 'player');
    NP.Audio.metal(lk.pos, 0.3, 1.8);
    NP.Tweens.add(0.35, (k) => { lk.hinge.rotation.y = Math.sin(k * Math.PI) * -1.4; });
    NP.Bus.emit('hide', { on: false, locker: lk });
  };
  Wd.pullFromLocker = function (lk) {
    NP.Tweens.add(0.15, (k) => { lk.hinge.rotation.y = -k * 1.9; });
    NP.Audio.metal(lk.pos, 1.2, 1.2);
    NP.Game.onCaught(NP.AI, true);
  };

  /* =============== mirror (two-way glass) =============== */
  function makeMirror(scene, pos, normal, w, h) {
    const res = NP.q().mirror;
    const geo = new THREE.PlaneGeometry(w, h);
    const tm = new THREE.Matrix4();
    const rt = res ? new THREE.WebGLRenderTarget(res * 2, res, { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter }) : null;
    const mat = new THREE.ShaderMaterial({
      uniforms: { tMap: { value: rt ? rt.texture : null }, uTM: { value: tm }, uOn: { value: rt ? 1 : 0 }, uDirt: { value: NP.Tex.get('concrete').roughnessMap } },
      vertexShader: 'uniform mat4 uTM; varying vec4 vC; varying vec2 vUv; void main(){ vUv=uv; vC = uTM*modelMatrix*vec4(position,1.0); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform sampler2D tMap; uniform sampler2D uDirt; uniform float uOn; varying vec4 vC; varying vec2 vUv; void main(){ vec3 r = uOn>0.5 ? texture2DProj(tMap, vC).rgb : vec3(0.0); float d = texture2D(uDirt, vUv*1.5).r; vec3 c = r*0.55*(0.6+0.4*d) + vec3(0.004,0.006,0.007); gl_FragColor = vec4(c,1.0); }',
    });
    const mesh = new THREE.Mesh(geo, mat); mesh.position.copy(pos); mesh.lookAt(pos.clone().add(normal)); scene.add(mesh);
    const vcam = new THREE.PerspectiveCamera(); vcam.layers.enable(3);
    const mp = new V3(), cp = new V3(), view = new V3(), tgt = new V3(), rot = new THREE.Matrix4(), look = new V3(), up = new V3();
    return {
      mesh, rt, pos,
      render(renderer, sceneR, camera) {
        if (!rt) return;
        camera.getWorldPosition(cp); mp.copy(pos);
        if (cp.distanceTo(mp) > 11) return;
        view.subVectors(mp, cp); if (view.dot(normal) > 0) return;
        if (!NP.Player.canSee(mp, 0.2, 12)) return;
        view.reflect(normal).negate(); view.add(mp);
        rot.extractRotation(camera.matrixWorld);
        look.set(0, 0, -1).applyMatrix4(rot).add(cp);
        tgt.subVectors(mp, look); tgt.reflect(normal).negate(); tgt.add(mp);
        vcam.position.copy(view); up.set(0, 1, 0).applyMatrix4(rot).reflect(normal); vcam.up.copy(up); vcam.lookAt(tgt);
        vcam.far = camera.far; vcam.fov = camera.fov; vcam.aspect = camera.aspect; vcam.near = 0.05; vcam.updateProjectionMatrix(); vcam.updateMatrixWorld();
        tm.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1).multiply(vcam.projectionMatrix).multiply(vcam.matrixWorldInverse);
        mesh.visible = false;
        const beam = NP.Player.beam.visible; NP.Player.beam.visible = false;
        renderer.setRenderTarget(rt); renderer.clear(); renderer.render(sceneR, vcam); renderer.setRenderTarget(null);
        mesh.visible = true; NP.Player.beam.visible = beam;
      },
    };
  }

  /* =============== CCTV =============== */
  function makeCCTV(scene) {
    const rt = new THREE.WebGLRenderTarget(320, 200, { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
    const cam = new THREE.PerspectiveCamera(78, 1.6, 0.1, 40); cam.layers.enable(2);
    const cp = at(34, 25, 0.9, 0.9, 2.7); cam.position.copy(cp); cam.lookAt(at(29, 21, 0, 0, 0.9));
    // physical camera housing
    const hous = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.3), new THREE.MeshStandardMaterial({ color: 0xdedcd2, roughness: 0.5 })); hous.position.copy(cp); hous.lookAt(at(29, 21, 0, 0, 0.9)); scene.add(hous);
    const camLed = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 4), new THREE.MeshBasicMaterial({ color: 0xff2010 })); camLed.position.copy(cp).add(new V3(0, -0.07, 0)); scene.add(camLed);
    const mat = new THREE.ShaderMaterial({
      uniforms: { tMap: { value: rt.texture }, uT: { value: 0 }, uNoise: { value: 0.15 } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform sampler2D tMap; uniform float uT; uniform float uNoise; varying vec2 vUv; float h(vec2 p){return fract(sin(dot(p,vec2(12.98,78.23)))*43758.5);} void main(){ vec2 uv=vUv; uv.x += (h(vec2(floor(uv.y*60.0),floor(uT*12.0)))-0.5)*0.004; vec3 c = texture2D(tMap, uv).rgb; float l = dot(c, vec3(0.3,0.59,0.11))*3.2; l = pow(l,0.8); l += (h(uv*vec2(320.0,200.0)+uT)-0.5)*uNoise; l *= 0.85+0.15*sin(uv.y*600.0); gl_FragColor = vec4(vec3(0.55,1.0,0.7)*l*1.6, 1.0); }',
    });
    // monitor wall above the security desk (north wall)
    const screens = [];
    const base = at(29, 20, 0.6, -C / 2 + 0.25);
    const k = new P.Kit(base.x, base.z, 0); k.box(3.6, 1.2, 0.3, 0, 2.0, 0, 'p_dark');
    for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) {
      const big = i === 1 && j === 0;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.5), big ? mat : new THREE.MeshBasicMaterial({ map: NP.Tex.screen(['CAM 0' + (i * 2 + j + 2), '', 'SIGNAL LOST'], '#5fae7a') }));
      m.position.set(base.x - 1.15 + i * 1.15, 1.72 + j * 0.56, base.z + 0.16); scene.add(m); screens.push(m);
    }
    const label = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.1), new THREE.MeshBasicMaterial({ map: NP.Tex.sign('CAM 01 SECURITY', null, { bg: '#000', fg: '#9f9' }) })); label.position.set(base.x, 1.42, base.z + 0.165); scene.add(label);
    let frame = 0;
    return {
      cam, rt, mat, main: screens[1], pos: screens[1].position.clone(),
      render(renderer, sceneR) {
        frame++; mat.uniforms.uT.value = NP.Timers.time;
        if (frame % 3) return;
        const z = L.zoneAt(NP.Player.pos.x, NP.Player.pos.z);
        if (!z || z.name !== 'Security Control') return;
        const beam = NP.Player.beam.visible; NP.Player.beam.visible = false;
        const hand = NP.Player.hand.visible; NP.Player.hand.visible = false;
        // stand-in body for the player on CCTV: a dark silhouette
        Wd.playerProxy.position.set(NP.Player.pos.x, 0, NP.Player.pos.z); Wd.playerProxy.rotation.y = NP.Player.yaw; Wd.playerProxy.visible = true;
        renderer.setRenderTarget(rt); renderer.clear(); renderer.render(sceneR, cam); renderer.setRenderTarget(null);
        Wd.playerProxy.visible = false; NP.Player.beam.visible = beam; NP.Player.hand.visible = hand;
      },
    };
  }

  /* =============== cloth curtain =============== */
  function makeCurtain(scene, pos, width) {
    const geo = new THREE.PlaneGeometry(width, 2.1, 24, 8);
    const base = geo.attributes.position.array.slice();
    const mat = new THREE.MeshStandardMaterial({ color: 0x8fa79a, roughness: 0.9, side: THREE.DoubleSide, transparent: true, opacity: 0.94 });
    const m = new THREE.Mesh(geo, mat); m.position.set(pos.x, 1.15, pos.z); m.castShadow = true; m.receiveShadow = true; scene.add(m);
    const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, width + 0.2, 6), L.dynMat('p_steel')); rail.rotation.z = Math.PI / 2; rail.position.set(pos.x, 2.22, pos.z); scene.add(rail);
    const st = { m, base, open: 0, sway: 0, width, x0: pos.x };
    st.update = (t) => {
      const p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const bx = base[i * 3], by = base[i * 3 + 1];
        const gather = 1 - st.open * 0.75;
        const x = (bx + width / 2) * gather - width / 2;
        const fold = Math.sin(bx * 9) * 0.06 * (1 + st.open * 2);
        const swing = st.sway * Math.sin(t * 2.3 + bx) * (1.05 - (by + 1.05) / 2.1) * 0.25;
        p.setXYZ(i, x, by, fold + swing + NP.noise1(t * 0.6 + bx) * 0.015);
      }
      p.needsUpdate = true; geo.computeVertexNormals();
      st.sway = NP.damp(st.sway, 0, 0.6, 0.016);
    };
    I.add({ meshes: [m], pos: new V3(pos.x, 1.2, pos.z), label: () => (st.open > 0.5 ? 'Close curtain' : 'Pull curtain'), use: () => { const o = st.open > 0.5 ? 0 : 1; NP.Audio.paper(); NP.Tweens.add(0.5, (k) => { st.open = o ? k : 1 - k; }); NP.Bus.emit('curtain', { open: o }); } });
    return st;
  }

  /* =============== state from flags (new game / checkpoints) =============== */
  Wd.reset = function () {
    const F = NP.Game.flags;
    // items
    for (const id in Wd.items) { const it = Wd.items[id]; it.taken = !!F[id] || (id === 'flashlight' && F.flashlight) || (it.kind === 'evidence' && F[id]); it.mesh.visible = !it.taken; }
    if (F.card2) Wd.items.card2.taken = true, Wd.items.card2.mesh.visible = false;
    if (F.fuse) Wd.items.fuse.taken = true, Wd.items.fuse.mesh.visible = false;
    // drawer
    const dr = Wd.objs.drawer; dr.st.open = !!F.card1; dr.g.position.z = dr.z0 - (F.card1 ? 0.32 : 0); dr.card.visible = !F.card1;
    // generator
    const g = Wd.objs.gen; g.seq = []; g.cooldown = 0;
    g.levers.forEach((l) => { l.down = !!F.power; l.arm.rotation.x = F.power ? -0.7 : 0.7; });
    g.lamp.material.color.setRGB(F.power ? 0.1 : 0.25, F.power ? 2 : 0, 0);
    Wd.objs.fusePanel.f.visible = !!F.fuseIn; Wd.objs.fusePanel.lamp.material.color.setRGB(F.fuseIn ? 0.1 : F.power ? 2 : 0.2, F.fuseIn ? 1.8 : 0, 0);
    // breakers
    if (F.lockOff) Wd.objs.brk.set = Wd.sol.brk.slice();
    Wd.syncBreakers();
    if (!F.lockOff) Wd.objs.brk.master.rotation.x = 0.8;
    // terminal screen
    if (!F.terminal) Wd.objs.term.scrMat.map = NP.Tex.screen(['HALE INSTITUTE // RESEARCH NODE 3', '', 'USER: mhale', 'PASSWORD: _', '', '> awaiting input'], '#7fe0a0');
    // scripted props back to rest
    Wd.app.setVisible(false); Wd.appCCTV.setVisible(false); Wd.appMirror.setVisible(false);
    Wd.mannequins.forEach((m, i) => { m.root.rotation.y = m.yaw; m.setPose(i % 3, true); });
    Wd.wardMannequin.root.position.copy(at(3, 15, 0, 0.3)); Wd.wardMannequin.root.rotation.y = Math.PI / 2; Wd.wardMannequin.setPose(0, true);
    Wd.tray.g.position.copy(Wd.tray.base); Wd.tray.g.rotation.set(0, 0, 0);
    Wd.hatch.g.rotation.z = 0;
    for (const k in Wd.vents) { const v = Wd.vents[k]; v.g.position.copy(v.base); v.g.rotation.set(0, 0, 0); }
    Wd.elevator.open = 0; Wd.elevator.lamp.intensity = 0;
    Wd.lockers.forEach((l) => { l.hinge.rotation.y = 0; });
    Wd.curtain.open = 0;
    const gp = at(16, 20, -0.2, 0); Wd.gurney.position.set(gp.x, 0, gp.z); Wd.gurney.rotation.y = 0.15; Wd.gurneyBox.disabled = false;
    Wd.phone.ringing = false;
    // doors from flags
    const D = L.doors;
    for (const id in D) { const d = D[id]; d.locked = !!d.lock; d.open = !!d.startOpen; d.t = d.open ? 1 : 0; d.speed2 = null; d.swingDir = 1; }
    if (F.card1) D.service.locked = false;
    if (F.fuseIn) { D.medical.locked = false; D.medical.open = true; D.medical.t = 1; }
    if (F.labOpen) { D.lab.locked = false; }
    if (F.terminal) { D.cell.locked = false; D.cell.open = true; D.cell.t = 1; }
    if (F.breach) { D.tunnel.locked = false; D.tunnel.open = true; D.tunnel.t = 1; D.lab.locked = true; D.lab.lock = 'jam'; D.lab.open = false; D.lab.t = 0; }
    if (F.card2) D.security.locked = false;
    if (F.secReached && !F.lockOff) { D.security.locked = true; D.security.open = false; D.security.t = 0; }
    if (F.lockOff) { D.contain.locked = false; D.security.locked = false; }
    if (F.finalStarted) { D.contain.open = false; D.contain.t = 0; D.contain.locked = true; D.contain.lock = 'jam'; }
    if (F.blastOpen) { D.blast.locked = false; D.blast.open = true; D.blast.t = 1; }
    if (!F.breach) { D.lab.lock = 'keypad'; }
    if (!F.finalStarted) D.contain.lock = 'contain';
    for (const id in D) D[id].pose();
  };
  Wd.update = function (dt, t) {
    const F = NP.Game.flags;
    // glints pulse
    const pulse = 0.6 + Math.sin(t * 3) * 0.4;
    for (const g of Wd.glints) { const v = g.parent && g.parent.visible !== false ? pulse * 0.9 : 0; g.material.color.setScalar(v); }
    // generator
    const gen = Wd.objs.gen;
    gen.spin = NP.damp(gen.spin, F.power ? 14 : 0, 0.8, dt); gen.fly.rotation.y += gen.spin * dt;
    if (gen.cooldown > 0) gen.cooldown -= dt;
    // mannequins
    Wd.mannequins.forEach((m) => m.update(dt)); Wd.wardMannequin.update(dt);
    Wd.curtain.update(t);
    // elevator doors
    const el = Wd.elevator; el.dl.position.x = -0.45 - el.open * 0.85; el.dr.position.x = 0.45 + el.open * 0.85;
    // apparitions
    if (Wd.app.root.visible) Wd.app.update(dt);
    if (Wd.appCCTV.root.visible) Wd.appCCTV.update(dt);
    if (Wd.appMirror.root.visible) Wd.appMirror.update(dt);
    // positional ambience: nearest active fluorescent fixtures hum, nearest vents roar
    const pp = NP.Player.pos;
    const fl = L.fixtures.filter((f) => f.kind === 'fluor' && f.cur > 0.05).sort((a, b) => a.pos.distanceToSquared(pp) - b.pos.distanceToSquared(pp));
    Wd.loops.hum.forEach((lp, i) => { const f = fl[i]; NP.Audio.setLoop(lp, f ? f.pos : null, f ? 0.06 * Math.min(1, f.cur) : 0); });
    const vs = Wd.ventSources.slice().sort((a, b) => a.distanceToSquared(pp) - b.distanceToSquared(pp));
    Wd.loops.vent.forEach((lp, i) => NP.Audio.setLoop(lp, vs[i], 0.22));
    NP.Audio.setLoop(Wd.loops.gen, at(29, 34, 0.6, 0.6, 1), F.power ? 0.35 : 0);
    const ss = Wd.steamSources.slice().sort((a, b) => a.distanceToSquared(pp) - b.distanceToSquared(pp));
    NP.Audio.setLoop(Wd.loops.steam, ss[0], 0.12);
  };
  Wd.renderTargets = function (renderer, scene, camera) {
    if (Wd.mirror) Wd.mirror.render(renderer, scene, camera);
    if (Wd.cctv) Wd.cctv.render(renderer, scene);
  };
})(window.NP);
