/* NIGHTMARE PROTOCOL — game orchestrator: boot, loop, light pool, story, objectives, cinematics, death, checkpoints */
'use strict';
(function (NP) {
  const L = NP.Level, C = L.C, V3 = THREE.Vector3;
  const G = (NP.Game = { state: 'boot', flags: {}, deaths: 0, playTime: 0 });
  const at = (gx, gz, ox = 0, oz = 0, y = 0) => new V3((gx + 0.5) * C + ox, y, (gz + 0.5) * C + oz);
  const nextFrame = () => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));

  /* ================= BOOT ================= */
  G.boot = async function () {
    const UI = NP.UI; UI.init(); UI.screen('loading');
    const q = NP.q();
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', stencil: false });
    } catch (e) { UI.loading('WebGL is not available in this browser. Try a recent Chrome, Edge or Firefox with hardware acceleration on.', 0); return; }
    G.renderer = renderer;
    renderer.outputEncoding = THREE.LinearEncoding;
    renderer.toneMapping = THREE.NoToneMapping;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor(0x000000, 1);
    document.getElementById('view').appendChild(renderer.domElement);
    renderer.domElement.addEventListener('webglcontextlost', (e) => { e.preventDefault(); G.contextLost = true; UI.overlay('ctxlost', true); NP.Input.unlock(); });
    renderer.domElement.addEventListener('webglcontextrestored', () => { UI.overlay('ctxlost', true); });
    NP.Input.init(renderer.domElement);

    const scene = (G.scene = new THREE.Scene());
    scene.fog = new THREE.FogExp2(0x05080a, 0.05);
    const camera = (G.camera = new THREE.PerspectiveCamera(NP.settings.fov, innerWidth / innerHeight, 0.05, 120));
    scene.add(camera);
    scene.add(new THREE.HemisphereLight(0x3a4a58, 0x0a0a08, 0.07));
    // dynamic light pool (fixed count avoids shader recompiles)
    G.pool = [];
    for (let i = 0; i < 8; i++) { const l = new THREE.PointLight(0xffffff, 0, 8, 2); l.visible = i < q.lights; scene.add(l); G.pool.push({ l, f: null }); }
    NP.FX.eventLight = new THREE.PointLight(0xffaa66, 0, 6, 2); scene.add(NP.FX.eventLight);

    G.applyRenderScale();
    NP.FX.init(renderer);
    addEventListener('resize', () => G.onResize());

    const steps = [
      ['Generating surfaces', () => ['concrete', 'tileFloor', 'tileWall', 'paint', 'metal', 'grate', 'ceiling', 'lino', 'labPanel', 'skin'].forEach((t) => NP.Tex.get(t))],
      ['Pouring concrete', () => { L.build(scene); }],
      ['Furnishing the wards', () => { G.rng = NP.makeRng((Math.random() * 1e9) | 0); NP.Props.populate(G.rng); }],
      ['Wiring the facility', () => { NP.FX.initParticles(scene, camera); NP.World.build(scene, G.rng); }],
      ['Baking emergency lighting', () => { L.finalize(scene); }],
      ['Waking the patient', () => { NP.Player.init(scene, camera); NP.AI.init(scene); NP.Scares.init(scene); G.buildEndGate(scene); }],
      ['Compiling shaders', () => { G.flags = {}; NP.World.reset(); G.applyLighting(true); renderer.compile(scene, camera); }],
    ];
    for (let i = 0; i < steps.length; i++) {
      UI.loading(steps[i][0] + '…', i / steps.length);
      await nextFrame();
      try { steps[i][1](); } catch (e) { console.error(e); UI.loading('Failed while ' + steps[i][0].toLowerCase() + ': ' + e.message, i / steps.length); throw e; }
    }
    UI.loading('Ready', 1);
    // player proxy for CCTV
    { const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.8 });
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.2, 1.35, 10), m); b.position.y = 0.75; g.add(b);
      const h = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), m); h.position.y = 1.58; g.add(h);
      g.traverse((o) => o.layers.set(2)); g.visible = false; scene.add(g); NP.World.playerProxy = g; }
    G.cpData = NP.store.get('cp', null);
    UI.setContinue(G.cpData);
    G.toMenu();
    G.last = performance.now();
    requestAnimationFrame(G.frame);
    // exposed for automated testing and debugging
    window.NPDebug = G.debugApi();
  };

  G.applyRenderScale = function () {
    const q = NP.q();
    const pr = q.scale * (q.dprBoost ? Math.min(devicePixelRatio || 1, 1.5) : 1);
    G.renderer.setPixelRatio(pr);
    G.renderer.setSize(innerWidth, innerHeight);
    G.renderer.shadowMap.enabled = q.shadows > 0;
  };
  G.onResize = function () {
    G.camera.aspect = innerWidth / innerHeight; G.camera.updateProjectionMatrix();
    G.applyRenderScale(); NP.FX.resize();
  };
  G.setFov = (v) => { if (G.camera) { G.camera.fov = v; G.camera.updateProjectionMatrix(); } };
  G.applyQualityLive = function () {
    if (!G.renderer) return;
    const q = NP.q();
    G.applyRenderScale(); NP.FX.resize();
    G.pool.forEach((p, i) => { p.l.visible = i < q.lights; });
    const fl = NP.Player.flash;
    if (fl) { fl.castShadow = q.shadows > 0; if (fl.castShadow) { fl.shadow.mapSize.set(q.shadows, q.shadows); if (fl.shadow.map) { fl.shadow.map.dispose(); fl.shadow.map = null; } } }
  };
  G.toggleFullscreen = function () {
    try {
      if (!document.fullscreenElement) { const p = document.documentElement.requestFullscreen(); if (p && p.catch) p.catch(() => NP.UI.toast('Fullscreen is not available here.')); }
      else document.exitFullscreen();
    } catch (e) { NP.UI.toast('Fullscreen is not available here.'); }
  };

  /* ================= MENU ================= */
  G.toMenu = function () {
    G.state = 'menu'; NP.Input.unlock();
    NP.Audio.stopAll(); NP.AI.reset(); NP.Scares.reset([]);
    NP.Player.cine = { pos: at(15, 35, 0, 0.6, 1.7), look: at(15, 29, 0, 0, 1.4), rate: 1 };
    NP.FX.setFade(1); NP.FX.fadeTo(0, 0.6); NP.FX.dof(0); NP.FX.blur(0);
    G.flags = { power: true, menu: true }; G.applyLighting(true);
    NP.UI.setContinue(G.cpData);
    NP.UI.screen('menu');
    G.menuT = 0;
  };
  G.menuAction = function (act) {
    NP.Audio.init(); NP.Audio.startAmbience();
    if (act === 'new') G.newGame();
    else if (act === 'continue') { if (G.cpData) G.loadCheckpoint(G.cpData); }
    else if (act === 'settings') { G.settingsBack = G.state === 'pause' ? 'pause' : 'menu'; NP.UI.screen('settings'); }
    else if (act === 'credits') NP.UI.screen('credits');
    else if (act === 'back') NP.UI.screen(G.settingsBack === 'pause' && G.state === 'pause' ? 'pause' : 'menu');
    else if (act === 'resume') G.resume();
    else if (act === 'restartcp') { if (G.cpData) G.loadCheckpoint(G.cpData); else G.newGame(); }
    else if (act === 'restart') G.newGame();
    else if (act === 'menu') G.toMenu();
    else if (act === 'play') G.resume();
  };

  /* ================= NEW GAME / CHECKPOINTS ================= */
  G.newGame = function () {
    NP.World.rollSolutions(NP.makeRng((Math.random() * 1e9) | 0));
    G.deaths = 0; G.playTime = 0; G.docsRead = 0;
    G.startFrom({ id: 'start', label: 'Recovery Room', flags: {}, sol: NP.World.sol, spares: 0, battery: 0.7, pos: [at(4, 32, 0.2, 1.05).x, at(4, 32, 0.2, 1.05).z], yaw: -Math.PI / 2, scares: [], time: 0, deaths: 0, owned: false }, true);
  };
  G.CP = {
    start: 'Recovery Room', power: 'Generator Room', medical: 'Medical Wing', cell: 'Research Laboratory', security: 'Security Control',
    unlock: 'Containment Override', final: 'Containment Chamber', escape: 'Emergency Exit',
  };
  G.saveCheckpoint = function (id, pos, yaw) {
    const P = NP.Player;
    const cp = { id, label: G.CP[id] || id, flags: Object.assign({}, G.flags), sol: NP.World.sol, spares: P.light.spares, battery: Math.max(0.35, P.light.battery), owned: P.light.owned,
      pos: pos ? [pos.x, pos.z] : [P.pos.x, P.pos.z], yaw: yaw != null ? yaw : P.yaw, scares: Array.from(NP.Scares.done), time: G.playTime, deaths: G.deaths };
    G.cpData = cp; NP.store.set('cp', cp);
    const reached = NP.store.get('reached', []); if (!reached.includes(id)) { reached.push(id); NP.store.set('reached', reached); }
    NP.UI.toast('Checkpoint — ' + cp.label, 2.2);
  };
  G.loadCheckpoint = function (cp) { G.startFrom(cp, cp.id === 'start'); };
  G.startFrom = function (cp, intro) {
    NP.Audio.init(); NP.Audio.startAmbience(); NP.Audio.stopAll();
    NP.Timers.clear(); NP.Tweens.clear();
    if (cp.sol) NP.World.rollSolutions(null, cp.sol);
    G.flags = Object.assign({}, cp.flags);
    G.deaths = cp.deaths || G.deaths || 0; G.playTime = cp.time || 0;
    NP.World.reset(); NP.Scares.reset(cp.scares || []);
    G.applyLighting(true);
    const P = NP.Player;
    P.reset(new V3(cp.pos[0], 0, cp.pos[1]), cp.yaw);
    P.light.owned = !!cp.owned || !!G.flags.flashlight; P.light.on = P.light.owned; P.light.battery = cp.battery; P.light.spares = cp.spares || 0; P.light.reloadT = 0;
    if (L.glassPanes) L.glassPanes.forEach((g) => { g.visible = !G.flags.breach; });
    G.endGate.visible = false;
    NP.AI.reset(); G.setupAI();
    G.cpData = cp;
    G.timerT = null; NP.UI.timer(null);
    G.zoneSeen = {}; G.curZone = null;
    G.applyQualityLive();
    NP.FX.setFade(1); NP.FX.dof(0); NP.FX.blur(0);
    NP.UI.screen('play'); G.state = 'play'; G.updateObjective();
    G.onCheckpointLoaded(cp);
    if (intro) G.intro(); else { NP.FX.fadeTo(0, 1.5); P.cine = null; }
    NP.Input.lock();
  };
  G.onCheckpointLoaded = function (cp) {
    const F = G.flags;
    if (F.breach && !F.secReached) NP.Audio.alarm(true);
    if (cp.id === 'escape' && F.blastOpen) G.startEscape(true);
    if (F.cycle && !F.blastOpen) { G.timerT = 45; NP.Audio.alarm(true); }
  };

  /* ================= AI per story phase ================= */
  G.setupAI = function () {
    const F = G.flags, AI = NP.AI;
    const cells = (keys) => { const out = []; for (let z = 0; z < L.H; z++) for (let x = 0; x < L.W; x++) if (keys.includes(L.ch(x, z))) out.push([x, z]); return out; };
    if (F.blastOpen) { AI.setPhase('final', { zones: ['c', 'x', 'e'], spawns: cells(['c']) }); const s = at(32, 9, 1.2, 2.6); AI.spawnAt(s.x, s.z, Math.PI, 'hunt'); }
    else if (F.finalStarted) { AI.setPhase('final', { zones: ['c'], spawns: cells(['c']) }); if (!G.finalIntro) { const s = AI.pickHiddenSpawn(10) || at(35, 12); AI.spawnAt(s.x, s.z, 0, 'hunt'); } }
    else if (F.secReached) { AI.setPhase('hunter', { zones: ['t'], spawns: cells(['t']).filter(([x, z]) => z < 19 || x > 35) }); AI.disappear(8); }
    else if (F.breach) { AI.setPhase('breach', { zones: ['l', 't'], spawns: cells(['l']) }); }
    else if (F.fuseIn) { AI.setPhase('stalker', { zones: ['m', 'w'], spawns: cells(['w', 'm']).filter(([x, z]) => z < 22), patrol: cells(['w', 'm']) }); AI.disappear(F.ev1 ? 10 : 35); }
    else AI.setPhase('off');
  };

  /* ================= LIGHTING FROM STORY STATE ================= */
  G.applyLighting = function (instant) {
    const F = G.flags, s = (c, v) => L.setCircuit(c, v, !instant);
    const pw = !!F.power;
    s('emer', F.breach || F.wardBlackout ? 1.0 : pw ? 0.35 : 0.6);
    s('recov', 1); s('recepF', F.breach ? 0 : 1);
    ['recep', 'service', 'store', 'gen'].forEach((c) => s(c, pw ? 1 : 0));
    const medOn = pw && !F.wardBlackout && !F.breach;
    s('med', medOn ? 1 : 0); s('sim', medOn ? 1 : 0); s('ward', medOn ? 1 : 0);
    s('lab', pw && !F.breach ? 1 : 0); s('cell', 0);
    s('tunnel', F.breach ? 0.85 : 0); s('sec', F.secReached ? 1 : 0);
    s('cont', F.lockOff ? (F.finalStarted ? 0.35 : 1) : 0); s('contCore', F.lockOff ? 1 : 0);
    s('exit', F.cycle ? 1 : 0); s('exitFl', F.blastOpen ? 0.7 : 0); s('lift', F.blastOpen ? 1 : 0);
    if (F.menu) { s('recep', 0); s('recepF', 1); s('emer', 0.8); s('service', 0); s('store', 0); s('gen', 0); s('med', 0); s('sim', 0); s('ward', 0); s('lab', 0); }
    if (instant) L.applyLighting();
    // fog density follows the space
  };

  /* ================= OBJECTIVES ================= */
  G.objective = function () {
    const F = G.flags;
    const ev = (F.ev1 ? 1 : 0) + (F.ev2 ? 1 : 0) + (F.terminal ? 1 : 0);
    if (!F.flashlight) return ['Find a light source.', 'You are in the recovery room.'];
    if (!F.card1) return ['Find an access card.', 'The service door in reception needs Level 1 access. Search the reception desk.'];
    if (!F.power) return ['Restore emergency power.', 'Restart the backup generator on the service level.'];
    if (!F.fuse) return ['Find a 30A fuse for the Medical Wing door.', 'Try the storage room off the service corridor.'];
    if (!F.fuseIn) return ['Install the fuse.', 'The fuse panel is beside the Medical Wing door in reception.'];
    if (!F.labOpen) return ['Collect research evidence (' + ev + '/3).', F.ev1 ? 'The lab door code: first half from Hale\'s log, the rest is written where it counts the days.' : 'Search the Medical Wing and the Patient Ward.'];
    if (!F.terminal) return ['Collect research evidence (' + ev + '/3).', 'Hale\'s terminal in the lab needs his password.' + (F.ev2 ? '' : ' Someone in the ward knew it.')];
    if (!F.card2) return ['Unlock the security room.', 'The Level 2 keycard is inside Containment Cell 0.'];
    if (!F.secReached) return ['RUN. Get to Security Control.', 'Through the maintenance tunnels. Your Level 2 card opens the door.'];
    if (!F.lockOff) return ['Disable the containment lock.', 'Set the breakers as the override sheet says, then pull MASTER.'];
    if (!F.finalStarted) return ['Enter the Containment Chamber.', 'The heavy door off the east–west tunnel. It is hunting in the tunnels.'];
    if (!F.cycle) return ['Survive. Start the emergency exit cycle.', 'The console in the chamber\'s north-west corner.'];
    if (!F.blastOpen) return ['Survive until the blast door opens.', 'Break line of sight. Lockers line the chamber walls.'];
    if (!F.escaped) return ['ESCAPE. Reach the service lift.', 'West along the exit corridor. The bulkheads are sealing.'];
    return ['', ''];
  };
  G.updateObjective = function () { const [a, b] = G.objective(); NP.UI.objective(a, b); };

  /* ================= FLAGS → STORY EVENTS ================= */
  G.onFlag = function (k) {
    const F = G.flags, UI = NP.UI, A = NP.Audio;
    if (k === 'flashlight') { UI.toast('F — flashlight   R — swap batteries   E — interact'); }
    if (k === 'card1') UI.toast('Level 1 keycard. It opens the service door.');
    if (k === 'power') G.powerOn();
    if (k === 'fuse') UI.toast('30A fuse. The Medical Wing door panel is in reception.');
    if (k === 'fuseIn') { const d = L.doors.medical; d.locked = false; NP.Timers.after(0.8, () => d.setOpen(true)); A.powerUp(); G.setupAI(); NP.Timers.after(1.5, () => G.saveCheckpoint('medical', at(15, 28, 0, 0.6), 0)); }
    if (k === 'ev1' || k === 'ev2') G.docsRead = (G.docsRead || 0) + 1;
    if (k === 'labOpen') { /* lab_rush scare handles the moment */ }
    if (k === 'terminal') { const d = L.doors.cell; d.locked = false; NP.Timers.after(1.2, () => { d.setOpen(true); A.alarm(false); }); NP.Timers.after(2.5, () => G.saveCheckpoint('cell', at(14, 6, 0, 0.6), -Math.PI / 2)); }
    if (k === 'card2') G.breach();
    if (k === 'lockOff') {
      L.doors.contain.locked = false; G.applyLighting();
      A.intercom('Containment lock released. Chamber access is open for ten minutes.', { who: 'INTERCOM', dur: 5, pitch: 0.6, rate: 0.9 });
      NP.Timers.after(2, () => G.saveCheckpoint('unlock', at(30, 23), Math.PI / 2));
    }
    if (k === 'cycle') { G.timerT = 45; A.alarm(true); G.applyLighting(); A.intercom('Emergency exit cycle engaged. Blast door pressurising.', { who: 'INTERCOM', dur: 4, pitch: 0.6 }); NP.AI.cfg.aggro = 1; if (NP.AI.state !== 'chase') NP.AI.go('hunt'); }
    G.updateObjective();
  };

  /* ---------- generator comes back: power-up sweep ---------- */
  G.powerOn = function () {
    const A = NP.Audio;
    A.powerUp(); NP.Player.addShake(0.2, 1.2);
    const seq = ['gen', 'service', 'store', 'recep', 'med', 'sim', 'ward', 'lab'];
    seq.forEach((c, i) => NP.Timers.after(0.6 + i * 0.35, () => { L.setCircuit(c, 1, true); }));
    NP.Timers.after(0.6, () => L.setCircuit('emer', 0.35, true));
    NP.Timers.after(4.5, () => A.intercom('Backup power restored. All personnel report to Containment. Repeat — all personnel.', { who: 'INTERCOM', dur: 5.5, pitch: 0.55, rate: 0.85 }));
    NP.Timers.after(3, () => G.saveCheckpoint('power', at(31, 34, 0.4, 0), Math.PI / 2));
  };

  /* ---------- containment breach (story scare #19: the tunnel chase) ---------- */
  G.breach = function () {
    const F = G.flags, A = NP.Audio, AI = NP.AI, P = NP.Player;
    F.breach = true; NP.Scares.mark('breach', 3);
    A.stinger('hit'); A.shatter(at(20, 7, 0, 0, 1.5)); A.alarm(true);
    if (L.glassPanes) L.glassPanes.forEach((g) => { g.visible = false; });
    for (let i = 0; i < 4; i++) NP.FX.burstSparks(at(18 + i, 7, 0, 0, 1.6 + Math.random()), 12);
    P.addShake(0.8, 1.0); NP.FX.distort(0.8); NP.FX.flash(0.35, 0.02, 0.0, 3);
    NP.Scares.H.flicker(1.0, 14);
    NP.Timers.after(0.3, () => G.applyLighting());
    // the facility changes: the way you came in seals itself
    const lab = L.doors.lab; lab.lock = 'jam'; lab.locked = true; lab.setOpen(false, { slam: true });
    NP.Timers.after(1.0, () => { const t = L.doors.tunnel; t.locked = false; t.setOpen(true); NP.FX.burstSparks(t.center.clone().setY(2), 30); NP.FX.burstSmoke(t.center.clone().setY(2.2), 30, 1); A.metal(t.center, 1.2, 0.5); });
    A.intercom('Containment breach. Cell zero. Containment breach.', { who: 'INTERCOM', dur: 4.5, pitch: 0.7, rate: 1.0 });
    // it drops down between you and the lab door
    G.setupAI();
    const s = at(15, 10, 0.6, -0.4);
    AI.held = true; AI.spawnAt(s.x, s.z, AI.yaw = Math.atan2(P.pos.x - s.x, P.pos.z - s.z), 'chase');
    AI.c.root.position.y = 3.2; AI.c.setState('crawl'); AI.c.snapPose();
    NP.Tweens.add(0.35, (k) => { AI.c.root.position.y = 3.2 * (1 - k * k); }, () => { A.metal(AI.pos(), 1, 0.6); P.addShake(0.6, 0.5); AI.c.setState('watch'); AI.c.lookAt = P.eyePos(new V3()); });
    NP.Timers.after(0.9, () => A.creature(AI.headPos(), 'screech'));
    NP.Timers.after(2.4, () => { AI.held = false; AI.c.root.position.y = 0; AI.state = 'patrol'; AI.startChase(); AI.stateT = 0.6; AI.awareness = 1.2; AI.lastKnown.copy(P.pos); });
    G.updateObjective();
  };

  /* ---------- containment chamber: final encounter (scare #20) ---------- */
  G.finalEncounter = function () {
    const F = G.flags, A = NP.Audio, AI = NP.AI, P = NP.Player, H = NP.Scares.H;
    F.finalStarted = true; NP.Scares.mark('final_encounter', 3);
    const d = L.doors.contain; d.setOpen(false, { slam: true }); d.lock = 'jam'; d.locked = true;
    A.duck(1, 3.5); A.stinger('swell');
    G.applyLighting();
    const tank = at(32, 9, 1.2, 0.6);
    NP.Timers.after(0.6, () => { H.flicker(2.4, 10); NP.FX.burstSmoke(tank.clone().setY(1.2), 40, 2.4); A.zap(tank.clone().setY(6)); NP.FX.burstSparks(tank.clone().setY(6.4), 30); });
    G.finalIntro = true;
    AI.setPhase('final', { zones: ['c'], spawns: (() => { const o = []; for (let z = 4; z <= 15; z++) for (let x = 28; x <= 37; x++) if (L.ch(x, z) === 'c') o.push([x, z]); return o; })() });
    NP.Timers.after(3.0, () => {
      L.bakeUniform.value = 0; P.interfere = 0.6;
      AI.held = true; AI.spawnAt(tank.x, tank.z + 0.2, Math.atan2(P.pos.x - tank.x, P.pos.z - tank.z), 'hunt');
      AI.c.root.position.y = 0.7; AI.c.setState('crawl'); AI.c.snapPose();
    });
    NP.Timers.after(3.6, () => {
      L.bakeUniform.value = 1; A.stinger('hit'); A.creature(AI.headPos(), 'screech'); H.jolt(3); NP.FX.flash(0.3, 0.3, 0.32, 5);
      AI.c.setState('watch'); AI.c.lookAt = P.eyePos(new V3());
      NP.Tweens.add(0.6, (k) => { AI.c.root.position.y = 0.7 * (1 - k); AI.c.root.position.z = tank.z + 0.2 + k * 2.4; });
      L.setCircuit('contCore', 0); L.forceApply();
    });
    NP.Timers.after(5.6, () => { AI.held = false; G.finalIntro = false; AI.go('hunt'); AI.c.setFade(0, true); AI.awareness = 0.3; A.intercom('It only follows the one who remembers.', { who: '???', dur: 3.5, pitch: 0.1, rate: 0.6 }); });
    NP.Timers.after(9, () => G.saveCheckpoint('final', at(32, 14, 0, 0.6), 0));
    G.updateObjective();
  };

  /* ---------- the blast door opens: timed escape through closing bulkheads ---------- */
  G.openBlast = function () {
    const F = G.flags; F.blastOpen = true; G.timerT = null; NP.UI.timer(null);
    const d = L.doors.blast; d.locked = false; d.setOpen(true);
    NP.Audio.metal(d.center, 1.3, 0.4);
    G.applyLighting();
    NP.Audio.intercom('Blast door open. Evacuate. Bulkheads sealing in sequence.', { who: 'INTERCOM', dur: 4, pitch: 0.6 });
    G.saveCheckpoint('escape', at(33, 4, 0, 0.6), 0);
    G.startEscape(false);
    NP.AI.setPhase('final', { zones: ['c', 'x', 'e'], spawns: [] });
    NP.AI.startChase(); NP.AI.awareness = 1.5; NP.AI.lastKnown.copy(NP.Player.pos);
    G.updateObjective();
  };
  G.startEscape = function (fromCheckpoint) {
    const ids = ['x1', 'x2', 'x3'];
    G.escape = { t: 0, sealed: {}, deadline: { x1: 16, x2: 26, x3: 36 } };
    ids.forEach((id) => { const d = L.doors[id]; d.open = true; d.t = 1; d.locked = false; d.pose(); });
    NP.Scares.mark('escape_bulkheads', 3);
    NP.Audio.chase(true, 1); NP.Audio.alarm(true);
    if (fromCheckpoint) { NP.AI.setPhase('final', { zones: ['c', 'x', 'e'] }); const s = at(32, 9, 1.2, 2.6); NP.AI.spawnAt(s.x, s.z, Math.PI, 'chase'); NP.AI.awareness = 1.5; NP.AI.lastKnown.copy(NP.Player.pos); }
  };
  G.updateEscape = function (dt) {
    const e = G.escape; if (!e) return;
    e.t += dt;
    const P = NP.Player.pos;
    for (const id of ['x1', 'x2', 'x3']) {
      if (e.sealed[id]) continue;
      const d = L.doors[id];
      const passed = P.x < d.center.x - 1.4;
      if ((passed && !e.pass) || e.t > e.deadline[id]) {
        if (passed) { e.passT = e.passT || {}; e.passT[id] = e.passT[id] || e.t; if (e.t - e.passT[id] < 0.7) continue; }
        e.sealed[id] = true; d.locked = true; d.setOpen(false); NP.Audio.metal(d.center, 1, 0.5); NP.FX.burstSparks(d.center.clone().setY(2.6), 16);
        NP.Player.addShake(0.3, 0.6);
        if (!passed) {
          // sealed in with it
          NP.UI.toast('The bulkhead sealed in front of you.');
          NP.Timers.after(2.5, () => { if (G.state === 'play') { const AI = NP.AI; const b = NP.Scares.H.behind(1.6); AI.spawnAt(b.x, b.z, NP.Player.yaw, 'attack'); G.onCaught(AI); } });
        }
      }
    }
  };

  /* ---------- ending: the lift ---------- */
  G.buildEndGate = function (scene) {
    const g = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.0, 2 * C), L.dynMat('p_rust'));
    g.position.set(7 * C - 0.1, 4.5, 2 * C); g.visible = false; g.castShadow = true; scene.add(g); G.endGate = g;
  };
  G.ending = function () {
    const F = G.flags, A = NP.Audio, P = NP.Player, AI = NP.AI;
    F.escaped = true; G.state = 'ending'; NP.UI.prompt(null); NP.UI.objective('', '');
    NP.Scares.mark('ending', 3);
    const eye = at(3, 2, 0, 0, 1.6);
    P.cine = { pos: eye, look: at(12, 2, 0, -0.4, 1.4), rate: 2, lookRate: 3 };
    G.endGate.visible = true; G.endGate.position.y = 4.5;
    // it comes down the corridor one last time
    AI.held = true; const s = at(16, 2, 0, -0.2); AI.spawnAt(s.x, s.z, -Math.PI / 2, 'sprint');
    A.creature(AI.headPos(), 'screech');
    let k = 0;
    NP.Tweens.add(1.4, (t) => { AI.c.root.position.x = NP.lerp(s.x, at(8, 2).x, t); AI.c.update(0.016); });
    NP.Timers.after(1.0, () => { NP.Tweens.add(0.35, (t) => { G.endGate.position.y = 4.5 - t * 3.0; }, () => { A.metal(G.endGate.position, 1.4, 0.45); P.addShake(0.8, 0.6); AI.c.setVisible(false); AI.setPhase('off'); A.chase(false); A.alarm(false); }); });
    NP.Timers.after(1.6, () => { A.metal(G.endGate.position, 1.0, 0.5); NP.FX.distort(0.4); });
    NP.Timers.after(2.4, () => { A.metal(G.endGate.position, 0.8, 0.5); });
    // the lift rises
    NP.Timers.after(3.6, () => { A.duck(1, 4); P.addShake(0.25, 3.0); A.powerUp(); P.cine = { pos: at(3, 2, 0, 0.2, 1.6), look: at(3, 2, 0, -2, 1.6), rate: 2, lookRate: 2 }; });
    NP.Timers.after(6.4, () => {
      // one last look
      L.bakeUniform.value = 0.05;
      P.yaw = 0; P.pitch = 0; P.pos.copy(at(3, 2, 0, 0.2));
      NP.Scares.H.placeFace(NP.World.app, 0.6);
    });
    NP.Timers.after(6.75, () => { L.bakeUniform.value = 1; A.stinger('screech'); NP.FX.flash(1.2, 1.2, 1.2, 0.8); NP.Scares.H.hide(NP.World.app); NP.Scares.H.faceLightOff(); P.addShake(1, 0.5); });
    NP.Timers.after(7.2, () => { NP.FX.fadeTo(1, 0.4); });
    NP.Timers.after(10, () => {
      NP.Input.unlock(); NP.store.del('cp'); G.cpData = null;
      const mins = Math.floor(G.playTime / 60), secs = Math.floor(G.playTime % 60);
      const docs = Object.keys(G.flags).filter((f) => f.startsWith('read_') || f.startsWith('tape')).length;
      NP.UI.ending({ time: mins + ':' + (secs < 10 ? '0' : '') + secs, deaths: G.deaths, scares: NP.Scares.log.length, docs });
      A.stopAll();
    });
  };

  /* ================= DEATH ================= */
  G.onCaught = function (ai, fromLocker) {
    if (G.state !== 'play') return;
    G.state = 'dying'; G.deaths++;
    const P = NP.Player, A = NP.Audio;
    if (P.hidden) P.hidden = null;
    NP.UI.prompt(null); NP.UI.closeModal();
    ai.held = true; ai.c.setState('attack'); ai.c.lookAt = P.eyePos(new V3());
    const head = ai.headPos(new V3());
    P.cine = { pos: P.eyePos(new V3()).add(new V3(0, -0.25, 0)), look: head, rate: 8, lookRate: 14 };
    A.stinger('hit'); A.creature(head, 'screech'); A.chase(false);
    P.addShake(1.2, 1.2); NP.FX.distort(1.4); NP.FX.flash(0.5, 0.0, 0.0, 2.5);
    NP.Timers.after(0.55, () => { NP.FX.flash(0.7, 0.02, 0.02, 4); P.cine.pos = P.cine.pos.clone().setY(0.4); P.cine.rate = 4; A.metal(P.pos, 0.7, 0.5); });
    NP.Timers.after(0.9, () => NP.FX.fadeTo(1, 2.5));
    NP.Timers.after(2.2, () => {
      G.state = 'dead'; NP.Input.unlock(); A.stopAll(); A.stinger('low', 0.6);
      NP.UI.death({ cp: G.cpData ? G.cpData.label : 'Recovery Room' });
    });
  };

  /* ================= INTRO ================= */
  G.intro = function () {
    const P = NP.Player, A = NP.Audio, FX = NP.FX;
    G.state = 'play';
    const bed = at(4, 32, -0.5, 0, 0.95);
    P.cine = { pos: bed, look: bed.clone().add(new V3(0.2, 2, 0.4)), rate: 50, lookRate: 50 };
    FX.setFade(1); FX.blur(1.2);
    const blink = (t, d) => { NP.Timers.after(t, () => FX.fadeTo(0.15, 1.5), 'intro'); NP.Timers.after(t + d, () => FX.fadeTo(0.97, 4), 'intro'); };
    NP.Timers.after(0.6, () => A.intercom('...emergency broadcast... if anyone can hear this, the Protocol has failed. Do not fall asleep. Do not let it see you remember...', { who: 'BROADCAST', dur: 8.5, pitch: 0.45, rate: 0.82 }), 'intro');
    blink(1.5, 1.2); blink(3.5, 1.0);
    NP.Timers.after(5.2, () => { FX.fadeTo(0, 0.8); FX.blur(0.35); P.cine.rate = 1.2; P.cine.lookRate = 1.5; P.cine.look = at(7, 32, 0, 0, 1.2); }, 'intro');
    NP.Timers.after(6.4, () => { P.cine.pos = at(4, 32, 0.2, 1.05, 1.62); P.cine.look = at(8, 32, 0, 0, 1.4); A.creature(at(1, 32, 0, 0, 1.4), 'click'); }, 'intro');
    NP.Timers.after(8.8, () => G.endIntro(), 'intro');
    G.introOn = true;
  };
  G.endIntro = function () {
    if (!G.introOn) return; G.introOn = false;
    NP.Timers.cancel('intro');
    const P = NP.Player; P.cine = null; P.yaw = -Math.PI / 2; P.pitch = -0.05;
    NP.FX.fadeTo(0, 1.4); NP.FX.blur(0);
    G.updateObjective();
    NP.UI.toast('WASD move · Mouse look · Shift sprint · Ctrl or C crouch · E interact · Tab objective', 6);
  };

  /* ================= PAUSE ================= */
  G.pause = function () {
    if (G.state !== 'play') return;
    G.state = 'pause'; NP.UI.screen('pause'); NP.Audio.suspend(); NP.Input.unlock();
    const inv = []; const F = G.flags;
    if (F.flashlight) inv.push('Flashlight'); if (F.card1) inv.push('Level 1 keycard'); if (F.fuse && !F.fuseIn) inv.push('30A fuse'); if (F.card2) inv.push('Level 2 keycard');
    ['ev1', 'ev2'].forEach((e) => F[e] && inv.push('Evidence ' + e.slice(2))); if (F.terminal) inv.push('Evidence 3 (terminal)');
    inv.push(NP.Player.light.spares + ' spare batteries');
    document.getElementById('inv').textContent = inv.join('  ·  ');
    document.getElementById('pause-obj').textContent = G.objective()[0];
  };
  G.resume = function () {
    if (G.state !== 'pause') return;
    G.state = 'play'; NP.UI.screen('play'); NP.Audio.resume(); NP.Input.lock();
  };

  /* ================= INPUT HOOKS ================= */
  G.onKey = function (e) {
    const UI = NP.UI;
    if (UI.modal === 'keypad') { if (e.code === 'Escape' || e.code === 'KeyE') { if (e.code === 'Escape') e.preventDefault(); UI.closeModal(); return; } const k = e.key; if (/^[0-9]$/.test(k)) UI.keypadInput(k); if (e.code === 'Backspace') UI.keypadInput('<'); return; }
    if (UI.modal === 'term') { if (e.code === 'Escape') { UI.closeModal(); return; } UI.termKey(e); e.preventDefault(); return; }
    if (UI.modal === 'doc') { if (['KeyE', 'Escape', 'Space', 'Enter'].includes(e.code)) { UI.closeModal(); if (e.code === 'Escape') G.ignoreUnlock = true; } return; }
    if (G.state === 'play') {
      if (G.introOn && (e.code === 'Space' || e.code === 'KeyE' || e.code === 'Enter')) { G.endIntro(); return; }
      if (e.code === 'KeyE') NP.Interact.use();
      if (e.code === 'KeyF') NP.Player.toggleFlash();
      if (e.code === 'KeyR') NP.Player.reload();
      if (e.code === 'Tab' || e.code === 'KeyO') { e.preventDefault(); UI.toggleObjective(); }
      if (e.code === 'KeyP') G.pause();
    } else if (G.state === 'pause' && (e.code === 'KeyP')) G.resume();
  };
  G.onCanvasClick = function () { if (G.state === 'play' && !NP.Input.locked) NP.Input.lock(); };
  G.onLockChange = function (locked) {
    if (!locked && G.state === 'play') {
      if (NP.UI.modal) return; // documents/keypad keep running without the pointer
      if (G.ignoreUnlock) { G.ignoreUnlock = false; G.pause(); return; }
      G.pause();
    }
  };
  G.onLockError = function () { G.noLock = true; if (G.state === 'play') NP.UI.toast('Mouse lock unavailable here: hold the left mouse button and drag to look.', 5); };

  /* ================= LIGHT POOL ================= */
  const lp = new V3();
  G.updateLightPool = function (dt) {
    const q = NP.q(), cam = G.camera.position;
    G.poolT = (G.poolT || 0) - dt;
    if (G.poolT <= 0) {
      G.poolT = 0.12;
      const cands = [];
      for (const f of L.fixtures) {
        if ((L.circuits[f.circuit] || 0) < 0.02 && f.override == null) continue;
        const d2 = f.pos.distanceToSquared(cam); if (d2 > 26 * 26) continue;
        const vis = L.los(cam.x, cam.z, f.x, f.z, 'light') ? 1 : 0.25;
        const s = f.intensity * (f.bake ? 1 : 1.6) * vis / (1 + d2 * 0.05);
        cands.push([s, f]);
      }
      cands.sort((a, b) => b[0] - a[0]);
      G.pool.forEach((p, i) => { p.f = i < q.lights && cands[i] ? cands[i][1] : null; });
    }
    for (const p of G.pool) {
      const f = p.f, l = p.l;
      if (!f || !l.visible) { l.intensity = 0; continue; }
      lp.set(f.pos.x + f.n[0] * 0.25, f.pos.y + f.n[1] * 0.25, f.pos.z + f.n[2] * 0.25);
      l.position.copy(lp); l.color.setRGB(f.color[0], f.color[1], f.color[2]);
      l.distance = f.range * 1.1;
      l.intensity = f.cur * f.intensity * (f.bake ? 0.55 : 1.4) * (f.kind === 'emer' ? 0.8 : 1);
    }
  };

  /* ================= MAIN LOOP ================= */
  G.frame = function (now) {
    requestAnimationFrame(G.frame);
    if (G.contextLost) return;
    let dt = Math.min(0.05, (now - G.last) / 1000); G.last = now;
    if (document.hidden) return;
    try { G.update(dt); G.render(); } catch (e) { console.error('[frame]', e); G.errors = (G.errors || 0) + 1; if (G.errors < 4) NP.UI.toast('Error: ' + e.message, 6); }
    NP.Input.endFrame();
  };
  G.update = function (dt) {
    const st = G.state, I = NP.Input, P = NP.Player;
    if (st === 'pause' || st === 'boot') { return; }
    if (st === 'menu') {
      G.menuT += dt;
      const t = G.menuT * 0.05;
      P.cine = { pos: at(15, 35, Math.sin(t) * 3.5, 0.6 - Math.sin(t * 0.7) * 1.5, 1.7 + Math.sin(t * 1.3) * 0.15), look: at(15, 29, Math.sin(t * 0.8) * 4, 0, 1.3), rate: 1, lookRate: 1 };
      P.applyCamera(dt); NP.Timers.update(dt); NP.Tweens.update(dt);
      L.updateCircuits(dt); L.updateFixtures(NP.Timers.time); L.updateDoors(dt); G.updateLightPool(dt);
      NP.FX.update(dt); NP.FX.updateParticles(dt, G.camera); NP.World.update(dt, NP.Timers.time);
      return;
    }
    if (st === 'dead') { NP.FX.update(dt); return; }
    // drag-to-look fallback when pointer lock is not available
    if (!I.locked && G.noLock && I.mouseDown && !NP.UI.modal) { /* deltas collected by core */ }
    if (st === 'play') G.playTime += dt;
    NP.Timers.update(dt); NP.Tweens.update(dt);
    P.update(dt, I);
    if (st === 'play') NP.Interact.update(G.camera);
    L.updateDoors(dt);
    NP.AI.update(dt);
    if (st === 'play') { NP.Scares.update(dt); G.story(dt); }
    NP.World.update(dt, NP.Timers.time);
    L.updateCircuits(dt); L.updateFixtures(NP.Timers.time); G.updateLightPool(dt);
    NP.FX.update(dt); NP.FX.updateParticles(dt, G.camera);
    NP.Audio.updateListener(G.camera); NP.Audio.update(dt, NP.AI.danger || 0, !!P.hidden);
    NP.UI.hud(P);
    // post FX reacting to state
    const danger = NP.AI.danger || 0;
    NP.FX.u.uLowHP.value = NP.damp(NP.FX.u.uLowHP.value, danger * 0.8, 2, dt);
    NP.FX.u.uSlats.value = NP.damp(NP.FX.u.uSlats.value, P.hidden ? 1 : 0, 10, dt);
    NP.FX.u.uChroma.value = 0.0012 + danger * 0.0025;
  };
  G.render = function () {
    const r = G.renderer;
    NP.World.renderTargets(r, G.scene, G.camera);
    NP.FX.render(G.scene, G.camera);
  };

  /* ================= STORY TRIGGERS (position based) ================= */
  G.story = function (dt) {
    const F = G.flags, P = NP.Player.pos;
    const [gx, gz] = L.cellOf(P.x, P.z);
    const zk = L.zoneKey(gx, gz);
    // zone banners
    if (zk && zk !== G.curZone && L.ch(gx, gz) !== '+') {
      G.curZone = zk; const Z = L.ZONES[zk];
      if (!G.zoneSeen[zk] || NP.Timers.time - G.zoneSeen[zk] > 60) NP.UI.location(Z.name.toUpperCase(), 'Hale Institute · Sub-level 4');
      G.zoneSeen[zk] = NP.Timers.time;
      const dens = { t: 0.075, c: 0.05, n: 0.06, x: 0.06 }[zk] || 0.045; G.scene.fog.density = dens;
      NP.Audio.setReverb(zk === 'c' ? 0.7 : zk === 't' ? 0.5 : zk === 'r' ? 0.45 : 0.3);
    }
    if (F.breach && !F.secReached && zk === 'q') {
      F.secReached = true; NP.Audio.alarm(false); G.applyLighting();
      const d = L.doors.security;
      NP.Timers.after(0.4, () => { d.setOpen(false); d.locked = true; });
      NP.Timers.after(1.8, () => { [0, 0.5, 0.9, 1.6].forEach((t, i) => NP.Timers.after(t, () => { NP.Audio.metal(d.center, 1.2 - i * 0.1, 0.55); NP.Player.addShake(0.3, 0.3); })); NP.Audio.creature(d.center.clone().setX(d.center.x + 1.5), 'growl'); });
      NP.Scares.mark('security_door_bang', 2);
      NP.Timers.after(0.6, () => { G.setupAI(); NP.Audio.chase(false); });
      NP.Timers.after(4, () => G.saveCheckpoint('security', at(31, 23), Math.PI / 2));
      G.updateObjective();
    }
    if (F.lockOff && !F.finalStarted && zk === 'c') G.finalEncounter();
    if (F.blastOpen && zk === 'e' && !F.escaped) G.ending();
    if (G.timerT != null && !F.blastOpen) {
      G.timerT -= dt; NP.UI.timer(Math.max(0, G.timerT));
      if (G.timerT <= 0) G.openBlast();
    }
    if (F.blastOpen) G.updateEscape(dt);
    // chase music follows the AI
    const chasing = NP.AI.state === 'chase' && NP.AI.c.visible;
    if (chasing !== G.chasing) { G.chasing = chasing; NP.Audio.chase(chasing || !!G.escape && F.blastOpen, 0.6); }
  };

  /* ================= DEBUG / TEST API ================= */
  G.debugApi = function () {
    return {
      G, NP,
      teleport(gx, gz, ox = 0, oz = 0) { const p = at(gx, gz, ox, oz); NP.Player.pos.set(p.x, 0, p.z); },
      flag(k) { G.flags[k] = true; G.onFlag(k); },
      state: () => ({ state: G.state, flags: Object.assign({}, G.flags), pos: NP.Player.pos.toArray().map((v) => +v.toFixed(2)), ai: NP.AI.state, aiPhase: NP.AI.phase, scares: Array.from(NP.Scares.done), objective: G.objective()[0] }),
      sol: () => NP.World.sol,
      look(yaw, pitch) { NP.Player.yaw = yaw; NP.Player.pitch = pitch || 0; },
    };
  };
})(window.NP);
