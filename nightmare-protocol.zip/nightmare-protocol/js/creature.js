/* NIGHTMARE PROTOCOL — THE PATIENT: procedural articulated creature + mannequins */
'use strict';
(function (NP) {
  const V3 = THREE.Vector3;

  /* dissolve-capable material: fragments vanish in a noisy pattern as uFade rises */
  function dissolveMat(params) {
    const m = new THREE.MeshStandardMaterial(params);
    m.userData.fade = { value: 0 };
    m.onBeforeCompile = (sh) => {
      sh.uniforms.uFade = m.userData.fade;
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP;')
        .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWP = (modelMatrix * vec4(transformed,1.0)).xyz;');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
uniform float uFade; varying vec3 vWP;
float h3(vec3 p){ p=fract(p*0.3183099+.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float n3(vec3 x){ vec3 i=floor(x); vec3 f=fract(x); f=f*f*(3.0-2.0*f);
 return mix(mix(mix(h3(i),h3(i+vec3(1,0,0)),f.x),mix(h3(i+vec3(0,1,0)),h3(i+vec3(1,1,0)),f.x),f.y),
            mix(mix(h3(i+vec3(0,0,1)),h3(i+vec3(1,0,1)),f.x),mix(h3(i+vec3(0,1,1)),h3(i+vec3(1,1,1)),f.x),f.y),f.z); }`)
        .replace('#include <clipping_planes_fragment>', `#include <clipping_planes_fragment>
 if(uFade>0.001){ float nn = n3(vWP*7.0)*0.6 + n3(vWP*19.0)*0.4; if(nn < uFade*1.15-0.05) discard; }`);
    };
    m.customProgramCacheKey = () => 'dissolve';
    return m;
  }
  NP.dissolveMat = dissolveMat;

  function lumpy(geo, amt, seed) {
    const p = geo.attributes.position; const r = NP.makeRng(seed || 3);
    const v = new V3();
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i);
      const n = NP.noise1(v.y * 9 + seed) * 0.5 + NP.noise1(v.x * 13 + v.z * 7 + seed * 3) * 0.5;
      const k = 1 + n * amt + (r() - 0.5) * amt * 0.3;
      p.setXYZ(i, v.x * k, v.y, v.z * k);
    }
    geo.computeVertexNormals();
    return geo;
  }
  function limb(len, r0, r1, seed) {
    const g = new THREE.CylinderGeometry(r0, r1, len, 9, 6);
    g.translate(0, -len / 2, 0);
    return lumpy(g, 0.25, seed);
  }

  class Creature {
    constructor(scene, opts) {
      opts = opts || {};
      this.scene = scene;
      const sk = NP.Tex.get('skin');
      this.mat = dissolveMat({ map: sk.map, normalMap: sk.normalMap, roughnessMap: sk.roughnessMap, color: 0x7d8077, roughness: 0.55, metalness: 0.05 });
      this.mat.normalScale = new THREE.Vector2(1.4, 1.4);
      this.dark = dissolveMat({ color: 0x050303, roughness: 0.3 });
      this.toothMat = dissolveMat({ color: 0x9a947c, roughness: 0.35 });
      const M = this.mat;
      const J = (this.j = {});
      const root = (this.root = new THREE.Group());
      const mk = (name, parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); J[name] = g; return g; };
      const mesh = (geo, mat, parent, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };

      const hips = mk('hips', root, 0, 1.18, 0);
      mesh(lumpy(new THREE.SphereGeometry(0.17, 12, 10), 0.2, 5), M, hips, 0, 0, 0).scale.set(1.2, 0.8, 0.9);
      const sp1 = mk('spine1', hips, 0, 0.12, -0.02);
      mesh(limb(0.2, 0.09, 0.11, 6), M, sp1, 0, 0.2, 0).rotation.x = Math.PI;
      const sp2 = mk('spine2', sp1, 0, 0.2, 0);
      // emaciated rib cage via lathe profile
      const prof = [];
      for (let i = 0; i <= 16; i++) { const t = i / 16; const r = 0.08 + Math.sin(t * Math.PI) * 0.15 + Math.max(0, Math.sin(t * 34)) * 0.012 * Math.sin(t * Math.PI); prof.push(new THREE.Vector2(r, t * 0.52)); }
      const cage = new THREE.LatheGeometry(prof, 18);
      lumpy(cage, 0.1, 7);
      const cm = mesh(cage, M, sp2, 0, 0, 0); cm.scale.set(1.15, 1, 0.72);
      // vertebrae on the back
      for (let i = 0; i < 7; i++) mesh(new THREE.SphereGeometry(0.03, 6, 5), M, sp2, 0, 0.04 + i * 0.07, -0.13 + Math.sin(i / 6 * Math.PI) * -0.03);
      const chest = mk('chest', sp2, 0, 0.5, 0);
      mesh(lumpy(new THREE.SphereGeometry(0.15, 12, 8), 0.25, 9), M, chest, 0, -0.02, -0.01).scale.set(1.75, 0.5, 0.8); // collarbone mass
      const n1 = mk('neck1', chest, 0, 0.05, 0.03);
      mesh(limb(0.2, 0.045, 0.05, 11), M, n1, 0, 0.2, 0).rotation.x = Math.PI;
      const n2 = mk('neck2', n1, 0, 0.2, 0.02);
      mesh(limb(0.18, 0.04, 0.045, 12), M, n2, 0, 0.18, 0).rotation.x = Math.PI;
      const head = mk('head', n2, 0, 0.18, 0.03);
      // elongated, swept-back cranium
      const hg = new THREE.SphereGeometry(0.15, 22, 18);
      { const p = hg.attributes.position, v = new V3();
        for (let i = 0; i < p.count; i++) { v.fromBufferAttribute(p, i);
          let x = v.x * 0.82, y = v.y, z = v.z;
          if (y > 0) { y *= 1.9; z -= y * 0.55; x *= 1 - y * 0.6; }
          if (z > 0.06) z = 0.06 + (z - 0.06) * 0.4; // flattened face
          y += NP.noise1(v.x * 30 + v.z * 20) * 0.006;
          p.setXYZ(i, x, y + 0.06, z); }
        hg.computeVertexNormals(); }
      mesh(hg, M, head);
      // vertical split mouth with teeth, from chin to brow
      const jaw = mk('jaw', head, 0, -0.02, 0.06);
      mesh(new THREE.BoxGeometry(0.03, 0.22, 0.04), this.dark, head, 0, 0.06, 0.07);
      for (let i = 0; i < 9; i++) {
        const y = -0.03 + i * 0.022;
        for (const s of [-1, 1]) { const t = mesh(new THREE.ConeGeometry(0.006, 0.03, 5), this.toothMat, head, s * 0.018, y, 0.085); t.rotation.z = s * Math.PI / 2; }
      }
      mesh(lumpy(new THREE.SphereGeometry(0.07, 10, 8), 0.2, 13), M, jaw, 0, -0.06, -0.01).scale.set(0.9, 0.7, 0.9);
      // sunken eye pits + glints (only visible in light)
      this.glintMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
      for (const s of [-1, 1]) {
        mesh(new THREE.SphereGeometry(0.028, 8, 6), this.dark, head, s * 0.055, 0.12, 0.07);
        const gl = new THREE.Mesh(new THREE.SphereGeometry(0.006, 6, 4), this.glintMat); gl.position.set(s * 0.055, 0.12, 0.094); head.add(gl);
      }
      // arms
      for (const s of [-1, 1]) {
        const side = s < 0 ? 'L' : 'R';
        const sh = mk('sh' + side, chest, s * 0.25, -0.02, -0.02);
        mesh(new THREE.SphereGeometry(0.06, 8, 6), M, sh);
        const ua = mk('ua' + side, sh, 0, 0, 0);
        mesh(limb(0.62, 0.05, 0.035, 20 + s), M, ua);
        const fa = mk('fa' + side, ua, 0, -0.62, 0);
        mesh(new THREE.SphereGeometry(0.045, 8, 6), M, fa).scale.set(1, 1.2, 1);
        mesh(limb(0.6, 0.035, 0.025, 30 + s), M, fa);
        const hd = mk('hd' + side, fa, 0, -0.6, 0);
        mesh(new THREE.BoxGeometry(0.07, 0.11, 0.03), M, hd, 0, -0.05, 0);
        J['fing' + side] = [];
        for (let f = 0; f < 4; f++) {
          const fx = (f - 1.5) * 0.02;
          const f1 = mk('f1' + side + f, hd, fx, -0.1, 0);
          mesh(limb(0.16 + (f === 1 || f === 2 ? 0.04 : 0), 0.011, 0.008, 40 + f), M, f1);
          const f2 = mk('f2' + side + f, f1, 0, -0.17 - (f === 1 || f === 2 ? 0.04 : 0), 0);
          mesh(limb(0.13, 0.008, 0.004, 50 + f), M, f2);
          J['fing' + side].push([f1, f2]);
        }
      }
      // legs (reverse-jointed feel via deep knee bend)
      for (const s of [-1, 1]) {
        const side = s < 0 ? 'L' : 'R';
        const th = mk('th' + side, hips, s * 0.12, -0.05, 0);
        mesh(limb(0.56, 0.065, 0.045, 60 + s), M, th);
        const shn = mk('sn' + side, th, 0, -0.56, 0);
        mesh(new THREE.SphereGeometry(0.05, 8, 6), M, shn);
        mesh(limb(0.58, 0.04, 0.028, 70 + s), M, shn);
        const ft = mk('ft' + side, shn, 0, -0.58, 0);
        mesh(new THREE.BoxGeometry(0.07, 0.04, 0.26), M, ft, 0, -0.02, 0.08);
      }
      root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = false; if (opts.layer != null) o.layers.set(opts.layer); } });
      if (opts.layer != null) root.layers.set(opts.layer);
      scene.add(root);
      // pose state
      this.rot = {}; this.tgt = {};
      for (const k in J) if (!Array.isArray(J[k])) { this.rot[k] = J[k].rotation; this.tgt[k] = new V3(); }
      this.state = 'stand'; this.t = 0; this.phase = 0; this.speed = 0; this.fade = 0; this.fadeTarget = 0;
      this.hipY = 1.18; this.lookAt = null; this.jitter = 0; this.twitchT = 0; this.twitch = new V3(); this.lookYaw = 0; this.lookPitch = 0;
      this.visible = true;
      this.glint = 0;
    }
    setVisible(v) { this.root.visible = v; this.visible = v; }
    place(x, z, yaw, y = 0) { this.root.position.set(x, y, z); if (yaw != null) this.root.rotation.y = yaw; }
    get pos() { return this.root.position; }
    setFade(f, instant) { this.fadeTarget = f; if (instant) this.fade = f; }
    setState(s) { if (this.state !== s) { this.state = s; this.stateT = 0; } }
    snapPose() { this.update(0.016, true); for (let i = 0; i < 30; i++) this.update(0.05, true); }

    update(dt, snap) {
      this.t += dt; this.stateT = (this.stateT || 0) + dt;
      const s = this.state, T = this.tgt, t = this.t;
      for (const k in T) T[k].set(0, 0, 0);
      let hipY = 1.18, rate = 9;
      const nz = (o, f, a) => NP.noise1(t * f + o) * a;
      // twitches: sudden snaps of the head/neck at irregular intervals
      this.twitchT -= dt;
      if (this.twitchT <= 0) { this.twitchT = 0.4 + Math.random() * 2.6; this.twitch.set((Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.9, (Math.random() - 0.5) * 1.1); if (Math.random() < 0.4) this.twitch.multiplyScalar(0.15); }
      // base hunched posture
      T.hips.x = 0.22; T.spine1.x = 0.15; T.spine2.x = 0.18; T.chest.x = 0.1; T.neck1.x = -0.35; T.neck2.x = -0.25; T.head.x = 0.1;
      for (const sd of ['L', 'R']) { const sg = sd === 'L' ? -1 : 1; T['ua' + sd].set(-0.15, 0, sg * 0.12); T['fa' + sd].set(-0.2, 0, 0); T['th' + sd].set(-0.25, 0, sg * 0.04); T['sn' + sd].set(0.5, 0, 0); T['ft' + sd].set(-0.25, 0, 0); }

      if (s === 'stand' || s === 'watch' || s === 'turnhead') {
        T.hips.y = nz(1, 0.3, 0.05); T.chest.z = nz(2, 0.5, 0.06);
        T.neck2.z = this.twitch.z * 0.6; T.head.z = this.twitch.z * 0.5; T.neck1.y = this.twitch.y * 0.4;
        T.uaL.z -= 0.05 + nz(3, 0.7, 0.05); T.uaR.z += 0.05 + nz(4, 0.7, 0.05);
        if (s === 'turnhead') { const k = Math.min(1, this.stateT / 3.5); T.neck1.y = k * 1.6; T.neck2.y = k * 1.4; T.head.z = k * 0.4; rate = 2.5; }
        if (s === 'stand') rate = 4;
      } else if (s === 'walk' || s === 'search') {
        const sp = s === 'search' ? 0.7 : 1;
        // irregular cadence
        this.phase += dt * (4.2 + NP.noise1(t * 0.8) * 1.8) * sp * Math.max(0.4, this.speed / 1.4);
        const p = this.phase;
        T.thL.x = -0.25 + Math.sin(p) * 0.55; T.thR.x = -0.25 - Math.sin(p) * 0.55;
        T.snL.x = 0.5 + Math.max(0, -Math.cos(p)) * 0.9; T.snR.x = 0.5 + Math.max(0, Math.cos(p)) * 0.9;
        T.ftL.x = -0.25 + Math.sin(p) * 0.2; T.ftR.x = -0.25 - Math.sin(p) * 0.2;
        T.hips.z = Math.sin(p) * 0.09; T.hips.y = Math.sin(p) * 0.12; hipY = 1.18 - Math.abs(Math.cos(p)) * 0.06;
        T.uaL.x = -0.1 - Math.sin(p) * 0.35; T.uaR.x = -0.1 + Math.sin(p) * 0.35;
        T.chest.z = -Math.sin(p) * 0.08;
        T.neck2.z = this.twitch.z * 0.7; T.head.z = this.twitch.z * 0.4; T.neck1.y = this.twitch.y * 0.3;
        if (s === 'search') { T.neck1.y = Math.sin(t * 0.9) * 0.9; T.neck2.x = -0.1; T.head.x = 0.25; }
      } else if (s === 'sprint') {
        this.phase += dt * 11.5;
        const p = this.phase;
        T.hips.x = 0.7; T.spine1.x = 0.3; T.spine2.x = 0.25; T.neck1.x = -0.9; T.neck2.x = -0.5; T.head.x = -0.2;
        T.thL.x = -0.9 + Math.sin(p) * 1.05; T.thR.x = -0.9 - Math.sin(p) * 1.05;
        T.snL.x = 0.7 + Math.max(0, -Math.cos(p)) * 1.6; T.snR.x = 0.7 + Math.max(0, Math.cos(p)) * 1.6;
        T.uaL.x = -0.6 - Math.sin(p) * 1.3; T.uaR.x = -0.6 + Math.sin(p) * 1.3; T.uaL.z = -0.35; T.uaR.z = 0.35;
        T.faL.x = -0.9; T.faR.x = -0.9;
        T.hips.y = Math.sin(p) * 0.18; T.hips.z = Math.sin(p) * 0.12; hipY = 1.0 - Math.abs(Math.sin(p)) * 0.08;
        T.head.z = Math.sin(p * 0.5) * 0.3; rate = 16;
      } else if (s === 'crawl') {
        this.phase += dt * 5 * Math.max(0.5, this.speed / 1.5);
        const p = this.phase;
        hipY = 0.62; T.hips.x = 1.15; T.spine1.x = 0.2; T.spine2.x = 0.1; T.chest.x = 0.05; T.neck1.x = -1.1; T.neck2.x = -0.4; T.head.x = -0.1;
        T.thL.x = -1.6 + Math.sin(p) * 0.45; T.thR.x = -1.6 - Math.sin(p) * 0.45; T.snL.x = 1.9; T.snR.x = 1.9; T.thL.z = -0.35; T.thR.z = 0.35;
        T.uaL.x = -1.45 + Math.sin(p + 1.6) * 0.5; T.uaR.x = -1.45 - Math.sin(p + 1.6) * 0.5; T.uaL.z = -0.3; T.uaR.z = 0.3;
        T.faL.x = 0.25 + Math.max(0, Math.sin(p)) * 0.4; T.faR.x = 0.25 + Math.max(0, -Math.sin(p)) * 0.4;
        T.hips.z = Math.sin(p) * 0.15; T.head.z = this.twitch.z; rate = 10;
      } else if (s === 'attack') {
        const k = Math.min(1, this.stateT / 0.25);
        T.hips.x = 0.5; T.spine2.x = 0.3; T.neck1.x = -0.7; T.neck2.x = -0.3; T.head.x = -0.35;
        T.uaL.set(-2.0 * k, 0, -0.6); T.uaR.set(-2.0 * k, 0, 0.6); T.faL.x = -0.4; T.faR.x = -0.4;
        T.jaw.x = 0.5; T.thL.x = -0.9; T.thR.x = -0.2; T.snL.x = 1.1; T.snR.x = 0.6; hipY = 1.05; rate = 20;
      } else if (s === 'flinch') {
        T.hips.x = -0.15; T.spine2.x = 0.4; T.neck1.x = 0.3; T.head.x = 0.4; T.neck1.y = 0.6;
        T.uaL.set(-2.3, 0.4, -0.3); T.uaR.set(-2.1, -0.4, 0.4); T.faL.x = -2.0; T.faR.x = -1.8;
        T.chest.z = Math.sin(t * 40) * 0.04; T.head.z = Math.sin(t * 33) * 0.08; rate = 14;
      } else if (s === 'hang') { // dangling upside-down from a hatch
        T.hips.x = 0; T.spine1.x = 0; T.spine2.x = 0.1; T.neck1.x = 0.2; T.head.x = 0.3;
        T.uaL.set(Math.PI - 0.3 + nz(5, 2, 0.4), 0, -0.4); T.uaR.set(Math.PI - 0.3 + nz(6, 2, 0.4), 0, 0.4);
        T.faL.x = -0.3; T.faR.x = -0.3; T.jaw.x = 0.4 + nz(7, 5, 0.3); T.head.z = this.twitch.z; rate = 8;
      } else if (s === 'peek') { // only used for hand/face reveals
        T.uaR.set(-1.5, 0, 0.2); T.faR.x = -0.4;
      }
      // look at a target point with the head (preserving twitch)
      if (this.lookAt && (s === 'watch' || s === 'stand' || s === 'walk' || s === 'search' || s === 'flinch' || s === 'turnhead')) {
        const wp = new V3(); this.j.neck1.getWorldPosition(wp);
        const dx = this.lookAt.x - wp.x, dy = this.lookAt.y - wp.y, dz = this.lookAt.z - wp.z;
        const yaw = NP.angDiff(this.root.rotation.y, Math.atan2(dx, dz));
        const pitch = Math.atan2(dy, Math.hypot(dx, dz));
        const wy = NP.clamp(yaw, -2.6, 2.6), wpch = NP.clamp(-pitch, -0.8, 0.8);
        T.neck1.y += wy * 0.55; T.neck2.y += wy * 0.45; T.head.x += wpch * 0.6; T.neck2.x += wpch * 0.3;
      }
      // fingers curl & flex
      for (const sd of ['L', 'R']) this.j['fing' + sd].forEach(([a, b], i) => {
        const c = s === 'attack' ? -0.2 : s === 'flinch' ? 0.9 : 0.35 + nz(i * 3 + (sd === 'L' ? 0 : 7), 1.3, 0.35);
        a.rotation.x = NP.damp(a.rotation.x, -c * 0.6, 8, dt); b.rotation.x = NP.damp(b.rotation.x, -c, 8, dt);
        a.rotation.z = (i - 1.5) * 0.08;
      });
      if (!T.jaw.x) T.jaw.x = Math.max(0, NP.noise1(t * 1.7) * 0.25);
      // integrate
      const k = snap ? 1 : 1 - Math.exp(-rate * dt);
      for (const n in T) { const r = this.rot[n], tg = T[n]; r.x += (tg.x - r.x) * k; r.y += (tg.y - r.y) * k; r.z += (tg.z - r.z) * k; }
      this.hipY += (hipY - this.hipY) * k;
      this.j.hips.position.y = this.hipY;
      // fade
      this.fade = NP.damp(this.fade, this.fadeTarget, 3.5, dt);
      const f = this.fade < 0.01 ? 0 : this.fade;
      this.mat.userData.fade.value = f; this.dark.userData.fade.value = f; this.toothMat.userData.fade.value = f;
      if (f > 0.98 && this.fadeTarget >= 1) this.root.visible = false;
      // eye glint in flashlight
      if (NP.Player && NP.Player.light) {
        const hp = new V3(); this.j.head.getWorldPosition(hp);
        const lit = NP.Player.inBeam(hp, 22) ? 1 : 0;
        this.glint = NP.damp(this.glint, lit, 10, dt);
        this.glintMat.color.setRGB(2.5 * this.glint, 2.2 * this.glint, 1.6 * this.glint);
      }
    }
    headPos(out) { return this.j.head.getWorldPosition(out || new V3()); }
  }
  NP.Creature = Creature;

  /* ---------------- mannequins ---------------- */
  const plastic = () => new THREE.MeshStandardMaterial({ color: 0xcfc6b8, roughness: 0.32, metalness: 0.0 });
  class Mannequin {
    constructor(scene, x, z, yaw, poseIdx) {
      const mat = plastic();
      const g = (this.root = new THREE.Group());
      const add = (geo, p, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; p.add(m); return m; };
      add(new THREE.CylinderGeometry(0.2, 0.24, 0.04, 16), g, 0, 0.02, 0);
      add(new THREE.CylinderGeometry(0.015, 0.015, 0.9, 6), g, 0, 0.47, 0);
      const body = (this.body = new THREE.Group()); body.position.y = 0.92; g.add(body);
      add(new THREE.CylinderGeometry(0.16, 0.13, 0.25, 12), body, 0, 0.0, 0).scale.set(1, 1, 0.7);
      add(new THREE.CylinderGeometry(0.13, 0.19, 0.5, 12), body, 0, 0.36, 0).scale.set(1, 1, 0.65);
      add(new THREE.SphereGeometry(0.06, 8, 6), body, 0, 0.66, 0);
      const head = (this.head = new THREE.Group()); head.position.y = 0.74; body.add(head);
      add(new THREE.SphereGeometry(0.11, 16, 12), head, 0, 0.09, 0).scale.set(0.85, 1.25, 0.95);
      this.arms = [];
      for (const s of [-1, 1]) {
        const sh = new THREE.Group(); sh.position.set(s * 0.21, 0.56, 0); body.add(sh);
        add(new THREE.SphereGeometry(0.05, 8, 6), sh, 0, 0, 0);
        add(new THREE.CylinderGeometry(0.04, 0.035, 0.32, 8), sh, 0, -0.17, 0);
        const el = new THREE.Group(); el.position.y = -0.33; sh.add(el);
        add(new THREE.CylinderGeometry(0.033, 0.026, 0.3, 8), el, 0, -0.15, 0);
        add(new THREE.SphereGeometry(0.035, 8, 6), el, 0, -0.32, 0).scale.set(0.8, 1.3, 0.5);
        this.arms.push({ sh, el });
      }
      for (const s of [-1, 1]) { add(new THREE.CylinderGeometry(0.06, 0.04, 0.42, 8), body, s * 0.08, -0.32, 0).visible = false; }
      g.position.set(x, 0, z); g.rotation.y = yaw;
      scene.add(g);
      this.yaw = yaw; this.poses = Mannequin.POSES; this.setPose(poseIdx || 0, true);
      NP.Level.addBox(x - 0.25, z - 0.25, x + 0.25, z + 0.25, 1.8);
    }
    setPose(i, snap) {
      const p = this.poses[i % this.poses.length];
      this.target = p;
      if (snap) this.apply(1);
    }
    apply(k) {
      const p = this.target;
      const lr = (o, v) => { o.x += (v[0] - o.x) * k; o.y += (v[1] - o.y) * k; o.z += (v[2] - o.z) * k; };
      lr(this.head.rotation, p.head); lr(this.body.rotation, p.body);
      lr(this.arms[0].sh.rotation, p.la); lr(this.arms[0].el.rotation, p.le);
      lr(this.arms[1].sh.rotation, p.ra); lr(this.arms[1].el.rotation, p.re);
    }
    update(dt) { this.apply(1 - Math.exp(-12 * dt)); }
  }
  Mannequin.POSES = [
    { head: [0, 0, 0], body: [0, 0, 0], la: [0, 0, -0.1], le: [0, 0, 0], ra: [0, 0, 0.1], re: [0, 0, 0] },
    { head: [0.3, 0.4, 0.3], body: [0.05, 0, 0], la: [-0.4, 0, -0.2], le: [-0.6, 0, 0], ra: [0, 0, 0.1], re: [0, 0, 0] },
    { head: [-0.2, -0.6, -0.4], body: [0, 0.2, 0], la: [-1.4, 0, -0.1], le: [-0.2, 0, 0], ra: [-1.4, 0, 0.1], re: [-0.2, 0, 0] },
    { head: [0.6, 0, 0.6], body: [0.15, 0, 0.1], la: [0, 0, -0.3], le: [-1.2, 0, 0], ra: [-2.6, 0, 0.2], re: [-0.4, 0, 0] },
    { head: [0, 1.2, 0.2], body: [0, -0.3, 0], la: [-0.8, 0.3, -0.5], le: [-1.5, 0, 0], ra: [-0.8, -0.3, 0.5], re: [-1.5, 0, 0] },
  ];
  NP.Mannequin = Mannequin;
})(window.NP);
