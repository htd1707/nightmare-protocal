/* NIGHTMARE PROTOCOL — props: procedural furniture, machinery, decals, light fixture placement */
'use strict';
(function (NP) {
  const L = NP.Level, C = L.C;
  const P = (NP.Props = {});
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), one = new THREE.Vector3(1, 1, 1), tv = new THREE.Vector3();

  P.at = (gx, gz, ox = 0, oz = 0) => ({ x: (gx + 0.5) * C + ox, z: (gz + 0.5) * C + oz });
  function xf(x, y, z, ry, rx = 0, rz = 0, s) { e.set(rx, ry, rz); q.setFromEuler(e); return m4.clone().compose(tv.set(x, y, z), q, s || one); }

  /* group-local builder: collects parts relative to a placement transform */
  class Kit {
    constructor(x, z, ry, y = 0) { this.base = xf(x, y, z, ry); this.x = x; this.z = z; this.ry = ry; }
    box(w, h, d, lx, ly, lz, key, rx = 0, ry = 0, rz = 0) {
      L.addStatic(new THREE.BoxGeometry(w, h, d), this.base.clone().multiply(xf(lx, ly, lz, ry, rx, rz)), key); return this;
    }
    cyl(rt, rb, h, lx, ly, lz, key, rx = 0, ry = 0, rz = 0, seg = 10) {
      L.addStatic(new THREE.CylinderGeometry(rt, rb, h, seg), this.base.clone().multiply(xf(lx, ly, lz, ry, rx, rz)), key); return this;
    }
    geo(g, lx, ly, lz, key, rx = 0, ry = 0, rz = 0) { L.addStatic(g, this.base.clone().multiply(xf(lx, ly, lz, ry, rx, rz)), key); return this; }
    // collision AABB from a local rect
    solid(w, d, lx = 0, lz = 0, top = 1) {
      const c = Math.cos(this.ry), s = Math.sin(this.ry);
      const cx = this.x + lx * c + lz * s, cz = this.z - lx * s + lz * c;
      const hw = Math.abs(w / 2 * c) + Math.abs(d / 2 * s), hd = Math.abs(w / 2 * s) + Math.abs(d / 2 * c);
      L.addBox(cx - hw, cz - hd, cx + hw, cz + hd, top); return this;
    }
  }
  P.Kit = Kit;

  /* ---------------- furniture ---------------- */
  P.bed = (x, z, ry, broken) => {
    const k = new Kit(x, z, ry);
    const tilt = broken ? 0.18 : 0;
    k.box(0.95, 0.05, 2.0, 0, 0.55, 0, 'p_steel', 0, 0, tilt);
    k.box(0.9, 0.16, 1.9, 0, 0.66 + (broken ? 0.06 : 0), 0, 'p_fabric', broken ? 0.06 : 0, 0, tilt);
    if (!broken) k.box(0.6, 0.1, 0.35, 0, 0.8, -0.72, 'p_white');
    for (const [lx, lz] of [[-0.42, -0.92], [0.42, -0.92], [-0.42, 0.92], [0.42, 0.92]]) if (!(broken && lx > 0 && lz > 0)) k.cyl(0.025, 0.025, 0.55, lx, 0.27, lz, 'p_steel');
    k.box(0.95, 0.5, 0.04, 0, 0.85, -0.99, 'p_steel').box(0.95, 0.3, 0.04, 0, 0.75, 0.99, 'p_steel');
    // restraint straps
    k.box(0.98, 0.012, 0.07, 0, 0.75, 0.2, 'p_dark').box(0.98, 0.012, 0.07, 0, 0.75, -0.3, 'p_dark');
    k.solid(1.0, 2.05, 0, 0, 0.8);
  };
  P.examBed = (x, z, ry) => {
    const k = new Kit(x, z, ry);
    k.box(0.7, 0.12, 1.9, 0, 0.82, 0, 'p_dark').box(0.7, 0.1, 0.5, 0, 0.95, -0.72, 'p_dark', -0.35);
    k.cyl(0.12, 0.18, 0.76, 0, 0.38, 0, 'p_steel').box(0.6, 0.05, 0.7, 0, 0.03, 0, 'p_steel');
    k.solid(0.75, 1.95, 0, 0, 0.9);
  };
  P.desk = (x, z, ry, w = 1.6, d = 0.75) => {
    const k = new Kit(x, z, ry);
    k.box(w, 0.04, d, 0, 0.76, 0, 'p_wood');
    k.box(0.04, 0.74, d - 0.05, -w / 2 + 0.04, 0.37, 0, 'p_metal').box(0.04, 0.74, d - 0.05, w / 2 - 0.04, 0.37, 0, 'p_metal');
    k.box(0.42, 0.62, d - 0.08, w / 2 - 0.27, 0.42, 0, 'p_metal');
    k.solid(w, d, 0, 0, 0.8);
  };
  P.chair = (x, z, ry, fallen) => {
    const k = new Kit(x, z, ry, fallen ? 0.24 : 0);
    const rx = fallen ? Math.PI / 2 : 0;
    const g = new THREE.Group();
    // chair built in its own local frame then tipped
    const base = fallen ? xf(0, 0, 0, 0, rx) : new THREE.Matrix4();
    const part = (geo, lx, ly, lz, key) => L.addStatic(geo, k.base.clone().multiply(base).multiply(xf(lx, ly, lz, 0)), key);
    part(new THREE.BoxGeometry(0.46, 0.05, 0.44), 0, 0.46, 0, 'p_fabric');
    part(new THREE.BoxGeometry(0.46, 0.44, 0.04), 0, 0.7, -0.21, 'p_fabric');
    for (const [lx, lz] of [[-0.2, -0.19], [0.2, -0.19], [-0.2, 0.19], [0.2, 0.19]]) part(new THREE.CylinderGeometry(0.015, 0.015, 0.46, 6), lx, 0.23, lz, 'p_steel');
    if (!fallen) k.solid(0.45, 0.45, 0, 0, 0.5);
    return g;
  };
  P.cabinet = (x, z, ry, w = 0.9, h = 1.9, d = 0.45, key = 'p_white') => {
    const k = new Kit(x, z, ry);
    k.box(w, h, d, 0, h / 2, 0, key);
    k.box(w - 0.06, 0.02, d - 0.06, 0, h * 0.5, 0.02, 'p_dark');
    k.box(0.02, h - 0.1, 0.02, 0, h / 2, d / 2 + 0.005, 'p_dark');
    k.solid(w, d, 0, 0, h);
  };
  P.shelf = (x, z, ry, w = 2.0, levels = 4, rng = Math.random) => {
    const k = new Kit(x, z, ry);
    for (const lx of [-w / 2 + 0.03, w / 2 - 0.03]) for (const lz of [-0.22, 0.22]) k.box(0.04, 2.1, 0.04, lx, 1.05, lz, 'p_rust');
    for (let i = 0; i < levels; i++) {
      const y = 0.15 + i * 0.6;
      k.box(w, 0.03, 0.48, 0, y, 0, 'p_rust');
      let px = -w / 2 + 0.1;
      while (px < w / 2 - 0.3) {
        const bw = 0.2 + rng() * 0.35, bh = 0.15 + rng() * 0.3;
        if (rng() > 0.25) k.box(bw, bh, 0.3 + rng() * 0.12, px + bw / 2, y + bh / 2 + 0.015, (rng() - 0.5) * 0.05, rng() > 0.5 ? 'p_wood' : 'p_white', 0, (rng() - 0.5) * 0.3);
        px += bw + 0.05;
      }
    }
    k.solid(w, 0.5, 0, 0, 2.1);
  };
  P.ivStand = (x, z) => {
    const k = new Kit(x, z, 0);
    k.cyl(0.012, 0.012, 1.9, 0, 0.95, 0, 'p_steel').box(0.5, 0.02, 0.02, 0, 1.85, 0, 'p_steel');
    for (let i = 0; i < 5; i++) k.box(0.3, 0.02, 0.03, 0, 0.04, 0, 'p_steel', 0, i * 1.25);
    k.box(0.12, 0.2, 0.05, 0.18, 1.7, 0, 'p_fabric');
  };
  P.tray = (x, z, ry) => {
    const k = new Kit(x, z, ry);
    k.box(0.6, 0.03, 0.4, 0, 0.85, 0, 'p_steel').cyl(0.02, 0.02, 0.85, -0.25, 0.42, 0, 'p_steel').box(0.5, 0.03, 0.4, 0, 0.02, 0, 'p_steel');
    for (let i = 0; i < 4; i++) k.box(0.18, 0.01, 0.02, -0.15 + i * 0.1, 0.875, 0.05 * (i % 2), 'p_steel', 0, i);
    k.solid(0.6, 0.4, 0, 0, 0.9);
  };
  P.crt = (x, y, z, ry, scr) => {
    const k = new Kit(x, z, ry, y);
    k.box(0.42, 0.36, 0.4, 0, 0.18, -0.05, 'p_dark');
    if (scr) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.26), scr);
      m.position.set(x, y + 0.19, z); m.rotation.y = ry;
      m.translateZ(0.151);
      L.scene.add(m); return m;
    }
    return null;
  };
  P.labTable = (x, z, ry, rng) => {
    const k = new Kit(x, z, ry);
    k.box(2.2, 0.06, 0.85, 0, 0.92, 0, 'p_white').box(2.1, 0.86, 0.75, 0, 0.45, 0, 'p_metal');
    for (let i = 0; i < 5; i++) {
      const r = 0.03 + rng() * 0.05, h = 0.1 + rng() * 0.25;
      k.cyl(r, r * 1.1, h, -0.9 + rng() * 1.8, 0.95 + h / 2, (rng() - 0.5) * 0.5, 'p_steel');
    }
    k.box(0.5, 0.35, 0.4, 0.6, 1.12, -0.1, 'p_dark');
    k.solid(2.2, 0.85, 0, 0, 1);
  };
  P.serverRack = (x, z, ry) => {
    const k = new Kit(x, z, ry);
    k.box(0.65, 2.0, 0.9, 0, 1.0, 0, 'p_dark');
    for (let i = 0; i < 9; i++) k.box(0.58, 0.14, 0.02, 0, 0.3 + i * 0.18, 0.455, 'p_metal');
    k.solid(0.65, 0.9, 0, 0, 2);
  };
  P.locker = (x, z, ry) => {
    const k = new Kit(x, z, ry);
    k.box(0.62, 2.0, 0.55, 0, 1.0, 0, 'p_green');
    k.solid(0.62, 0.55, 0, 0, 2);
  };
  P.pipeRun = (x0, z0, x1, z1, y, r, key = 'p_pipe') => {
    const dx = x1 - x0, dz = z1 - z0, len = Math.hypot(dx, dz);
    const ry = Math.atan2(dx, dz);
    L.addStatic(new THREE.CylinderGeometry(r, r, len, 10), xf((x0 + x1) / 2, y, (z0 + z1) / 2, ry, Math.PI / 2), key);
    for (let t = 1.2; t < len; t += 2.4) {
      const px = x0 + dx * t / len, pz = z0 + dz * t / len;
      L.addStatic(new THREE.CylinderGeometry(r * 1.3, r * 1.3, 0.08, 10), xf(px, y, pz, ry, Math.PI / 2), 'p_dark');
    }
  };
  P.elecPanel = (x, y, z, ry) => {
    const k = new Kit(x, z, ry, y);
    k.box(0.7, 0.9, 0.22, 0, 0, 0, 'p_metal').box(0.6, 0.06, 0.03, 0, 0.3, 0.12, 'p_yellow');
    for (let i = 0; i < 3; i++) k.cyl(0.03, 0.03, 0.6, -0.2 + i * 0.2, -0.75, 0.0, 'p_dark');
  };
  P.debris = (x, z, r, n, rng, keys) => {
    for (let i = 0; i < n; i++) {
      const a = rng() * 6.28, d = rng() * r;
      const s = 0.05 + rng() * 0.22;
      L.addStatic(new THREE.BoxGeometry(s * (0.5 + rng()), s * 0.4, s * (0.5 + rng())), xf(x + Math.cos(a) * d, s * 0.2, z + Math.sin(a) * d, rng() * 6, (rng() - 0.5) * 0.6, (rng() - 0.5) * 0.6), keys[i % keys.length]);
    }
  };

  /* ---------------- decals ---------------- */
  const decalGeo = new THREE.PlaneGeometry(1, 1);
  P.decals = [];
  P.decal = (tex, x, y, z, w, h, n, opts) => {
    opts = opts || {};
    const mat = new THREE.MeshStandardMaterial({ map: tex, transparent: true, depthWrite: false, roughness: opts.rough != null ? opts.rough : 0.4, metalness: 0, polygonOffset: true, polygonOffsetFactor: -2, color: opts.color || 0xffffff });
    const m = new THREE.Mesh(decalGeo, mat);
    m.scale.set(w, h, 1); m.position.set(x, y, z);
    if (n === 'floor') { m.rotation.x = -Math.PI / 2; m.rotation.z = opts.rot || 0; }
    else m.rotation.y = Math.atan2(n[0], n[2]);
    m.receiveShadow = true;
    L.scene.add(m); P.decals.push(m); return m;
  };
  P.puddle = (x, z, s, seed) => {
    const mat = new THREE.MeshStandardMaterial({ color: 0x0b0d0c, roughness: 0.04, metalness: 0.2, alphaMap: NP.Tex.puddle(seed), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, opacity: 0.92 });
    const m = new THREE.Mesh(decalGeo, mat);
    m.rotation.x = -Math.PI / 2; m.rotation.z = seed; m.scale.set(s, s, 1); m.position.set(x, 0.004, z);
    m.receiveShadow = true;
    L.scene.add(m);
    (L.puddles = L.puddles || []).push({ x, z, r: s * 0.4 });
    return m;
  };

  /* ---------------- fixtures helpers ---------------- */
  const FL = [0.82, 1.0, 0.86], WARM = [1.0, 0.62, 0.3], RED = [1.0, 0.07, 0.04], AMB = [1.0, 0.55, 0.18], GREEN = [0.55, 1.0, 0.6], COLD = [0.7, 0.85, 1.0];
  P.COL = { FL, WARM, RED, AMB, GREEN, COLD };
  P.fl = (gx, gz, circuit, opt) => {
    const p = P.at(gx, gz, opt && opt.ox, opt && opt.oz);
    return L.addFixture(Object.assign({ x: p.x, y: L.ceilH(gx, gz) - 0.06, z: p.z, kind: 'fluor', color: FL, intensity: 1.15, range: 8.5, circuit, rotY: opt && opt.rotY }, opt || {}));
  };
  P.emer = (gx, gz, side, opt) => {
    const p = P.at(gx, gz); const n = { n: [0, 0, 1], s: [0, 0, -1], w: [1, 0, 0], e: [-1, 0, 0] }[side];
    const x = p.x - n[0] * (C / 2 - 0.06), z = p.z - n[2] * (C / 2 - 0.06);
    return L.addFixture(Object.assign({ x, y: Math.min(2.45, L.ceilH(gx, gz) - 0.3), z, kind: 'emer', color: RED, intensity: 0.75, range: 7, circuit: 'emer', n }, opt || {}));
  };
  P.cage = (gx, gz, circuit, opt) => {
    const p = P.at(gx, gz, opt && opt.ox, opt && opt.oz);
    return L.addFixture(Object.assign({ x: p.x, y: L.ceilH(gx, gz) - 0.28, z: p.z, kind: 'cage', color: AMB, intensity: 0.9, range: 7, circuit }, opt || {}));
  };

  /* ================= POPULATE THE FACILITY ================= */
  P.populate = function (rng) {
    const R = rng;
    const deg = Math.PI / 180;

    /* ---- A0. RECOVERY ROOM (v: 3..7 x 30..34) ---- */
    {
      const b1 = P.at(4, 32); P.bed(b1.x, b1.z, Math.PI / 2);          // player wakes here
      const b2 = P.at(4, 30, 0, -0.2); P.bed(b2.x, b2.z, Math.PI / 2, true);
      const t = P.at(5, 31, 0.5, -0.3); P.tray(t.x, t.z, 0.2);
      P.ivStand(b1.x + 0.6, b1.z - 1.2);
      const cab = P.at(7, 30, 0.6, -0.8); P.cabinet(cab.x, cab.z, -Math.PI / 2, 0.9, 1.9, 0.45);
      const ch = P.at(6, 34, 0, 0.3); P.chair(ch.x, ch.z, 0.6, true);
      P.fl(5, 32, 'recov', { flicker: 'dying', intensity: 1.0 });
      P.emer(7, 33, 'e');
      P.emer(3, 30, 'n', { intensity: 0.5 });
      P.debris(P.at(5, 33).x, P.at(5, 33).z, 1.2, 8, R, ['p_white', 'p_fabric']);
      // mirror frame on west wall
      const mp = P.at(3, 32); const mk = new Kit(mp.x - C / 2 + 0.03, mp.z, Math.PI / 2);
      mk.box(2.0, 0.08, 0.06, 0, 2.3, 0, 'p_metal').box(2.0, 0.08, 0.06, 0, 0.9, 0, 'p_metal').box(0.08, 1.48, 0.06, -1.0, 1.6, 0, 'p_metal').box(0.08, 1.48, 0.06, 1.0, 1.6, 0, 'p_metal');
    }

    /* ---- A. RECEPTION (r: 9..21 x 28..36) ---- */
    {
      // curved reception counter facing south at x 14..17, z 32..33
      const dc = P.at(15, 32, 0.6, 0.4);
      const k = new Kit(dc.x, dc.z, 0);
      k.box(3.6, 1.1, 0.5, 0, 0.55, 0.8, 'p_wood').box(3.8, 0.05, 0.62, 0, 1.12, 0.8, 'p_white');
      k.box(0.5, 1.1, 1.6, -1.6, 0.55, 0, 'p_wood').box(0.5, 1.1, 1.6, 1.6, 0.55, 0, 'p_wood');
      k.box(3.2, 0.04, 0.7, 0, 0.75, 0.2, 'p_wood');
      k.solid(3.6, 0.55, 0, 0.8, 1.2).solid(0.5, 1.6, -1.6, 0, 1.2).solid(0.5, 1.6, 1.6, 0, 1.2);
      P.chair(dc.x - 0.5, dc.z - 0.2, Math.PI, false);
      P.chair(dc.x + 0.9, dc.z - 0.5, 2.4, true);
      // waiting chairs rows
      for (let r = 0; r < 2; r++) for (let i = 0; i < 5; i++) {
        const c = P.at(10, 29 + r * 2, -0.6 + i * 0.55, 0.2);
        if (R() > 0.15) P.chair(c.x, c.z, Math.PI * (r ? 1 : 0), R() > 0.85);
      }
      for (let i = 0; i < 4; i++) { const c = P.at(19, 35, -0.8 + i * 0.55, 0.3); P.chair(c.x, c.z, Math.PI, i === 2); }
      // planters
      for (const [gx, gz] of [[9, 36], [21, 28]]) { const p = P.at(gx, gz, gx < 15 ? -0.6 : 0.6, gz > 30 ? 0.6 : -0.6); new Kit(p.x, p.z, 0).cyl(0.3, 0.24, 0.6, 0, 0.3, 0, 'p_dark').cyl(0.02, 0.05, 1.1, 0, 1.0, 0, 'p_wood', 0.2).cyl(0.01, 0.03, 0.8, 0.1, 0.9, 0, 'p_wood', -0.5).solid(0.6, 0.6, 0, 0, 0.6); }
      // sealed main entrance shutter on south wall
      const se = P.at(12, 36, 0, C / 2 - 0.08);
      const sk = new Kit(se.x, se.z, 0);
      for (let i = 0; i < 12; i++) sk.box(3.4, 0.2, 0.08, 0, 0.12 + i * 0.22, 0, 'p_rust');
      sk.box(3.6, 0.3, 0.2, 0, 2.75, 0, 'p_metal');
      // pillars trim
      for (const [gx, gz] of [[12, 30], [18, 30], [12, 34], [18, 34]]) { const p = P.at(gx, gz); new Kit(p.x, p.z, 0).box(C + 0.06, 0.12, C + 0.06, 0, 0.06, 0, 'p_dark'); }
      // ceiling lights
      [[10, 29], [15, 29], [20, 29], [10, 32], [20, 32], [10, 35], [15, 35], [20, 35]].forEach(([gx, gz]) => P.fl(gx, gz, 'recep', { intensity: 1.2 }));
      P.fl(15, 31, 'recepF', { flicker: 'dying', intensity: 1.3 });
      P.emer(9, 28, 'n'); P.emer(21, 36, 's'); P.emer(21, 30, 'e', { intensity: 0.6 }); P.emer(9, 34, 'w', { intensity: 0.6 });
      P.debris(P.at(13, 33).x, P.at(13, 33).z, 2, 16, R, ['p_white', 'p_wood', 'p_dark']);
      P.puddle(P.at(17, 35).x, P.at(17, 35).z, 2.6, 3);
      P.puddle(P.at(11, 31).x, P.at(11, 31).z, 1.8, 5);
    }

    /* ---- SERVICE CORRIDOR + STORAGE + GENERATOR ---- */
    {
      for (let gz = 27; gz <= 37; gz += 1) { /* pipes along the ceiling */ }
      const a = P.at(23, 27, -0.9, -1.0), b = P.at(23, 37, -0.9, 1.0);
      P.pipeRun(a.x, a.z, b.x, b.z, 2.65, 0.12);
      P.pipeRun(a.x + 0.35, a.z, b.x + 0.35, b.z, 2.75, 0.07, 'p_rust');
      P.pipeRun(a.x + 4.0, a.z, b.x + 4.0, b.z, 2.7, 0.09);
      P.fl(23, 28, 'service', { ox: 1.2 }); P.fl(23, 32, 'service', { ox: 1.2, flicker: 'buzz' }); P.fl(23, 36, 'service', { ox: 1.2 });
      P.emer(24, 29, 'e'); P.emer(23, 35, 'w', { intensity: 0.6 });
      const ep = P.at(24, 31, C / 2 - 0.12, 0); P.elecPanel(ep.x, 1.4, ep.z, -Math.PI / 2);
      P.puddle(P.at(24, 33).x - 0.6, P.at(24, 33).z, 2.2, 7);
      // storage
      P.shelf(P.at(27, 27).x + 0.9, P.at(27, 27).z - 0.85, 0, 2.6, 4, R);
      P.shelf(P.at(30, 27).x + 0.3, P.at(30, 27).z - 0.85, 0, 2.6, 4, R);
      P.shelf(P.at(31, 29).x + 0.85, P.at(31, 29).z, -Math.PI / 2, 2.4, 4, R);
      P.shelf(P.at(28, 30).x, P.at(28, 30).z + 0.85, Math.PI, 3.0, 3, R);
      for (let i = 0; i < 6; i++) { const p = P.at(27 + (i % 3), 29, R() - 0.5, R() - 0.5); new Kit(p.x, p.z, R() * 3).box(0.5, 0.4, 0.4, 0, 0.2, 0, 'p_wood').solid(0.55, 0.55, 0, 0, 0.4); }
      P.fl(27, 28, 'store', { flicker: 'buzz' }); P.fl(30, 29, 'store');
      P.emer(26, 30, 'w', { intensity: 0.5 });
      // generator room
      const gp = P.at(29, 34, 0.6, 0.6);
      const gk = new Kit(gp.x, gp.z, 0);
      gk.box(3.2, 1.6, 1.5, 0, 0.8, 0, 'p_green').box(3.4, 0.15, 1.7, 0, 0.07, 0, 'p_dark').box(1.0, 0.5, 1.2, 1.2, 1.85, 0, 'p_metal');
      gk.cyl(0.18, 0.18, 2.4, -1.1, 2.6, 0, 'p_pipe').cyl(0.22, 0.22, 0.2, -1.1, 3.85, 0, 'p_dark');
      gk.cyl(0.55, 0.55, 2.6, -0.4, 0.6, -1.7, 'p_yellow', 0, 0, Math.PI / 2, 14); // fuel tank
      gk.solid(3.4, 1.7, 0, 0, 1.7).solid(2.6, 1.15, -0.4, -1.7, 1.2);
      for (let i = 0; i < 4; i++) gk.box(0.06, 1.2, 1.52, -1.4 + i * 0.25, 0.9, 0, 'p_dark');
      const pa = P.at(26, 32, -0.8, -0.8), pb = P.at(33, 32, 0.8, -0.8);
      P.pipeRun(pa.x, pa.z, pb.x, pb.z, 3.6, 0.15); P.pipeRun(pa.x, pa.z + 0.4, pb.x, pb.z + 0.4, 3.85, 0.1, 'p_rust');
      P.cage(28, 33, 'gen'); P.cage(31, 36, 'gen'); P.cage(32, 33, 'gen');
      P.emer(26, 34, 'w'); P.emer(33, 37, 's', { intensity: 0.5 });
      P.puddle(gp.x - 1.8, gp.z + 1.6, 2.4, 11);
      P.debris(P.at(27, 36).x, P.at(27, 36).z, 1, 10, R, ['p_rust', 'p_dark']);
    }

    /* ---- B. MEDICAL WING ---- */
    {
      for (const gz of [14, 18, 22, 25]) P.fl(15, gz, 'med', { ox: 1.2, rotY: Math.PI / 2, flicker: gz === 18 ? 'buzz' : 'stable' });
      P.emer(16, 20, 'e', { intensity: 0.55 }); P.emer(15, 26, 'w', { intensity: 0.55 }); P.emer(15, 13, 'w', { intensity: 0.55 });
      // corridor benches & wheel marks
      const bp = P.at(15, 21, -0.85, 0); new Kit(bp.x, bp.z, Math.PI / 2).box(1.6, 0.06, 0.4, 0, 0.45, 0, 'p_wood').box(0.05, 0.45, 0.35, -0.7, 0.22, 0, 'p_steel').box(0.05, 0.45, 0.35, 0.7, 0.22, 0, 'p_steel').solid(1.6, 0.42, 0, 0, 0.5);
      // E1 exam
      const e1a = P.at(19, 23, 0.3, 0.2); P.examBed(e1a.x, e1a.z, 0);
      const e1b = P.at(21, 23, 0.3, 0.2); P.examBed(e1b.x, e1b.z, 0);
      P.tray(P.at(20, 25).x, P.at(20, 25).z, 0.4);
      P.cabinet(P.at(22, 26).x + 0.6, P.at(22, 26).z + 0.3, -Math.PI / 2, 1.2, 1.9, 0.45);
      P.ivStand(P.at(18, 25).x - 0.3, P.at(18, 25).z);
      P.fl(20, 23, 'med', { rotY: Math.PI / 2 }); P.fl(20, 25, 'med', { flicker: 'buzz' });
      // overhead surgical lamp
      const sl = P.at(19, 23, 0.3, 0.2); new Kit(sl.x, sl.z, 0).cyl(0.02, 0.02, 0.8, 0, 2.6, 0, 'p_steel').cyl(0.32, 0.12, 0.18, 0, 2.15, 0, 'p_white');
      // E2 simulation room
      P.fl(20, 16, 'sim', { flicker: 'buzz' }); P.fl(20, 18, 'sim');
      const wb = P.at(22, 15, C / 2 - 0.05, 0); new Kit(wb.x, wb.z, -Math.PI / 2).box(2.6, 1.2, 0.04, 0, 1.6, 0, 'p_white');
      // W1 pharmacy
      for (let i = 0; i < 3; i++) { const p = P.at(10 + i, 22, 0, -C / 2 + 0.25); P.cabinet(p.x, p.z, 0, 1.0, 2.0, 0.42); }
      for (let i = 0; i < 2; i++) { const p = P.at(10 + i, 25, 0.4, C / 2 - 0.25); P.cabinet(p.x, p.z, Math.PI, 1.0, 2.0, 0.42); }
      P.desk(P.at(12, 24).x, P.at(12, 24).z, Math.PI / 2, 1.4, 0.7);
      P.fl(11, 23, 'med', { flicker: 'dying' }); P.fl(12, 24, 'med');
      P.debris(P.at(11, 24).x, P.at(11, 24).z, 1.0, 14, R, ['p_white']);
      P.puddle(P.at(16, 17).x, P.at(16, 17).z, 1.8, 13);
    }

    /* ---- C. PATIENT WARD ---- */
    {
      [[3, 14], [7, 15], [11, 14]].forEach(([gx, gz], i) => P.fl(gx, gz, 'ward', { ox: 1.2, flicker: i === 0 ? 'dying' : 'stable' }));
      P.emer(2, 14, 'w', { intensity: 0.6 }); P.emer(13, 15, 's', { intensity: 0.5 }); P.emer(8, 14, 'n', { intensity: 0.5 });
      const rooms = [[2, 17, 4, 20, 's'], [6, 17, 8, 20, 's'], [10, 17, 12, 20, 's'], [2, 9, 4, 12, 'n'], [6, 9, 8, 12, 'n']];
      rooms.forEach(([x0, z0, x1, z1, side], i) => {
        const cx = (x0 + x1) / 2, far = side === 's' ? z1 : z0;
        const bp = P.at(Math.round(cx), far, 0, side === 's' ? 0.0 : 0.0);
        P.bed(bp.x, bp.z, 0, i === 1 || i === 4);
        if (i !== 3) P.ivStand(bp.x + 0.9, bp.z - 0.5);
        P.fl(Math.round(cx), (z0 + z1) >> 1, 'ward', { flicker: i === 2 ? 'dying' : i === 4 ? 'buzz' : 'stable', intensity: 0.9 });
        P.debris(P.at(Math.round(cx), (z0 + z1) >> 1).x, P.at(Math.round(cx), (z0 + z1) >> 1).z, 1.4, 8, R, ['p_fabric', 'p_white', 'p_wood']);
        // scratch marks on walls (decals)
        const wall = P.at(x0, (z0 + z1) >> 1, -C / 2 + 0.012, 0);
        P.decal(NP.Tex.scrawl(['////', 'IIII', '|||| ||', 'WAKE'][i % 4], 512, 256, 120), wall.x, 1.3, wall.z, 1.4, 0.7, [1, 0, 0], { color: 0x9a8a80 });
      });
      P.puddle(P.at(9, 15).x, P.at(9, 15).z, 2.0, 17);
      P.decal(NP.Tex.footprints(), P.at(5, 14).x, 0.006, P.at(5, 14).z, 0.6, 2.4, 'floor', { rot: Math.PI / 2 + 0.1 });
    }

    /* ---- D. RESEARCH LAB ---- */
    {
      P.labTable(P.at(12, 9).x + 0.5, P.at(12, 9).z, 0, R);
      P.labTable(P.at(12, 11).x + 0.5, P.at(12, 11).z - 0.3, 0, R);
      P.labTable(P.at(20, 10).x, P.at(20, 10).z + 0.5, 0, R);
      for (let i = 0; i < 4; i++) { const p = P.at(10, 5 + i, -0.65, 0.4); P.serverRack(p.x, p.z, Math.PI / 2); }
      // Somnograph: a ring scanner with a bed
      const sp = P.at(15, 9, 0.6, 0.4);
      const sk = new Kit(sp.x, sp.z, Math.PI / 2);
      sk.geo(new THREE.TorusGeometry(0.95, 0.28, 12, 28), 0, 1.15, 0, 'p_white');
      sk.box(0.7, 0.1, 2.6, 0, 0.82, 0, 'p_dark', 0, Math.PI / 2).box(0.5, 0.8, 0.5, 0, 0.4, 0, 'p_metal');
      sk.box(0.4, 1.2, 0.5, 0, 0.6, -0.4, 'p_white');
      sk.solid(2.6, 1.8, 0, 0, 1.4);
      // console desk near terminal
      P.desk(P.at(12, 4).x + 0.4, P.at(12, 4).z - 0.5, 0, 2.4, 0.8);
      P.fl(12, 9, 'lab'); P.fl(15, 6, 'lab', { flicker: 'buzz' }); P.fl(20, 10, 'lab'); P.fl(15, 11, 'lab', { flicker: 'dying' });
      P.fl(20, 5, 'cell', { color: COLD, intensity: 0.9 });
      P.emer(10, 11, 'w', { intensity: 0.6 }); P.emer(22, 9, 'e', { intensity: 0.6 }); P.emer(16, 4, 'n', { intensity: 0.5 });
      P.debris(P.at(18, 9).x, P.at(18, 9).z, 1.8, 18, R, ['p_white', 'p_steel']);
      // shattered glass shards near the cell window
      for (let i = 0; i < 26; i++) { const p = P.at(18 + R() * 4, 8, 0, R() * 0.8 - 0.6); L.addStatic(new THREE.PlaneGeometry(0.06 + R() * 0.1, 0.06 + R() * 0.12), xf(p.x, 0.008, p.z, R() * 6, -Math.PI / 2), 'p_steel'); }
      P.decal(NP.Tex.bloodDecal(77), P.at(20, 5).x, 0.006, P.at(20, 5).z, 1.6, 1.6, 'floor');
      P.decal(NP.Tex.footprints(), P.at(21, 9).x, 0.006, P.at(21, 9).z + 0.4, 0.6, 2.4, 'floor', { rot: -1.4 });
    }

    /* ---- E. MAINTENANCE TUNNELS ---- */
    {
      const seg = [[P.at(24, 5, 0.6, -1.0), P.at(24, 18, 0.6, 0.8)], [P.at(24, 17, -0.8, -0.8), P.at(37, 17, 1.0, -0.8)], [P.at(37, 19, 0.85, -1.0), P.at(37, 28, 0.85, 1.0)]];
      seg.forEach(([a, b], i) => {
        P.pipeRun(a.x, a.z, b.x, b.z, 2.2, 0.14);
        P.pipeRun(a.x + (i === 1 ? 0 : -0.45), a.z + (i === 1 ? 0.45 : 0), b.x + (i === 1 ? 0 : -0.45), b.z + (i === 1 ? 0.45 : 0), 2.3, 0.08, 'p_rust');
      });
      [[24, 6], [24, 10], [24, 14], [25, 17], [29, 18], [33, 17], [36, 20], [37, 24], [36, 27]].forEach(([gx, gz], i) => P.cage(gx, gz, 'tunnel', { flicker: i % 3 === 1 ? 'buzz' : i === 4 ? 'dying' : 'stable', intensity: 0.8 }));
      [[24, 8, 'w'], [25, 16, 'e'], [31, 17, 'n'], [37, 21, 'e'], [36, 26, 'w']].forEach(([gx, gz, s]) => P.emer(gx, gz, s, { intensity: 0.6 }));
      [[24, 12, 'w'], [28, 18, 's'], [37, 25, 'e']].forEach(([gx, gz, s]) => {
        const p = P.at(gx, gz); const off = { w: [-C / 2 + 0.12, 0, Math.PI / 2], e: [C / 2 - 0.12, 0, -Math.PI / 2], s: [0, C / 2 - 0.12, Math.PI] }[s];
        P.elecPanel(p.x + off[0], 1.3, p.z + off[1], off[2]);
      });
      P.puddle(P.at(25, 7).x, P.at(25, 7).z, 1.6, 21); P.puddle(P.at(34, 18).x, P.at(34, 18).z, 2.0, 23);
      P.decal(NP.Tex.bloodDecal(91), P.at(30, 17).x, 0.006, P.at(30, 17).z, 1.2, 1.2, 'floor');
    }

    /* ---- F. SECURITY CONTROL ---- */
    {
      const dk = P.at(30, 21, 0.6, 0.3); P.desk(dk.x, dk.z, 0, 3.4, 0.9);
      P.chair(dk.x, dk.z + 0.8, Math.PI + 0.3, false);
      P.serverRack(P.at(34, 21).x + 0.6, P.at(34, 21).z, -Math.PI / 2);
      P.cabinet(P.at(27, 25).x - 0.6, P.at(27, 25).z + 0.5, Math.PI / 2, 1.0, 1.8, 0.5, 'p_metal');
      P.fl(29, 22, 'sec'); P.fl(32, 24, 'sec', { flicker: 'buzz' });
      P.emer(27, 20, 'n', { intensity: 0.6 }); P.emer(34, 25, 's', { intensity: 0.5 });
    }

    /* ---- G. CONTAINMENT CHAMBER (c: 28..37 x 4..15, h 7) ---- */
    {
      const cp = P.at(32, 9, 1.2, 0.6);
      const ck = new Kit(cp.x, cp.z, 0);
      ck.cyl(2.3, 2.6, 0.6, 0, 0.3, 0, 'p_dark', 0, 0, 0, 24).cyl(1.6, 1.6, 0.12, 0, 0.66, 0, 'p_steel', 0, 0, 0, 24);
      ck.cyl(1.7, 1.7, 0.4, 0, 6.6, 0, 'p_metal', 0, 0, 0, 24);
      for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; ck.box(0.12, 6.0, 0.12, Math.cos(a) * 1.65, 3.6, Math.sin(a) * 1.65, 'p_steel'); }
      ck.solid(4.2, 4.2, 0, 0, 0.7);
      // cables hanging from ceiling
      for (let i = 0; i < 10; i++) {
        const a = R() * 6.28, r = 2.5 + R() * 2.5;
        const len = 1.5 + R() * 3.5;
        ck.cyl(0.04, 0.04, len, Math.cos(a) * r, 7 - len / 2, Math.sin(a) * r, 'p_dark', (R() - 0.5) * 0.3, 0, (R() - 0.5) * 0.3, 6);
      }
      // machinery along walls
      for (let i = 0; i < 4; i++) { const p = P.at(29 + i * 2, 15, 0, 0.6); new Kit(p.x, p.z, 0).box(1.8, 2.6, 1.0, 0, 1.3, 0, i % 2 ? 'p_green' : 'p_metal').box(1.6, 0.3, 1.05, 0, 2.0, 0, 'p_dark').solid(1.8, 1.0, 0, 0, 2.6); }
      for (let i = 0; i < 3; i++) { const p = P.at(37, 6 + i * 3, 0.6, 0); new Kit(p.x, p.z, -Math.PI / 2).box(2.0, 3.2, 0.9, 0, 1.6, 0, 'p_metal').solid(2.0, 0.9, 0, 0, 3.2); }
      // catwalk ring (visual)
      const rw = P.at(28, 4, -0.6, -0.6); new Kit(rw.x, rw.z, 0).box(0.2, 0.1, 27, 0.5, 3.6, 13.5, 'p_rust').box(25, 0.1, 0.2, 12.5, 3.6, 0.5, 'p_rust');
      P.fl(29, 5, 'cont', { color: GREEN, flicker: 'buzz' }); P.fl(35, 5, 'cont', { color: GREEN }); P.fl(29, 13, 'cont', { color: GREEN, flicker: 'dying' }); P.fl(35, 13, 'cont', { color: GREEN });
      P.fl(32, 9, 'contCore', { color: COLD, intensity: 1.6, range: 10, ox: 1.2, oz: 0.6 });
      P.emer(28, 9, 'w', { flicker: 'strobe' }); P.emer(37, 12, 'e', { flicker: 'strobe' }); P.emer(32, 4, 'n', { intensity: 0.8 });
      P.decal(NP.Tex.bloodDecal(123), cp.x + 2.6, 0.006, cp.z + 1.0, 2.2, 2.2, 'floor');
      P.puddle(P.at(30, 11).x, P.at(30, 11).z, 2.6, 29);
      P.debris(cp.x, cp.z, 4, 40, R, ['p_steel', 'p_dark', 'p_metal']);
    }

    /* ---- H. EXIT ROUTE ---- */
    {
      for (let gx = 9; gx <= 36; gx += 4) L.addFixture({ x: P.at(gx, 1).x, y: 2.75, z: P.at(gx, 1).z + 0.2, kind: 'beacon', color: RED, intensity: 1.2, range: 7, circuit: 'exit', flicker: 'beacon', seed: gx * 0.7 });
      for (let gx = 8; gx <= 36; gx += 6) P.fl(gx, 2, 'exitFl', { oz: -1.2, flicker: gx % 12 ? 'stable' : 'buzz' });
      P.emer(36, 2, 'e', { intensity: 0.6 });
      P.pipeRun(P.at(7, 1).x, P.at(7, 1).z - 0.9, P.at(37, 1).x, P.at(37, 1).z - 0.9, 2.65, 0.12);
      // elevator lobby
      P.fl(3, 2, 'lift', { color: WARM, intensity: 1.0 });
      const ev = P.at(2, 2, -C / 2 + 0.05, 0);
      new Kit(ev.x, ev.z, Math.PI / 2).box(2.0, 2.6, 0.1, 0, 1.3, 0, 'p_steel').box(2.4, 0.3, 0.2, 0, 2.75, 0, 'p_metal');
    }
  };
})(window.NP);
