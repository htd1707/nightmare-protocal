/* NIGHTMARE PROTOCOL — procedural Web Audio engine: positional sfx, reverb, ambience, stingers, creature voice, music.
   Optional overrides: place files in ./audio/ and list them in ./audio/manifest.json as {"stinger":"stinger.ogg", ...}.
   Any name below that has an override buffer plays the file instead of the synthesized version. */
'use strict';
(function (NP) {
  const A = (NP.Audio = { ready: false, overrides: {} });
  let ctx, master, sfx, amb, mus, verbSend, verb, noiseBuf, brownBuf;

  A.init = function () {
    if (A.ready) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    A.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 4; comp.attack.value = 0.004; comp.release.value = 0.25;
    master = ctx.createGain(); master.gain.value = NP.settings.volume;
    master.connect(comp); comp.connect(ctx.destination);
    sfx = ctx.createGain(); sfx.connect(master);
    amb = ctx.createGain(); amb.connect(master);
    mus = ctx.createGain(); mus.gain.value = NP.settings.musicVolume; mus.connect(master);
    // reverb
    verb = ctx.createConvolver(); verb.buffer = impulse(2.8, 2.6);
    verbSend = ctx.createGain(); verbSend.gain.value = 0.35; verbSend.connect(verb); verb.connect(master);
    noiseBuf = makeNoise(2, 'white'); brownBuf = makeNoise(4, 'brown');
    A.ready = true;
    A.loadOverrides();
  };
  A.setVolume = (v) => { if (master) master.gain.setTargetAtTime(v, ctx.currentTime, 0.05); };
  A.setMusicVolume = (v) => { if (mus) mus.gain.setTargetAtTime(v, ctx.currentTime, 0.05); };
  A.suspend = () => { if (ctx && ctx.state === 'running') ctx.suspend(); };
  A.resume = () => { if (ctx && ctx.state === 'suspended') ctx.resume(); };
  A.setReverb = (wet) => { if (verbSend) verbSend.gain.setTargetAtTime(wet, ctx.currentTime, 0.4); };

  A.loadOverrides = async function () {
    try {
      const r = await fetch('audio/manifest.json', { cache: 'no-store' });
      if (!r.ok) return;
      const man = await r.json();
      for (const name in man) {
        try { const b = await (await fetch('audio/' + man[name])).arrayBuffer(); A.overrides[name] = await ctx.decodeAudioData(b); } catch (e) { /* fall back to synth */ }
      }
    } catch (e) { /* no manifest: procedural audio only */ }
  };

  function makeNoise(sec, type) {
    const n = ctx.sampleRate * sec, b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) {
      const w = Math.random() * 2 - 1;
      if (type === 'brown') { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w;
    }
    return b;
  }
  function impulse(sec, decay) {
    const n = ctx.sampleRate * sec, b = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay) * (i < 200 ? i / 200 : 1); }
    return b;
  }

  /* ----- routing: positional or stereo, with occlusion muffling + reverb send ----- */
  function out(pos, opts) {
    opts = opts || {};
    const g = ctx.createGain();
    let head = g;
    if (pos) {
      const p = ctx.createPanner();
      p.panningModel = NP.settings.quality === 'low' ? 'equalpower' : 'HRTF';
      p.distanceModel = 'inverse'; p.refDistance = opts.ref || 1.6; p.rolloffFactor = opts.roll || 1.3; p.maxDistance = 60;
      if (p.positionX) { p.positionX.value = pos.x; p.positionY.value = pos.y != null ? pos.y : 1.2; p.positionZ.value = pos.z; }
      else p.setPosition(pos.x, pos.y != null ? pos.y : 1.2, pos.z);
      // muffle through walls
      if (NP.Player && NP.Player.pos && !NP.Level.los(NP.Player.pos.x, NP.Player.pos.z, pos.x, pos.z, 'sight')) {
        const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 650;
        g.connect(lp); lp.connect(p); g.gain.value = 0.75;
      } else g.connect(p);
      p.connect(opts.bus || sfx);
      head = p;
    } else g.connect(opts.bus || sfx);
    if (opts.verb !== 0) { const s = ctx.createGain(); s.gain.value = opts.verb != null ? opts.verb : 0.5; g.connect(s); s.connect(verbSend); }
    return g;
  }
  function env(g, t, a, peak, hold, rel) {
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.setValueAtTime(peak, t + a + hold); g.gain.exponentialRampToValueAtTime(0.0001, t + a + hold + rel);
  }
  function noise(dest, t, dur, buf) {
    const s = ctx.createBufferSource(); s.buffer = buf || noiseBuf; s.loop = true;
    s.loopStart = Math.random(); s.connect(dest); s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05);
    return s;
  }
  function osc(type, f, dest, t, dur) { const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t); o.connect(dest); o.start(t); o.stop(t + dur + 0.05); return o; }
  function filt(type, f, q, dest) { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q) b.Q.value = q; b.connect(dest); return b; }
  function playBuf(name, pos, vol, opts) {
    const b = A.overrides[name]; if (!b) return false;
    const o = out(pos, opts); o.gain.value = vol;
    const s = ctx.createBufferSource(); s.buffer = b; s.connect(o); s.start();
    return true;
  }
  const now = () => ctx.currentTime;
  const ok = () => A.ready && ctx.state === 'running';

  A.updateListener = function (cam) {
    if (!A.ready) return;
    const l = ctx.listener, p = cam.position;
    const f = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion), u = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
    if (l.positionX) {
      const t = now();
      l.positionX.setTargetAtTime(p.x, t, 0.02); l.positionY.setTargetAtTime(p.y, t, 0.02); l.positionZ.setTargetAtTime(p.z, t, 0.02);
      l.forwardX.setTargetAtTime(f.x, t, 0.02); l.forwardY.setTargetAtTime(f.y, t, 0.02); l.forwardZ.setTargetAtTime(f.z, t, 0.02);
      l.upX.setTargetAtTime(u.x, t, 0.02); l.upY.setTargetAtTime(u.y, t, 0.02); l.upZ.setTargetAtTime(u.z, t, 0.02);
    } else { l.setPosition(p.x, p.y, p.z); l.setOrientation(f.x, f.y, f.z, u.x, u.y, u.z); }
  };

  /* ================= SFX ================= */
  A.footstep = function (surf, vol, run) {
    if (!ok()) return; const t = now();
    if (playBuf('step_' + surf, null, vol * 0.5)) return;
    const o = out(null, { verb: 0.25 }); o.gain.value = 0.45 * vol;
    const g = ctx.createGain(); g.connect(o);
    const f = { tile: [2200, 1.2], concrete: [900, 0.9], metal: [1600, 6], water: [1400, 0.7] }[surf] || [1000, 1];
    const bp = filt('bandpass', f[0] * (0.85 + Math.random() * 0.3), f[1], g);
    noise(bp, t, 0.12);
    env(g, t, 0.003, 1, 0.02, run ? 0.09 : 0.12);
    // low thud
    const g2 = ctx.createGain(); g2.connect(o); osc('sine', 70 + Math.random() * 20, g2, t, 0.12); env(g2, t, 0.002, 0.8, 0.01, 0.08);
    if (surf === 'metal') { const g3 = ctx.createGain(); g3.connect(o); [430, 1120, 2410].forEach((fr) => osc('sine', fr * (0.95 + Math.random() * 0.1), g3, t, 0.3)); env(g3, t, 0.001, 0.12, 0.0, 0.22); }
    if (surf === 'water') { const g4 = ctx.createGain(); g4.connect(o); const hp = filt('highpass', 2500, 0.5, g4); noise(hp, t + 0.02, 0.2); env(g4, t + 0.02, 0.01, 0.5, 0.03, 0.16); }
  };
  A.click = function (v) {
    if (!ok()) return; const t = now(); const o = out(null, { verb: 0.05 }); o.gain.value = 0.25 * (v || 1);
    const g = ctx.createGain(); g.connect(o); osc('square', 2200, filt('highpass', 1500, 1, g), t, 0.02); env(g, t, 0.001, 1, 0.004, 0.02);
  };
  A.reload = function () {
    if (!ok()) return; const t = now();
    [0, 0.35, 0.8].forEach((d, i) => { const o = out(null, { verb: 0.1 }); o.gain.value = 0.3; const g = ctx.createGain(); g.connect(o); noise(filt('bandpass', 3000 - i * 800, 3, g), t + d, 0.05); env(g, t + d, 0.002, 1, 0.01, 0.04); });
  };
  A.pickup = function () {
    if (!ok()) return; const t = now(); const o = out(null, { verb: 0.2 }); o.gain.value = 0.22;
    const g = ctx.createGain(); g.connect(o); osc('triangle', 660, g, t, 0.3); osc('sine', 990, g, t + 0.07, 0.25); env(g, t, 0.005, 1, 0.05, 0.25);
  };
  A.paper = function () {
    if (!ok()) return; const t = now(); const o = out(null, { verb: 0.1 }); o.gain.value = 0.3;
    for (let i = 0; i < 5; i++) { const g = ctx.createGain(); g.connect(o); noise(filt('bandpass', 2500 + Math.random() * 3000, 1.5, g), t + i * 0.05, 0.08); env(g, t + i * 0.05, 0.005, 0.7, 0.02, 0.05); }
  };
  A.beep = function (okk, pos) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.2 }); o.gain.value = 0.18;
    const g = ctx.createGain(); g.connect(o);
    if (okk === 'key') { osc('square', 1400, filt('lowpass', 3000, 1, g), t, 0.06); env(g, t, 0.002, 1, 0.03, 0.03); return; }
    osc('square', okk ? 880 : 220, filt('lowpass', 2400, 1, g), t, 0.4); if (okk) osc('square', 1320, filt('lowpass', 2400, 1, g), t + 0.12, 0.2);
    env(g, t, 0.002, 1, okk ? 0.25 : 0.35, 0.05);
  };
  A.metal = function (pos, vol, pitch) {   // generic metallic impact
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.8, ref: 2.5 }); o.gain.value = vol || 0.8;
    const g = ctx.createGain(); g.connect(o);
    noise(filt('lowpass', 2500, 0.5, g), t, 0.25); env(g, t, 0.001, 1, 0.02, 0.2);
    const g2 = ctx.createGain(); g2.connect(o);
    [97, 233, 411, 587, 1033, 1789].forEach((f, i) => { const os = osc('sine', f * (pitch || 1) * (0.97 + Math.random() * 0.06), g2, t, 2.2); os.frequency.exponentialRampToValueAtTime(f * (pitch || 1) * 0.98, t + 2); });
    env(g2, t, 0.001, 0.32, 0.02, 1.8);
    const g3 = ctx.createGain(); g3.connect(o); osc('sine', 48, g3, t, 0.5); env(g3, t, 0.002, 1, 0.05, 0.4);
  };
  A.door = function (d, open, slam) {
    if (!ok()) return; const t = now(); const pos = { x: d.center.x, y: 1.2, z: d.center.z };
    if (slam) { if (!playBuf('door_slam', pos, 1)) A.metal(pos, 1.2, 0.85); NP.Bus.emit('noise', { x: pos.x, z: pos.z, r: 18, kind: 'door' }); return; }
    if (d.kind === 'hinged') {
      // creak: resonant sweep
      const o = out(pos, { verb: 0.5 }); o.gain.value = 0.18; const g = ctx.createGain(); g.connect(o);
      const s = osc('sawtooth', 140 + Math.random() * 60, filt('bandpass', 900, 8, g), t, 0.9);
      s.frequency.linearRampToValueAtTime(90 + Math.random() * 120, t + 0.8);
      const lfo = ctx.createOscillator(); lfo.frequency.value = 23; const lg = ctx.createGain(); lg.gain.value = 40; lfo.connect(lg); lg.connect(s.frequency); lfo.start(t); lfo.stop(t + 0.9);
      env(g, t, 0.05, 1, 0.5, 0.3);
      if (!open) NP.Timers.after(0.55, () => A.metal(pos, 0.35, 1.3));
    } else {
      // hydraulic hiss + motor
      const o = out(pos, { verb: 0.5 }); o.gain.value = d.kind === 'heavy' ? 0.55 : 0.32;
      const g = ctx.createGain(); g.connect(o); noise(filt('highpass', 3000, 0.7, g), t, 0.8); env(g, t, 0.02, 0.6, 0.3, 0.4);
      const g2 = ctx.createGain(); g2.connect(o); const m = osc('sawtooth', d.kind === 'heavy' ? 45 : 70, filt('lowpass', 260, 2, g2), t, d.kind === 'heavy' ? 2.6 : 1.2);
      m.frequency.linearRampToValueAtTime(d.kind === 'heavy' ? 60 : 90, t + 1);
      env(g2, t, 0.1, 0.8, d.kind === 'heavy' ? 2.0 : 0.6, 0.3);
      NP.Timers.after(d.kind === 'heavy' ? 2.2 : 0.75, () => A.metal(pos, d.kind === 'heavy' ? 0.9 : 0.25, d.kind === 'heavy' ? 0.6 : 1.4));
    }
    NP.Bus.emit('noise', { x: pos.x, z: pos.z, r: d.kind === 'heavy' ? 20 : 8, kind: 'door' });
  };
  A.locked = function (pos) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.3 }); o.gain.value = 0.35;
    for (let i = 0; i < 3; i++) { const g = ctx.createGain(); g.connect(o); noise(filt('bandpass', 700, 3, g), t + i * 0.09, 0.05); env(g, t + i * 0.09, 0.002, 1, 0.01, 0.06); }
  };
  A.lever = function (pos) {
    if (!ok()) return; const t = now(); A.metal(pos, 0.35, 1.8);
    const o = out(pos, { verb: 0.3 }); o.gain.value = 0.4; const g = ctx.createGain(); g.connect(o);
    noise(filt('bandpass', 400, 2, g), t, 0.25); env(g, t, 0.01, 1, 0.08, 0.12);
  };
  A.spark = function (pos) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.4 }); o.gain.value = 0.5;
    for (let i = 0; i < 6; i++) { const g = ctx.createGain(); g.connect(o); const d = Math.random() * 0.3; noise(filt('highpass', 2000 + Math.random() * 4000, 1, g), t + d, 0.03); env(g, t + d, 0.001, 1, 0.005, 0.03); }
    const g = ctx.createGain(); g.connect(o); osc('sawtooth', 60, filt('lowpass', 400, 4, g), t, 0.35); env(g, t, 0.005, 0.5, 0.2, 0.1);
  };
  A.clatter = function (pos) { // harmless falling tray (false scare)
    if (!ok()) return; [0, 0.18, 0.31, 0.42, 0.5].forEach((d, i) => NP.Timers.after(d, () => A.metal(pos, 0.9 - i * 0.15, 2.2 + Math.random() * 0.6)));
    NP.Bus.emit('noise', { x: pos.x, z: pos.z, r: 14, kind: 'clatter' });
  };
  A.glassBang = function (pos) { if (!ok()) return; A.metal(pos, 0.9, 0.5); const t = now(); const o = out(pos, { verb: 0.7 }); o.gain.value = 0.6; const g = ctx.createGain(); g.connect(o); [1800, 2700, 3900].forEach((f) => osc('sine', f, g, t, 1)); env(g, t, 0.001, 0.25, 0.01, 0.9); };
  A.shatter = function (pos) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.8 }); o.gain.value = 0.9;
    for (let i = 0; i < 24; i++) { const d = Math.random() * 0.8; const g = ctx.createGain(); g.connect(o); [2000 + Math.random() * 5000].forEach((f) => osc('sine', f, g, t + d, 0.3)); env(g, t + d, 0.001, 0.15, 0.0, 0.2 + Math.random() * 0.2); }
    const g = ctx.createGain(); g.connect(o); noise(filt('highpass', 1500, 0.5, g), t, 0.6); env(g, t, 0.002, 1, 0.05, 0.5);
  };
  A.scratch = function (pos, dur) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.4, ref: 1.2 }); o.gain.value = 0.5;
    const n = Math.floor((dur || 1.5) * 7);
    for (let i = 0; i < n; i++) {
      const d = i * 0.14 + Math.random() * 0.06; const g = ctx.createGain(); g.connect(o);
      const bp = filt('bandpass', 1800 + Math.random() * 2500, 4, g); const s = noise(bp, t + d, 0.12);
      bp.frequency.linearRampToValueAtTime(900 + Math.random() * 600, t + d + 0.1);
      env(g, t + d, 0.005, 0.9, 0.05, 0.05);
    }
  };
  A.whisper = function (pos) {
    if (!ok()) return; const t = now(); if (playBuf('whisper', pos, 0.6)) return;
    const o = out(pos, { verb: 0.7, ref: 1.0, roll: 1.8 }); o.gain.value = 0.4;
    for (let i = 0; i < 9; i++) {
      const d = i * 0.17 + Math.random() * 0.08; const g = ctx.createGain(); g.connect(o);
      const bp = filt('bandpass', [1300, 2400, 3300, 900][i % 4] * (0.8 + Math.random() * 0.4), 9, g); noise(bp, t + d, 0.25);
      env(g, t + d, 0.04, 0.8, 0.05, 0.12);
    }
  };
  A.footstepsAt = function (pos, run, count) { // creature/distant footsteps
    if (!ok()) return; const n = count || 4; const gap = run ? 0.28 : 0.62;
    for (let i = 0; i < n; i++) NP.Timers.after(i * gap + Math.random() * 0.06, () => {
      const t = now(); const o = out(pos, { verb: 0.6, ref: 2 }); o.gain.value = run ? 0.9 : 0.6;
      const g = ctx.createGain(); g.connect(o); noise(filt('lowpass', 600, 1, g), t, 0.1); env(g, t, 0.003, 1, 0.02, 0.1);
      const g2 = ctx.createGain(); g2.connect(o); osc('sine', 55, g2, t, 0.15); env(g2, t, 0.002, 1, 0.02, 0.1);
      // wet click of long toes
      const g3 = ctx.createGain(); g3.connect(o); noise(filt('bandpass', 3200, 8, g3), t + 0.04, 0.02); env(g3, t + 0.04, 0.001, 0.5, 0.0, 0.02);
    });
  };
  A.creature = function (pos, kind) {
    if (!ok()) return; const t = now();
    if (playBuf('creature_' + kind, pos, 1, { ref: 2.5 })) return;
    const o = out(pos, { verb: 0.7, ref: 2.5 });
    if (kind === 'screech') {
      o.gain.value = 0.55;
      const g = ctx.createGain(); g.connect(o);
      const bp1 = filt('bandpass', 1200, 6, g), bp2 = filt('bandpass', 2600, 7, g);
      for (const f of [310, 467, 621]) { const s = osc('sawtooth', f, bp1, t, 1.4); s.connect(bp2); s.frequency.linearRampToValueAtTime(f * 1.7, t + 0.25); s.frequency.linearRampToValueAtTime(f * 0.8, t + 1.3); }
      noise(filt('bandpass', 3500, 1, g), t, 1.3);
      env(g, t, 0.03, 1, 0.6, 0.6);
    } else if (kind === 'growl') {
      o.gain.value = 0.9;
      const g = ctx.createGain(); g.connect(o);
      const lp = filt('lowpass', 500, 5, g);
      const s = osc('sawtooth', 48, lp, t, 2.2); s.frequency.linearRampToValueAtTime(38, t + 2);
      const am = ctx.createOscillator(); am.frequency.value = 17; const ag = ctx.createGain(); ag.gain.value = 0.6; am.connect(ag); ag.connect(g.gain); am.start(t); am.stop(t + 2.2);
      noise(filt('bandpass', 260, 2, g), t, 2, brownBuf);
      env(g, t, 0.3, 0.8, 1.2, 0.6);
    } else if (kind === 'click') { // throat clicks
      o.gain.value = 0.7;
      for (let i = 0; i < 7; i++) { const d = i * 0.06 + Math.random() * 0.03; const g = ctx.createGain(); g.connect(o); noise(filt('bandpass', 900 + Math.random() * 500, 10, g), t + d, 0.03); env(g, t + d, 0.001, 1, 0.005, 0.03); }
    } else if (kind === 'breath') {
      o.gain.value = 0.6;
      for (let i = 0; i < 2; i++) { const d = i * 1.3; const g = ctx.createGain(); g.connect(o); const bp = filt('bandpass', 500, 1.2, g); noise(bp, t + d, 1.1, brownBuf); bp.frequency.linearRampToValueAtTime(900, t + d + 0.9); env(g, t + d, 0.4, 0.8, 0.2, 0.5); }
    } else if (kind === 'wail') {
      o.gain.value = 0.45;
      const g = ctx.createGain(); g.connect(o); const bp = filt('bandpass', 800, 4, g);
      const s = osc('sawtooth', 220, bp, t, 3.2); s.frequency.linearRampToValueAtTime(330, t + 1); s.frequency.linearRampToValueAtTime(140, t + 3);
      const v = ctx.createOscillator(); v.frequency.value = 6; const vg = ctx.createGain(); vg.gain.value = 12; v.connect(vg); vg.connect(s.frequency); v.start(t); v.stop(t + 3.2);
      env(g, t, 0.5, 1, 1.6, 1.0);
    }
  };
  A.stinger = function (kind, vol) {
    if (!ok()) return; const t = now(); vol = vol || 1;
    if (playBuf('stinger_' + kind, null, vol)) return;
    const o = out(null, { verb: 0.9 }); o.gain.value = 0.7 * vol;
    if (kind === 'hit') { // sudden orchestral-ish slam
      const g = ctx.createGain(); g.connect(o);
      [55, 58.3, 82.4, 116.5, 164.8, 233, 311, 466].forEach((f) => { const s = osc('sawtooth', f, filt('lowpass', 2800, 0.7, g), t, 2.6); s.detune.value = (Math.random() - 0.5) * 30; });
      noise(filt('bandpass', 2400, 0.6, g), t, 0.4);
      env(g, t, 0.003, 0.9, 0.12, 2.2);
      const k = ctx.createGain(); k.connect(o); const ks = osc('sine', 120, k, t, 0.9); ks.frequency.exponentialRampToValueAtTime(32, t + 0.6); env(k, t, 0.001, 1.6, 0.05, 0.7);
    } else if (kind === 'swell') { // reverse-swell into silence
      const g = ctx.createGain(); g.connect(o);
      [110, 116.5, 155.6, 233, 246.9, 349].forEach((f) => osc('sawtooth', f, filt('lowpass', 1600, 1, g), t, 3.2));
      noise(filt('highpass', 2000, 0.5, g), t, 3.1);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.8, t + 2.8); g.gain.linearRampToValueAtTime(0, t + 3.0);
    } else if (kind === 'screech') { // violin-like scrape cluster
      const g = ctx.createGain(); g.connect(o);
      [1760, 1864, 1975, 2093].forEach((f) => { const s = osc('sawtooth', f, filt('bandpass', f, 3, g), t, 1.5); s.frequency.linearRampToValueAtTime(f * 0.6, t + 1.4); });
      env(g, t, 0.005, 0.7, 0.4, 1.0);
      A.stinger('hit', 0.6 * vol);
    } else if (kind === 'low') { // quiet unsettling sub drop
      const g = ctx.createGain(); g.connect(o); const s = osc('sine', 70, g, t, 3); s.frequency.exponentialRampToValueAtTime(28, t + 2.8);
      osc('triangle', 147, filt('lowpass', 500, 1, g), t, 3);
      env(g, t, 0.2, 0.9, 1.5, 1.2);
    } else if (kind === 'static') {
      const g = ctx.createGain(); g.connect(o); noise(filt('bandpass', 3000, 0.3, g), t, 0.6); env(g, t, 0.002, 0.8, 0.4, 0.15);
    }
  };
  A.exhaust = function () { A.breath(3, 0.35); };
  A.breath = function (n, vol) {
    if (!ok()) return; const t = now();
    for (let i = 0; i < (n || 2); i++) {
      const d = i * 0.85; const o = out(null, { verb: 0.05 }); o.gain.value = vol || 0.25; const g = ctx.createGain(); g.connect(o);
      const bp = filt('bandpass', i % 2 ? 1400 : 900, 1.4, g); noise(bp, t + d, 0.7); env(g, t + d, 0.12, 1, 0.15, 0.35);
    }
  };
  A.heartbeat = function (vol) {
    if (!ok()) return; const t = now();
    [0, 0.22].forEach((d, i) => { const o = out(null, { verb: 0 }); o.gain.value = (vol || 0.5) * (i ? 0.65 : 1); const g = ctx.createGain(); g.connect(o); const s = osc('sine', 62, g, t + d, 0.2); s.frequency.exponentialRampToValueAtTime(38, t + d + 0.15); env(g, t + d, 0.004, 1, 0.03, 0.12); });
  };
  A.ding = function (pos) { if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.8 }); o.gain.value = 0.35; const g = ctx.createGain(); g.connect(o); osc('sine', 1046, g, t, 1.5); osc('sine', 1568, g, t, 1.2); env(g, t, 0.002, 1, 0.05, 1.2); };
  A.phone = function (pos) {
    if (!ok()) return; const t = now(); const o = out(pos, { verb: 0.5 }); o.gain.value = 0.25;
    for (let i = 0; i < 2; i++) { const g = ctx.createGain(); g.connect(o); const s = osc('square', 1500, filt('bandpass', 1500, 2, g), t + i * 0.45, 0.4); const m = ctx.createOscillator(); m.frequency.value = 20; const mg = ctx.createGain(); mg.gain.value = 300; m.connect(mg); mg.connect(s.frequency); m.start(t + i * 0.45); m.stop(t + i * 0.45 + 0.42); env(g, t + i * 0.45, 0.01, 1, 0.35, 0.02); }
  };
  A.zap = function (pos) { if (!ok()) return; A.spark(pos); const t = now(); const o = out(pos, { verb: 0.5 }); o.gain.value = 0.5; const g = ctx.createGain(); g.connect(o); osc('sawtooth', 120, filt('lowpass', 2000, 6, g), t, 0.25); env(g, t, 0.002, 1, 0.1, 0.1); };
  A.powerDown = function () {
    if (!ok()) return; const t = now(); const o = out(null, { verb: 0.9 }); o.gain.value = 0.7; const g = ctx.createGain(); g.connect(o);
    const s = osc('sawtooth', 120, filt('lowpass', 900, 2, g), t, 2.5); s.frequency.exponentialRampToValueAtTime(18, t + 2.3);
    const s2 = osc('sine', 60, g, t, 2.5); s2.frequency.exponentialRampToValueAtTime(12, t + 2.3);
    env(g, t, 0.01, 1, 0.6, 1.8);
    A.metal({ x: NP.Player.pos.x + 8, y: 3, z: NP.Player.pos.z - 5 }, 0.6, 0.4);
  };
  A.powerUp = function () {
    if (!ok()) return; const t = now(); const o = out(null, { verb: 0.8 }); o.gain.value = 0.5; const g = ctx.createGain(); g.connect(o);
    const s = osc('sawtooth', 20, filt('lowpass', 700, 2, g), t, 3); s.frequency.exponentialRampToValueAtTime(120, t + 2.5);
    env(g, t, 0.4, 1, 1.5, 1.0);
    for (let i = 0; i < 5; i++) NP.Timers.after(0.6 + i * 0.35, () => A.metal({ x: NP.Player.pos.x + (Math.random() - 0.5) * 20, y: 3, z: NP.Player.pos.z + (Math.random() - 0.5) * 20 }, 0.25, 1.6));
  };

  /* ----- intercom: radio static bed + synthesized speech (subtitled by the UI) ----- */
  A.intercom = function (text, opts) {
    opts = opts || {};
    if (NP.UI) NP.UI.subtitle(text, opts.who || 'INTERCOM', opts.dur || Math.max(3.5, text.length * 0.065));
    if (!ok()) return;
    const t = now(); const o = out(null, { verb: 0.9 }); o.gain.value = 0.18; const g = ctx.createGain(); g.connect(o);
    noise(filt('bandpass', 1800, 0.8, g), t, opts.dur || 4); env(g, t, 0.05, 0.5, (opts.dur || 4) - 0.3, 0.2);
    A.stinger('static', 0.4);
    try {
      if (window.speechSynthesis && !opts.silent) {
        const u = new SpeechSynthesisUtterance(text.replace(/[—…]/g, ', '));
        u.pitch = opts.pitch || 0.35; u.rate = opts.rate || 0.82; u.volume = Math.min(1, NP.settings.volume * 0.75);
        window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
      }
    } catch (e) { /* speech not available: subtitles carry it */ }
  };
  A.stopSpeech = () => { try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } };

  /* ================= LOOPS ================= */
  // ambience: drone + room tone, intensity driven by tension
  let drone = null, alarm = null;
  A.startAmbience = function () {
    if (!A.ready || drone) return;
    const t = now(); const g = ctx.createGain(); g.gain.value = 0; g.connect(amb);
    const lp = filt('lowpass', 260, 1.5, g);
    const nodes = [];
    [41.2, 41.6, 61.7, 82.4].forEach((f) => { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.connect(lp); o.start(t); nodes.push(o); });
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.07; const lg = ctx.createGain(); lg.gain.value = 120; lfo.connect(lg); lg.connect(lp.frequency); lfo.start(t);
    const room = ctx.createBufferSource(); room.buffer = brownBuf; room.loop = true; const rg = ctx.createGain(); rg.gain.value = 0.5; room.connect(filt('lowpass', 400, 0.7, rg)); rg.connect(g); room.start(t);
    // high tension layer (dissonant shimmer)
    const hg = ctx.createGain(); hg.gain.value = 0; hg.connect(amb);
    const hb = filt('bandpass', 3200, 6, hg);
    [3136, 3322].forEach((f) => { const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f; o.connect(hb); o.start(t); nodes.push(o); });
    const hn = ctx.createBufferSource(); hn.buffer = noiseBuf; hn.loop = true; hn.connect(hb); hn.start(t);
    drone = { g, hg, nodes, lp };
    g.gain.setTargetAtTime(0.42, t, 2);
  };
  A.setTension = function (k) { if (!drone) return; const t = now(); drone.g.gain.setTargetAtTime(0.32 + k * 0.35, t, 0.8); drone.hg.gain.setTargetAtTime(k * k * 0.05, t, 0.8); drone.lp.frequency.setTargetAtTime(220 + k * 400, t, 1); };
  A.duck = function (amount, dur) { // silence before a scare
    if (!A.ready) return; const t = now();
    amb.gain.cancelScheduledValues(t); amb.gain.setTargetAtTime(1 - amount, t, 0.15); amb.gain.setTargetAtTime(1, t + dur, 0.8);
  };

  // positional loops (fluorescent hum / vents / generator) — small pooled set reassigned each frame
  const loops = [];
  A.makeLoop = function (kind) {
    if (!A.ready) return null;
    const t = now();
    const p = ctx.createPanner(); p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = kind === 'gen' ? 3 : 1; p.rolloffFactor = kind === 'gen' ? 1 : 2.2;
    const g = ctx.createGain(); g.gain.value = 0; g.connect(p); p.connect(amb);
    const nodes = [];
    if (kind === 'hum') {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 120; const bp = filt('bandpass', 240, 3, g); o.connect(bp); o.start(t); nodes.push(o);
      const o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.value = 360; const g2 = ctx.createGain(); g2.gain.value = 0.15; o2.connect(g2); g2.connect(filt('bandpass', 4000, 1, g)); o2.start(t); nodes.push(o2);
    } else if (kind === 'vent') {
      const s = ctx.createBufferSource(); s.buffer = brownBuf; s.loop = true; s.connect(filt('bandpass', 380, 0.8, g)); s.start(t); nodes.push(s);
      const s2 = ctx.createBufferSource(); s2.buffer = noiseBuf; s2.loop = true; const g2 = ctx.createGain(); g2.gain.value = 0.2; s2.connect(g2); g2.connect(filt('highpass', 5000, 0.5, g)); s2.start(t); nodes.push(s2);
    } else if (kind === 'gen') {
      [30, 60, 90.5].forEach((f, i) => { const o = ctx.createOscillator(); o.type = i ? 'square' : 'sawtooth'; o.frequency.value = f; const gg = ctx.createGain(); gg.gain.value = i ? 0.25 : 1; o.connect(gg); gg.connect(filt('lowpass', 300, 3, g)); o.start(t); nodes.push(o); });
      const am = ctx.createOscillator(); am.frequency.value = 11; const ag = ctx.createGain(); ag.gain.value = 0.25; am.connect(ag); ag.connect(g.gain); am.start(t); nodes.push(am);
    } else if (kind === 'steam') {
      const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; s.connect(filt('highpass', 1800, 0.6, g)); s.start(t); nodes.push(s);
    }
    const L = { kind, p, g, nodes, vol: 0, pos: null };
    loops.push(L);
    return L;
  };
  A.setLoop = function (lp, pos, vol) {
    if (!lp) return; const t = now();
    if (pos) { if (lp.p.positionX) { lp.p.positionX.setTargetAtTime(pos.x, t, 0.05); lp.p.positionY.setTargetAtTime(pos.y, t, 0.05); lp.p.positionZ.setTargetAtTime(pos.z, t, 0.05); } else lp.p.setPosition(pos.x, pos.y, pos.z); }
    lp.g.gain.setTargetAtTime(vol, t, 0.15);
  };

  A.alarm = function (on) {
    if (!A.ready) return; const t = now();
    if (on && !alarm) {
      const g = ctx.createGain(); g.gain.value = 0; g.connect(sfx);
      const s = verbSend; const sg = ctx.createGain(); sg.gain.value = 0.6; g.connect(sg); sg.connect(s);
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 600;
      const lfo = ctx.createOscillator(); lfo.type = 'triangle'; lfo.frequency.value = 0.6; const lg = ctx.createGain(); lg.gain.value = 250; lfo.connect(lg); lg.connect(o.frequency);
      o.connect(filt('lowpass', 1800, 1, g)); o.start(t); lfo.start(t);
      g.gain.setTargetAtTime(0.06, t, 0.3);
      alarm = { g, o, lfo };
    } else if (!on && alarm) { alarm.g.gain.setTargetAtTime(0, t, 0.3); const a = alarm; alarm = null; setTimeout(() => { try { a.o.stop(); a.lfo.stop(); } catch (e) { /* ignore */ } }, 1500); }
  };

  /* ----- chase music: lookahead scheduler ----- */
  const music = { on: false, next: 0, step: 0, intensity: 0, gain: null };
  A.chase = function (on, intensity) {
    if (!A.ready) return;
    if (on && !music.on) {
      music.on = true; music.next = now() + 0.05; music.step = 0;
      music.gain = ctx.createGain(); music.gain.gain.value = 0; music.gain.connect(mus);
      music.gain.gain.setTargetAtTime(0.75, now(), 0.3);
      if (A.overrides.chase) { const s = ctx.createBufferSource(); s.buffer = A.overrides.chase; s.loop = true; s.connect(music.gain); s.start(); music.src = s; }
    } else if (!on && music.on) {
      music.on = false; const g = music.gain; g.gain.setTargetAtTime(0, now(), 0.9);
      if (music.src) { const s = music.src; setTimeout(() => { try { s.stop(); } catch (e) { /* ignore */ } }, 3000); music.src = null; }
    }
    if (intensity != null) music.intensity = intensity;
  };
  function scheduleMusic() {
    if (!music.on || music.src) return;
    const spb = 60 / 150 / 2; // eighth notes at 150bpm
    while (music.next < now() + 0.2) {
      const t = music.next, s = music.step % 32, g = music.gain;
      // pounding low drum
      if (s % 4 === 0 || s % 16 === 14) { const k = ctx.createGain(); k.connect(g); const o = osc('sine', 90, k, t, 0.4); o.frequency.exponentialRampToValueAtTime(34, t + 0.3); env(k, t, 0.002, 1.1, 0.04, 0.3); const n = ctx.createGain(); n.connect(g); noise(filt('lowpass', 900, 1, n), t, 0.06); env(n, t, 0.001, 0.4, 0.01, 0.05); }
      // metallic hits
      if (s % 8 === 6) { const k = ctx.createGain(); k.connect(g); [523, 739, 1108].forEach((f) => osc('square', f, filt('bandpass', f, 12, k), t, 0.3)); env(k, t, 0.001, 0.15, 0.01, 0.25); }
      // ostinato in low strings (sawtooth)
      const notes = [36.7, 36.7, 38.9, 36.7, 36.7, 41.2, 38.9, 34.6];
      const k2 = ctx.createGain(); k2.connect(g); const lp = filt('lowpass', 500 + music.intensity * 700, 3, k2);
      osc('sawtooth', notes[s % 8] * 2, lp, t, spb * 0.9); osc('sawtooth', notes[s % 8] * 2 * 1.006, lp, t, spb * 0.9);
      env(k2, t, 0.005, 0.22, spb * 0.5, spb * 0.3);
      // screaming high cluster every 2 bars when intense
      if (s === 0 && music.intensity > 0.5) { const k3 = ctx.createGain(); k3.connect(g); [1244, 1318, 1396].forEach((f) => osc('sawtooth', f, filt('bandpass', f, 4, k3), t, 2)); env(k3, t, 0.4, 0.07, 1.0, 0.5); }
      music.next += spb; music.step++;
    }
  }

  // heartbeat & breathing driven by danger
  let hbT = 0, brT = 0;
  A.update = function (dt, danger, hiding) {
    if (!A.ready) return;
    scheduleMusic();
    hbT -= dt;
    if (danger > 0.25 && hbT <= 0) { A.heartbeat(0.2 + danger * 0.5); hbT = 1.1 - danger * 0.6; }
    brT -= dt;
    if (hiding && brT <= 0) { A.breath(2, 0.12 + danger * 0.2); brT = 2.2 - danger; }
  };
  A.stopAll = function () { A.chase(false); A.alarm(false); loops.forEach((l) => A.setLoop(l, null, 0)); A.stopSpeech(); };
})(window.NP);
