/* NIGHTMARE PROTOCOL — monster AI: grid A* navigation + state machine
   States: dormant, patrol, investigate, search, stalk, hunt, chase, attack, retreat, gone */
'use strict';
(function (NP) {
  const L = NP.Level, C = L.C, W = L.W, H = L.H;
  const AI = (NP.AI = {});
  const V3 = THREE.Vector3;

  /* ---------------- navigation ---------------- */
  let clutter = null;
  function buildClutter() {
    clutter = new Float32Array(W * H);
    for (const b of L.boxes) {
      if (b.top < 0.45) continue;
      const gx0 = Math.floor(b.x0 / C), gx1 = Math.floor(b.x1 / C), gz0 = Math.floor(b.z0 / C), gz1 = Math.floor(b.z1 / C);
      for (let gz = gz0; gz <= gz1; gz++) for (let gx = gx0; gx <= gx1; gx++) {
        const ox = Math.max(0, Math.min(b.x1, (gx + 1) * C) - Math.max(b.x0, gx * C));
        const oz = Math.max(0, Math.min(b.z1, (gz + 1) * C) - Math.max(b.z0, gz * C));
        if (L.inb(gx, gz)) clutter[gz * W + gx] += (ox * oz) / (C * C);
      }
    }
  }
  AI.walkable = function (gx, gz) {
    if (!L.inb(gx, gz)) return false;
    const c = L.ch(gx, gz);
    if (c === '#' || c === 'M' || c === 'G') return false;
    if (c === '+') {
      const d = L.doorAtCell[gz * W + gx];
      if (!d) return false;
      if (d.open && d.t > 0.5) return true;
      if (d.open) return true;
      return d.monsterCanOpen && !d.locked;
    }
    if (AI.zones && !AI.zones.includes(c)) return false;
    if (clutter && clutter[gz * W + gx] > 0.62) return false;
    return true;
  };
  AI.findPath = function (sx, sz, tx, tz) {
    if (!clutter) buildClutter();
    const start = sz * W + sx, goal = tz * W + tx;
    if (!AI.walkable(tx, tz)) return null;
    const g = new Float32Array(W * H).fill(1e9), from = new Int32Array(W * H).fill(-1), closed = new Uint8Array(W * H);
    const open = [start]; g[start] = 0;
    const hfun = (i) => { const x = i % W, z = (i / W) | 0; return Math.hypot(x - tx, z - tz); };
    const f = new Float32Array(W * H).fill(1e9); f[start] = hfun(start);
    const dirs = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
    let iter = 0;
    while (open.length && iter++ < 4000) {
      let bi = 0; for (let i = 1; i < open.length; i++) if (f[open[i]] < f[open[bi]]) bi = i;
      const cur = open[bi]; open.splice(bi, 1);
      if (cur === goal) break;
      closed[cur] = 1;
      const cx = cur % W, cz = (cur / W) | 0;
      for (const [dx, dz, cost] of dirs) {
        const nx = cx + dx, nz = cz + dz;
        if (!AI.walkable(nx, nz)) continue;
        if (dx && dz) { // no corner cutting, never diagonal through doors
          if (!AI.walkable(cx + dx, cz) || !AI.walkable(cx, cz + dz)) continue;
          if (L.ch(nx, nz) === '+' || L.ch(cx, cz) === '+') continue;
        }
        const ni = nz * W + nx; if (closed[ni]) continue;
        const ng = g[cur] + cost + (clutter ? clutter[ni] * 3 : 0);
        if (ng < g[ni]) { g[ni] = ng; f[ni] = ng + hfun(ni); from[ni] = cur; if (!open.includes(ni)) open.push(ni); }
      }
    }
    if (from[goal] < 0 && start !== goal) return null;
    const path = [];
    for (let i = goal; i !== start && i >= 0; i = from[i]) path.push(i);
    path.reverse();
    return path.map((i) => ({ gx: i % W, gz: (i / W) | 0 }));
  };

  /* ---------------- tuning per story phase ---------------- */
  const PH = {
    off: { active: false },
    stalker: { active: true, walk: 1.25, run: 3.7, sight: 13, hear: 1.0, repel: true, stalk: true, lose: 2.5, aggro: 0.0 },
    breach: { active: true, walk: 1.8, run: 4.35, sight: 18, hear: 1.3, repel: false, stalk: false, lose: 3.0, aggro: 0.6, lightAngers: true },
    hunter: { active: true, walk: 1.9, run: 4.45, sight: 16, hear: 1.4, repel: false, stalk: true, lose: 3.0, aggro: 0.8, hunts: true },
    final: { active: true, walk: 2.2, run: 4.7, sight: 22, hear: 1.6, repel: false, stalk: false, lose: 4.0, aggro: 1.0, hunts: true, lightAngers: true },
  };
  AI.PHASES = PH;

  AI.init = function (scene) {
    this.c = new NP.Creature(scene);
    this.c.setVisible(false);
    this.state = 'dormant'; this.cfg = PH.off; this.path = null; this.pi = 0;
    this.awareness = 0; this.lastKnown = new V3(); this.lostT = 0; this.stateT = 0; this.repath = 0;
    this.searchCenter = new V3(); this.searchT = 0; this.stalkT = 0; this.beamT = 0; this.goneT = 0; this.stepT = 0; this.voiceT = 4;
    this.stuckT = 0; this.lastPos = new V3(); this.sawHide = false; this.spawns = []; this.speedMul = 1; this.target = null;
    this.yaw = 0; this.held = false; this.pauseT = 0; this.danger = 0;
    NP.Bus.on('noise', (n) => this.hear(n));
  };
  AI.reset = function () {
    this.setPhase('off'); this.c.setVisible(false); this.state = 'dormant'; this.path = null; this.held = false; this.sawHide = false; this.awareness = 0;
  };
  AI.setPhase = function (name, opts) {
    this.phase = name; this.cfg = PH[name] || PH.off;
    opts = opts || {};
    this.zones = opts.zones || null; this.spawns = opts.spawns || []; this.patrolCells = opts.patrol || null;
    if (!this.cfg.active) { this.go('dormant'); this.c.setVisible(false); }
  };
  AI.go = function (s) {
    if (this.state === s) return;
    this.state = s; this.stateT = 0; this.path = null; this.repath = 0;
    if (s === 'chase') { NP.Bus.emit('aiChase', { on: true }); }
    if (s !== 'chase' && s !== 'attack') NP.Bus.emit('aiChase', { on: false });
  };
  AI.spawnAt = function (x, z, yaw, state) {
    this.c.place(x, z, yaw || 0); this.yaw = yaw || 0;
    this.c.setVisible(true); this.c.setFade(0, true); this.c.root.visible = true;
    this.go(state || 'patrol'); this.lastPos.set(x, 0, z); this.stuckT = 0;
  };
  AI.pos = function () { return this.c.root.position; };
  AI.active = function () { return this.cfg.active && this.state !== 'dormant' && this.state !== 'gone' && this.c.visible; };

  /* spawn somewhere the player cannot currently see, far enough away */
  AI.pickHiddenSpawn = function (minD) {
    const P = NP.Player.pos;
    const cand = (this.spawns.length ? this.spawns : []).slice();
    NP.rand.shuffle(cand);
    for (const [gx, gz] of cand) {
      const c = L.center(gx, gz);
      if (c.distanceTo(P) < (minD || 12)) continue;
      if (L.los(P.x, P.z, c.x, c.z, 'sight')) continue;
      return c;
    }
    return null;
  };

  AI.hear = function (n) {
    if (!this.cfg.active || !this.c.visible) return;
    if (this.state === 'dormant' || this.state === 'gone' || this.state === 'attack' || this.state === 'retreat') return;
    const p = this.pos();
    const d = Math.hypot(n.x - p.x, n.z - p.z);
    const reach = n.r * this.cfg.hear * (L.los(p.x, p.z, n.x, n.z, 'sight') ? 1 : 0.6);
    if (d > reach) return;
    if (this.state === 'chase') { if (d < reach * 0.8) this.lastKnown.set(n.x, 0, n.z); return; }
    this.lastKnown.set(n.x, 0, n.z);
    this.searchCenter.set(n.x, 0, n.z);
    if (this.state !== 'investigate') { this.go('investigate'); if (Math.random() < 0.5) NP.Audio.creature(this.headPos(), 'click'); }
    else this.path = null;
  };

  const _hp = new V3();
  AI.headPos = function () { return this.c.headPos(_hp); };

  /* vision: returns 0..1 visibility of the player this frame */
  AI.seePlayer = function () {
    const Pl = NP.Player, P = Pl.pos;
    if (Pl.hidden) return 0;
    const p = this.pos();
    const dx = P.x - p.x, dz = P.z - p.z, d = Math.hypot(dx, dz);
    let range = this.cfg.sight;
    if (Pl.light.on && Pl.light.flick > 0.3) range *= 1.5;
    if (Pl.crouch) range *= 0.6;
    if (d > range) return 0;
    if (!L.los(p.x, p.z, P.x, P.z, 'sight')) return 0;
    const fa = Math.atan2(dx, dz);
    const off = Math.abs(NP.angDiff(this.yaw, fa));
    if (off > 1.25 && d > 2.8) return 0;
    let v = 1 - d / range;
    if (Pl.sprinting) v *= 1.4;
    if (Pl.light.on) v *= 1.4;
    return NP.clamp(v * 1.6, 0, 1);
  };

  function moveToward(self, tx, tz, speed, dt) {
    const p = self.pos();
    const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
    if (d < 0.05) return d;
    const want = Math.atan2(dx, dz);
    self.yaw += NP.angDiff(self.yaw, want) * Math.min(1, dt * (speed > 3 ? 9 : 5));
    const step = Math.min(d, speed * dt);
    // move mostly toward goal, with the body following its facing
    p.x += (dx / d) * step; p.z += (dz / d) * step;
    L.collideCircle(p, 0.36, null);
    self.c.root.rotation.y = self.yaw;
    return d;
  }
  // follow path toward a world target; returns true when arrived
  function navTo(self, target, speed, dt, arriveR) {
    const p = self.pos();
    const [sx, sz] = L.cellOf(p.x, p.z), [tx, tz] = L.cellOf(target.x, target.z);
    self.repath -= dt;
    if (!self.path || self.repath <= 0 || self.pathGoal !== tz * W + tx) {
      self.path = AI.findPath(sx, sz, tx, tz); self.pi = 0; self.repath = self.state === 'chase' ? 0.35 : 1.5; self.pathGoal = tz * W + tx;
      if (!self.path) { self.repath = 0.7; return Math.hypot(target.x - p.x, target.z - p.z) < (arriveR || 0.8); }
    }
    // direct when in same cell or clear straight shot nearby
    const dd = Math.hypot(target.x - p.x, target.z - p.z);
    if (dd < (arriveR || 0.8)) return true;
    let wx, wz;
    if (self.pi >= self.path.length || (sx === tx && sz === tz) || (dd < 3.5 && L.los(p.x, p.z, target.x, target.z, 'move'))) { wx = target.x; wz = target.z; }
    else {
      // skip ahead while waypoint is reachable in a straight line (path smoothing)
      while (self.pi < self.path.length - 1) {
        const n = self.path[self.pi + 1]; const nc = L.center(n.gx, n.gz);
        if (L.ch(self.path[self.pi].gx, self.path[self.pi].gz) === '+') break;
        if (L.los(p.x, p.z, nc.x, nc.z, 'move') && L.ch(n.gx, n.gz) !== '+') self.pi++; else break;
      }
      const w = self.path[self.pi];
      // open doors on the way
      const door = L.doorAtCell[w.gz * W + w.gx];
      if (door && !door.open) {
        if (door.monsterCanOpen && !door.locked) {
          const dc = door.center;
          if (Math.hypot(dc.x - p.x, dc.z - p.z) < 2.2) {
            door.swingDir = (door.axis === 'x' ? (p.x < dc.x ? -1 : 1) : (p.z < dc.z ? 1 : -1));
            door.setOpen(true, { slam: self.state === 'chase' || self.state === 'hunt' });
          }
        } else { self.path = null; self.repath = 0.5; return false; }
      }
      const wc = L.center(w.gx, w.gz);
      wx = wc.x; wz = wc.z;
      if (Math.hypot(wx - p.x, wz - p.z) < 0.55) self.pi++;
    }
    moveToward(self, wx, wz, speed, dt);
    return false;
  }

  AI.update = function (dt) {
    const c = this.c;
    if (!this.cfg.active || this.state === 'dormant') { if (c.visible && this.held) c.update(dt); this.danger = 0; return; }
    if (this.held) { c.update(dt); return; } // scripted control
    const Pl = NP.Player, P = Pl.pos, p = this.pos();
    this.stateT += dt;
    const dist = Math.hypot(P.x - p.x, P.z - p.z);
    let speed = 0;

    if (this.state === 'gone') {
      c.setVisible(false); this.goneT -= dt;
      if (this.goneT <= 0) {
        const s = this.pickHiddenSpawn(13);
        if (s) { this.spawnAt(s.x, s.z, Math.random() * 6.28, this.cfg.hunts ? 'hunt' : 'patrol'); }
        else this.goneT = 2;
      }
      this.danger = 0; return;
    }

    // ---- perception ----
    const vis = this.seePlayer();
    if (vis > 0) {
      this.awareness = Math.min(1.5, this.awareness + vis * dt * (this.state === 'investigate' || this.state === 'search' || this.state === 'hunt' ? 3.2 : 1.8));
      this.lastKnown.set(P.x, 0, P.z); this.lostT = 0;
    } else { this.awareness = Math.max(0, this.awareness - dt * 0.25); this.lostT += dt; }
    // flashlight on the creature
    const beamed = Pl.inBeam(this.headPos(), 18) || Pl.inBeam(p.clone().setY(1.2), 18);
    this.beamT = beamed ? this.beamT + dt : Math.max(0, this.beamT - dt * 2);
    if (this.cfg.lightAngers && beamed && this.state !== 'chase' && this.state !== 'attack' && dist < 16) { this.awareness = 1.2; }

    // ---- state machine ----
    switch (this.state) {
      case 'patrol': {
        c.setState(this.pauseT > 0 ? 'stand' : 'walk');
        if (this.pauseT > 0) { this.pauseT -= dt; break; }
        if (!this.target || navTo(this, this.target, this.cfg.walk, dt, 0.9) || this.stateT > 25) {
          this.target = this.randomPatrolTarget(); this.stateT = 0;
          if (Math.random() < 0.35) this.pauseT = 1.5 + Math.random() * 2.5;
        }
        speed = this.cfg.walk;
        if (this.awareness >= 1) this.onDetect();
        break;
      }
      case 'investigate': {
        c.setState('walk');
        speed = this.cfg.walk * 1.45;
        if (navTo(this, this.lastKnown, speed, dt, 1.0) || this.stateT > 14) { this.searchCenter.copy(this.lastKnown); this.go('search'); this.searchT = 7 + Math.random() * 5; }
        if (this.awareness >= 1) this.onDetect();
        break;
      }
      case 'search': {
        c.setState('search');
        speed = this.cfg.walk * 0.8;
        this.searchT -= dt;
        if (!this.target || navTo(this, this.target, speed, dt, 0.8)) {
          // check a nearby hiding spot sometimes
          const hs = (NP.World && NP.World.lockers || []).filter((l) => l.pos.distanceTo(this.searchCenter) < 6.5);
          if (hs.length && Math.random() < 0.55) { const l = NP.rand.pick(hs); this.target = l.front.clone(); this.inspecting = l; }
          else { this.target = this.randomNear(this.searchCenter, 3); this.inspecting = null; }
        }
        if (this.inspecting && this.pos().distanceTo(this.inspecting.front) < 0.9) {
          // stand in front of locker and listen
          c.setState('stand'); c.lookAt = this.inspecting.pos.clone().setY(1.4);
          this.inspectT = (this.inspectT || 0) + dt;
          if (this.inspectT > 1.6) {
            this.inspectT = 0;
            if (NP.Player.hidden === this.inspecting && (this.sawHide || Pl.noisyHide)) { this.go('attack'); NP.World.pullFromLocker(this.inspecting); break; }
            this.inspecting.rattle && this.inspecting.rattle();
            this.inspecting = null; this.target = null;
          }
        }
        if (this.searchT <= 0) { this.sawHide = false; this.go(this.cfg.hunts ? 'hunt' : 'patrol'); this.target = null; }
        if (this.awareness >= 1) this.onDetect();
        break;
      }
      case 'stalk': {
        // keep distance and watch
        c.lookAt = Pl.eyePos(new V3());
        this.stalkT -= dt;
        const want = 8.5;
        if (dist > want + 3 || vis === 0) { c.setState('walk'); speed = this.cfg.walk * 1.2; navTo(this, this.lastKnown, speed, dt, want); }
        else if (dist < want - 3) { c.setState('walk'); speed = this.cfg.walk; const away = p.clone().add(p.clone().sub(P).setY(0).normalize().multiplyScalar(2)); moveToward(this, away.x, away.z, speed, dt); }
        else { c.setState('watch'); this.yaw += NP.angDiff(this.yaw, Math.atan2(P.x - p.x, P.z - p.z)) * dt * 3; c.root.rotation.y = this.yaw; }
        if (this.cfg.repel && this.beamT > 0.9) { this.flinch(); break; }
        if (dist < 3.6 || (this.cfg.aggro > 0.5 && this.stalkT < 0) || Pl.sprinting && dist < 7) { this.startChase(); break; }
        if (this.stalkT <= 0) { this.retreat(); break; }
        if (this.lostT > 6) { this.go('search'); this.searchCenter.copy(this.lastKnown); this.searchT = 6; }
        break;
      }
      case 'hunt': {
        // knows roughly where the player is; closes in
        c.setState('walk'); speed = this.cfg.walk * 1.3;
        if (!this.target || this.stateT > 6) { this.target = this.randomNear(P, 2); this.stateT = 0; }
        if (navTo(this, this.target, speed, dt, 1)) this.target = null;
        if (this.awareness >= 1) this.onDetect();
        break;
      }
      case 'chase': {
        c.setState('sprint');
        speed = this.cfg.run * this.speedMul * (this.cfg.lightAngers && Pl.light.on ? 1.06 : 1);
        if (this.stateT < 0.55) { speed = 0; c.setState('watch'); c.lookAt = Pl.eyePos(new V3()); } // telegraph
        const tgt = vis > 0 ? P : this.lastKnown;
        if (speed > 0) navTo(this, tgt, speed, dt, 0.4);
        if (dist < 1.25 && vis > 0) { this.go('attack'); NP.Game.onCaught(this); break; }
        if (this.cfg.repel && this.beamT > 1.6 && dist > 3) { this.flinch(); break; }
        if (this.lostT > this.cfg.lose || Pl.hidden && !this.sawHide && this.lostT > 0.5) {
          NP.Audio.creature(this.headPos(), 'growl');
          this.searchCenter.copy(this.lastKnown); this.go('search'); this.searchT = 9 + Math.random() * 5;
        }
        if (Pl.hidden && this.sawHide) { this.searchCenter.copy(Pl.hidden.pos); this.go('search'); this.searchT = 12; this.target = Pl.hidden.front.clone(); this.inspecting = Pl.hidden; }
        break;
      }
      case 'attack': c.setState('attack'); c.lookAt = Pl.eyePos(new V3()); break;
      case 'flinchS': {
        c.setState('flinch'); c.lookAt = Pl.eyePos(new V3());
        if (this.stateT > 1.1) this.retreat();
        break;
      }
      case 'retreat': {
        c.setState(this.stateT < 0.3 ? 'flinch' : 'sprint'); speed = this.cfg.run * 0.9;
        if (!this.target) this.target = this.fleeTarget();
        const arrived = this.target ? navTo(this, this.target, speed, dt, 1) : true;
        if (arrived || (this.stateT > 1.2 && !L.los(P.x, P.z, p.x, p.z, 'sight')) || this.stateT > 6) this.disappear(6 + Math.random() * 8);
        break;
      }
    }
    c.speed = speed;
    if (this.state !== 'stalk' && this.state !== 'attack' && this.state !== 'flinchS' && !(this.state === 'search' && this.inspecting)) c.lookAt = vis > 0 ? Pl.eyePos(new V3()) : null;

    // stuck detection
    if (speed > 0.5) {
      if (p.distanceTo(this.lastPos) < speed * dt * 0.15) { this.stuckT += dt; if (this.stuckT > 1.2) { this.path = null; this.repath = 0; this.stuckT = 0; this.target = null; p.x += (Math.random() - 0.5) * 0.3; p.z += (Math.random() - 0.5) * 0.3; } }
      else this.stuckT = Math.max(0, this.stuckT - dt);
    }
    this.lastPos.copy(p);
    c.update(dt);

    // footsteps & voice
    if (speed > 0.3) {
      this.stepT -= dt * (speed > 3 ? 3.4 : 1.6);
      if (this.stepT <= 0) { this.stepT = 1; NP.Audio.footstepsAt({ x: p.x, y: 0.2, z: p.z }, speed > 3, 1); }
    }
    this.voiceT -= dt;
    if (this.voiceT <= 0) { this.voiceT = 3 + Math.random() * 6; NP.Audio.creature(this.headPos(), this.state === 'chase' ? NP.rand.pick(['growl', 'click', 'screech']) : NP.rand.pick(['breath', 'click', 'breath'])); }

    // danger level for heartbeat/tension (proximity + pursuit)
    const prox = NP.clamp(1 - dist / 18, 0, 1);
    this.danger = this.state === 'chase' ? Math.max(0.75, prox) : prox * (vis > 0 ? 0.9 : 0.5);
  };

  AI.onDetect = function () {
    this.awareness = 1;
    const P = NP.Player.pos;
    const dist = this.pos().distanceTo(P);
    if (this.cfg.stalk && this.cfg.aggro < 0.7 && dist > 5) { this.go('stalk'); this.stalkT = 7 + Math.random() * 7; NP.Bus.emit('aiStalk', {}); return; }
    if (this.cfg.stalk && this.cfg.aggro >= 0.7 && dist > 9 && Math.random() < 0.35) { this.go('stalk'); this.stalkT = 3 + Math.random() * 3; return; }
    this.startChase();
  };
  AI.startChase = function () {
    if (this.state === 'chase') return;
    this.go('chase');
    NP.Audio.creature(this.headPos(), 'screech');
    NP.Player.addShake(0.4, 0.4);
  };
  AI.flinch = function () {
    this.go('flinchS'); NP.Audio.creature(this.headPos(), 'wail'); NP.Bus.emit('aiFlinch', {});
  };
  AI.retreat = function () { this.go('retreat'); this.target = null; };
  AI.disappear = function (t) { this.c.setFade(1); this.goneT = t; NP.Timers.after(0.9, () => { if (this.state === 'retreat' || this.state === 'gone') { this.state = 'gone'; this.c.setVisible(false); } }); this.state = 'gone'; this.stateT = 0; NP.Bus.emit('aiChase', { on: false }); };
  AI.fleeTarget = function () {
    const P = NP.Player.pos, p = this.pos();
    let best = null, bd = -1;
    for (let i = 0; i < 40; i++) {
      const c = this.randomNear(p, 5); if (!c) continue;
      const d = c.distanceTo(P) - (L.los(P.x, P.z, c.x, c.z, 'sight') ? 6 : 0);
      if (d > bd) { bd = d; best = c; }
    }
    return best;
  };
  AI.randomNear = function (center, rCells) {
    const [cx, cz] = L.cellOf(center.x, center.z);
    for (let i = 0; i < 30; i++) {
      const gx = cx + Math.round((Math.random() * 2 - 1) * rCells), gz = cz + Math.round((Math.random() * 2 - 1) * rCells);
      if (this.walkable(gx, gz) && L.ch(gx, gz) !== '+') { const c = L.center(gx, gz); c.x += (Math.random() - 0.5) * 1.2; c.z += (Math.random() - 0.5) * 1.2; return c; }
    }
    return center.clone();
  };
  AI.randomPatrolTarget = function () {
    const list = this.patrolCells || this.spawns;
    if (list && list.length) { const [gx, gz] = NP.rand.pick(list); return L.center(gx, gz); }
    return this.randomNear(this.pos(), 6);
  };
  /* player entered a locker: did the monster see it happen? */
  AI.notifyHide = function () {
    if (!this.active()) return;
    const P = NP.Player.pos, p = this.pos();
    this.sawHide = (this.state === 'chase' || this.state === 'stalk') && this.lostT < 0.4 && p.distanceTo(P) < 14 && L.los(p.x, p.z, P.x, P.z, 'sight');
  };
})(window.NP);
